# Relatório QA — ZeroX Survival 0.4.0 nativo

Data: 2026-10-15 | Situação: projeto de fontes entregue; build em Android real pendente.

## Testes executados

- **PASS**: compilação das classes `core/*.java` com `javac` Java 21.
- **PASS**: checagem de tipos de todas as classes Java da aplicação com stubs de API Android/GLSurfaceView/GLES20.
- **PASS**: smoke-test JVM: 49.058 assertions concluídas. A maioria testa a finitude dos milhares de componentes de vértices da geometria; não é correto chamar isso de 49 mil casos de uso independentes.
- **PASS**: teste de 20 regiões, salvamento/restauração `SaveCodec` com checksum e rejeição de corrupção, preservação de inventário/vida na viagem, crafting, consumo e organização.
- **PASS**: criação de malhas nativas para cubo, cone, esfera, disco, solo e checagem de normais voltadas para cima.
- **PASS com mocks**: 7.418 chamadas de desenho `glDrawArrays` simuladas durante o ciclo de todas as 20 regiões, sem erro JVM; shader fake não é executado em GPU.
- **PASS**: código-fonte e manifesto sem import de `android.webkit`, WebView, URLs de rede, `INTERNET`, autenticação ou HTML/JS.
- **PASS**: APIs Java de persistência são compatíveis com Android minSdk 26 (FileInputStream/FileOutputStream; sem Files.readString do Java 11).

## Testes NÃO executados

- Build Gradle `:app:assembleDebug`: **não executado** por ausência de Android SDK/Gradle neste ambiente.
- Instalação/abertura do APK num dispositivo Android: **não executado**.
- Compilação real de shaders OpenGL ES 2.0, renderização real e FPS: **não executado** (stubs não são drivers gráficos).
- Verificação real dos gestos multitouch e salvamento entre reinicializações físicas: **pendente**.

## Problema da v0.3.0 corrigido na arquitetura

A versão anterior usava `WebView`/HTML/WebGL, o que gerou comportamento de página/navegador. A versão atual usa somente os componentes Android `GLSurfaceView`, `GLES20`, `View`, `Canvas` (HUD) e classes de núcleo Java. Não há arquivos `index.html`, JavaScript ou chamadas de browser.

## Teste obrigatório seguinte

Abrir a raiz no Code on the Go -> `:app:assembleDebug` -> instalar -> abrir pelo ícone -> verificar renderização do chão, personagem e joystick -> observar o Logcat se houver tela preta/crash. Verificar salvamento ao trocar de região, fechar e reabrir.
