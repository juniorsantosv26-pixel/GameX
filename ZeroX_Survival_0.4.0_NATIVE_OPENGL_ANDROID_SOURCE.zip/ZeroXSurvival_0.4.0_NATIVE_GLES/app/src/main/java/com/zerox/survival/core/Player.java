package com.zerox.survival.core;

public final class Player {
    public final Vec2 pos = new Vec2(0, 0);
    public final Inventory bag = new Inventory();
    public double health = 100, hunger = 100, thirst = 100;
    public boolean stealth = false;
    public Biome biome = Biome.WOODLAND;
    public double attackCooldown = 0;
    public double noiseSeconds = 0;
    public void update(double dt, double motion, Weather climate) {
        update(dt, motion, climate, false);
    }
    public void update(double dt, double motion, Weather climate, boolean running) {
        attackCooldown = Math.max(0, attackCooldown - dt);
        noiseSeconds = Math.max(0, noiseSeconds - dt);
        hunger = Vec2.clamp(hunger - dt * (0.16 + motion * 0.035), 0, 100);
        double rainFactor = climate == Weather.STORM ? 0.6 : 1.0;
        thirst = Vec2.clamp(thirst - dt * (0.27 + motion * 0.15 + (running ? 0.3 : 0))
                * rainFactor * biome.thirstMultiplier, 0, 100);
        if (hunger == 0) health -= 1.7 * dt;
        if (thirst == 0) health -= 2.6 * dt;
        if (climate == Weather.TOXIC_FOG) health -= 0.15 * dt;
        health = Vec2.clamp(health, 0, 100);
    }
    public boolean consume(Item item) {
        if (item != Item.BERRY && item != Item.WATER && item != Item.BANDAGE) return false;
        if (!bag.remove(item, 1)) return false;
        if (item == Item.BERRY) hunger = Vec2.clamp(hunger + 18, 0, 100);
        if (item == Item.WATER) thirst = Vec2.clamp(thirst + 28, 0, 100);
        if (item == Item.BANDAGE) health = Vec2.clamp(health + 35, 0, 100);
        return true;
    }
    public Item bestWeapon() {
        if (bag.count(Item.SPEAR) > 0) return Item.SPEAR;
        if (bag.count(Item.AXE) > 0) return Item.AXE;
        return null;
    }
    public boolean isDead() { return health <= 0; }
}
