package com.zerox.survival.core;

import java.util.Collections;
import java.util.EnumMap;
import java.util.Map;

public final class Recipe {
    public final Item result;
    public final int amount;
    public final Map<Item, Integer> requirements;
    private Recipe(Item result, int amount, Map<Item, Integer> requires) {
        this.result = result; this.amount = amount;
        this.requirements = Collections.unmodifiableMap(new EnumMap<>(requires));
    }
    public static Recipe of(Item result, int amount, Item[] items, int[] quantities) {
        if (items.length != quantities.length || items.length == 0 || amount < 1) throw new IllegalArgumentException();
        EnumMap<Item, Integer> req = new EnumMap<>(Item.class);
        for (int i = 0; i < items.length; i++) {
            if (quantities[i] < 1) throw new IllegalArgumentException();
            req.merge(items[i], quantities[i], Integer::sum);
        }
        return new Recipe(result, amount, req);
    }
    public boolean craft(Inventory inventory) {
        Inventory draft = inventory.copy();
        for (Map.Entry<Item, Integer> entry : requirements.entrySet()) {
            if (!draft.remove(entry.getKey(), entry.getValue())) return false;
        }
        if (!draft.add(result, amount)) return false;
        inventory.replace(draft);
        return true;
    }
    public String label() {
        StringBuilder b = new StringBuilder();
        for (Map.Entry<Item, Integer> entry : requirements.entrySet()) {
            if (b.length() > 0) b.append(" + ");
            b.append(entry.getValue()).append(' ').append(entry.getKey().title);
        }
        return b.toString();
    }
}
