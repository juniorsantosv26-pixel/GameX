package com.zerox.survival.graphics;

import android.opengl.GLES20;
import android.opengl.GLSurfaceView;
import android.opengl.Matrix;
import android.os.SystemClock;

import com.zerox.survival.core.Enemy;
import com.zerox.survival.core.GameEngine;
import com.zerox.survival.core.Item;
import com.zerox.survival.core.Regions;
import com.zerox.survival.core.ResourceNode;
import com.zerox.survival.core.Weather;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import javax.microedition.khronos.egl.EGLConfig;
import javax.microedition.khronos.opengles.GL10;

/** True Android OpenGL ES renderer. No browser, WebView, Javascript or network. */
public final class NativeRenderer implements GLSurfaceView.Renderer {
    private final GameEngine game;
    private final float[] projection = new float[16], view = new float[16], viewProj=new float[16];
    private final float[] model=new float[16], mvp=new float[16];
    private int program, aPos,aNormal,aColor,uMvp,uModel,uFog,uFogDensity;
    private int width=1,height=1;
    private long lastNanos=0;
    private float cameraX=0,cameraZ=0,walkPhase=0,facing=0;
    public volatile float inputX=0,inputY=0;
    public volatile int quality=1;
    public volatile float fps=0;
    private int currentRegion=-1;
    private Mesh ground,box,cone,limb,head,grass,rock,bush,water,shadow,flower,wood,redShirt,pants,skin,iron;
    private static final float[] GREEN={.17f,.79f,.32f},DARK_GREEN={.08f,.57f,.28f};
    private static final float[] TRUNK={.49f,.28f,.14f},ROCK={.62f,.68f,.77f},BUSH={.26f,.78f,.28f};
    private static final float[] BLUE={.10f,.58f,.93f},BLACK={.13f,.17f,.22f};
    private final List<float[]> decorations=new ArrayList<>();
    private final float[] fogColor={.61f,.82f,.94f};
    public NativeRenderer(GameEngine game) { this.game=game; }

    private static int shader(int type,String code) {
        int id=GLES20.glCreateShader(type);
        GLES20.glShaderSource(id,code);GLES20.glCompileShader(id);
        int[] ok=new int[1];GLES20.glGetShaderiv(id,GLES20.GL_COMPILE_STATUS,ok,0);
        if(ok[0]==0) throw new IllegalStateException("GL shader failed: "+GLES20.glGetShaderInfoLog(id));
        return id;
    }
    @Override public void onSurfaceCreated(GL10 unused,EGLConfig config) {
        // Vertex-lit geometry with distance fog.
        String vs="uniform mat4 uMvp; uniform mat4 uModel; uniform vec2 uCamera; attribute vec3 aPos; attribute vec3 aNormal; attribute vec3 aColor; varying vec3 vCol; varying float vDist; void main(){vec4 world=uModel*vec4(aPos,1.0); gl_Position=uMvp*vec4(aPos,1.0); vec3 light=normalize(vec3(-0.5,0.86,0.35)); vec3 n=normalize(mat3(uModel)*aNormal); float d=max(dot(n,light),0.0); vCol=aColor*(0.62+0.38*d); vDist=length(world.xz-uCamera); }";
        String fs="precision mediump float; uniform vec3 uFog; uniform float uFogDensity; varying vec3 vCol; varying float vDist; void main(){float f=clamp((vDist-8.0)*uFogDensity,0.0,0.72); gl_FragColor=vec4(mix(vCol,uFog,f),1.0);}";
        int v=shader(GLES20.GL_VERTEX_SHADER,vs),f=shader(GLES20.GL_FRAGMENT_SHADER,fs);
        program=GLES20.glCreateProgram();GLES20.glAttachShader(program,v);GLES20.glAttachShader(program,f);
        GLES20.glLinkProgram(program);
        int[] ok=new int[1];GLES20.glGetProgramiv(program,GLES20.GL_LINK_STATUS,ok,0);
        if(ok[0]==0)throw new IllegalStateException("GL program failed: "+GLES20.glGetProgramInfoLog(program));
        GLES20.glDeleteShader(v);GLES20.glDeleteShader(f);
        aPos=GLES20.glGetAttribLocation(program,"aPos"); aNormal=GLES20.glGetAttribLocation(program,"aNormal"); aColor=GLES20.glGetAttribLocation(program,"aColor");
        uMvp=GLES20.glGetUniformLocation(program,"uMvp"); uModel=GLES20.glGetUniformLocation(program,"uModel");
        uFog=GLES20.glGetUniformLocation(program,"uFog"); uFogDensity=GLES20.glGetUniformLocation(program,"uFogDensity");
        GLES20.glEnable(GLES20.GL_DEPTH_TEST);GLES20.glDepthFunc(GLES20.GL_LEQUAL);
        GLES20.glDisable(GLES20.GL_CULL_FACE);
        box=Mesh.cube(BLUE);cone=Mesh.cone(9,GREEN);limb=Mesh.cube(TRUNK);head=Mesh.sphere(12,8,new float[]{.96f,.74f,.50f});
        grass=Mesh.cone(4,new float[]{.26f,.76f,.17f});rock=Mesh.sphere(9,5,ROCK);bush=Mesh.sphere(10,6,BUSH);
        water=Mesh.disk(16,new float[]{.16f,.75f,.99f});shadow=Mesh.disk(18,new float[]{.24f,.43f,.23f});
        flower=Mesh.sphere(6,4,new float[]{1,.28f,.60f});wood=Mesh.cube(TRUNK);
        redShirt=Mesh.cube(new float[]{.68f,.23f,.25f});pants=Mesh.cube(new float[]{.17f,.33f,.43f});
        skin=Mesh.sphere(10,7,new float[]{.55f,.78f,.53f});iron=Mesh.cube(new float[]{.66f,.71f,.79f});
        currentRegion=-1;
        lastNanos=0;
    }
    @Override public void onSurfaceChanged(GL10 unused,int w,int h) {
        width=Math.max(1,w);height=Math.max(1,h);GLES20.glViewport(0,0,width,height);
    }
    private void regionMeshes() {
        if(currentRegion==game.region && ground!=null)return;
        currentRegion=game.region;int kind=Regions.kind(currentRegion);
        ground=Mesh.ground(28,kind);
        decorations.clear();Random r=new Random(75211L + 197L*currentRegion);
        for(int i=0;i<100;i++) {
            float x=r.nextFloat()*24-12,z=r.nextFloat()*24-12;
            if(x*x+z*z<5)continue;
            decorations.add(new float[]{x,z,r.nextFloat()*.45f+.18f,r.nextFloat(),r.nextFloat()});
        }
    }
    @Override public void onDrawFrame(GL10 unused) {
        long now=SystemClock.elapsedRealtimeNanos();
        float dt=lastNanos==0?0.016f:Math.max(.001f,Math.min(.05f,(now-lastNanos)/1_000_000_000f));
        lastNanos=now;fps=fps*.92f+(.08f/dt);
        synchronized(game) {
            game.update(dt,inputX,inputY);
            if(Math.hypot(inputX,inputY)>.12){facing=(float)Math.atan2(inputX+inputY,inputY-inputX);walkPhase+=dt*9;}
            float px=(float)game.player.pos.x,pz=(float)game.player.pos.y;
            cameraX+=(px-cameraX)*Math.min(1,dt*6);cameraZ+=(pz-cameraZ)*Math.min(1,dt*6);
            regionMeshes();
            int kind=Regions.kind(game.region);
            float toxic=kind==2?.16f:0;
            if(game.climate==Weather.TOXIC_FOG){fogColor[0]=.55f;fogColor[1]=.73f;fogColor[2]=.32f;}
            else if(game.climate==Weather.STORM){fogColor[0]=.48f;fogColor[1]=.61f;fogColor[2]=.70f;}
            else{fogColor[0]=.59f+toxic;fogColor[1]=.83f-toxic*.4f;fogColor[2]=.98f-toxic;}
            GLES20.glClearColor(fogColor[0],fogColor[1],fogColor[2],1);GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT|GLES20.GL_DEPTH_BUFFER_BIT);
            GLES20.glUseProgram(program);
            GLES20.glUniform3fv(uFog,1,fogColor,0);
            GLES20.glUniform1f(uFogDensity,quality==0?.04f:quality==1?.03f:.018f);
            int cam=GLES20.glGetUniformLocation(program,"uCamera");GLES20.glUniform2f(cam,cameraX,cameraZ);
            float aspect=(float)width/(float)height;
            Matrix.perspectiveM(projection,0,quality==0?47:43,aspect,0.1f,75f);
            Matrix.setLookAtM(view,0,cameraX+10.7f,14.9f,cameraZ+13.9f,cameraX,0.55f,cameraZ,0,1,0);
            Matrix.multiplyMM(viewProj,0,projection,0,view,0);
            draw(ground,0,0,0,1,1,1,0);
            for(float[] d:decorations) {
                if(Math.abs(d[0]-cameraX)>17 || Math.abs(d[1]-cameraZ)>17)continue;
                if(quality==0 && d[3]<.65f)continue;
                if(quality==1 && d[3]<.30f)continue;
                float h=Mesh.hill(d[0],d[1],kind);
                if(d[3]>.72){draw(flower,d[0],h+.18f,d[1],.20f,.25f,.20f,0);}
                else draw(grass,d[0],h+.18f,d[1],d[2],.55f,d[2],d[4]*6.2f);
            }
            if(game.region==0)drawShelter();
            for(ResourceNode n:game.resources)if(n.amount>0){
                float x=(float)n.pos.x,z=(float)n.pos.y;
                if(Math.abs(x-cameraX)>17||Math.abs(z-cameraZ)>17)continue;
                float h=Mesh.hill(x,z,kind);
                drawResource(n,x,h,z);
            }
            for(Enemy enemy:game.enemies)if(enemy.health>0) {
                float x=(float)enemy.pos.x,z=(float)enemy.pos.y;
                if(Math.abs(x-cameraX)>17||Math.abs(z-cameraZ)>17)continue;
                drawZombie(enemy,x,Mesh.hill(x,z,kind),z);
            }
            drawPlayer(px,Mesh.hill(px,pz,kind),pz);
        }
    }
    private void draw(Mesh m,float x,float y,float z,float sx,float sy,float sz,float yaw) {
        Matrix.setIdentityM(model,0);
        Matrix.translateM(model,0,x,y,z);
        if(yaw!=0)Matrix.rotateM(model,0,(float)Math.toDegrees(yaw),0,1,0);
        Matrix.scaleM(model,0,sx,sy,sz);
        Matrix.multiplyMM(mvp,0,viewProj,0,model,0);
        GLES20.glUniformMatrix4fv(uMvp,1,false,mvp,0);
        GLES20.glUniformMatrix4fv(uModel,1,false,model,0);
        m.buffer.position(0);GLES20.glEnableVertexAttribArray(aPos);GLES20.glVertexAttribPointer(aPos,3,GLES20.GL_FLOAT,false,Mesh.STRIDE,m.buffer);
        m.buffer.position(3);GLES20.glEnableVertexAttribArray(aNormal);GLES20.glVertexAttribPointer(aNormal,3,GLES20.GL_FLOAT,false,Mesh.STRIDE,m.buffer);
        m.buffer.position(6);GLES20.glEnableVertexAttribArray(aColor);GLES20.glVertexAttribPointer(aColor,3,GLES20.GL_FLOAT,false,Mesh.STRIDE,m.buffer);
        GLES20.glDrawArrays(GLES20.GL_TRIANGLES,0,m.vertices);
    }
    private void drawResource(ResourceNode n,float x,float h,float z){
        draw(shadow,x,h+.012f,z,1.0f,1,1.0f,0);
        switch(n.item){
            case WOOD:
                draw(wood,x,h+.75f,z,.34f,1.5f,.34f,0);
                draw(cone,x,h+2.12f,z,2.0f,2.8f,2.0f,0);
                draw(cone,x,h+3.08f,z,1.55f,2.1f,1.55f,.35f);break;
            case STONE:
                draw(rock,x,h+.36f,z,1.0f,.85f,1.10f,.2f);
                draw(rock,x+.42f,h+.20f,z+.22f,.58f,.55f,.64f,0);break;
            case FIBER:
                for(int i=0;i<4;i++)draw(grass,x+(i-2)*.19f,h+.45f,z+(i%2)*.18f,.34f,.9f,.34f,i);break;
            case BERRY:
                draw(bush,x,h+.55f,z,1.2f,1.2f,1.1f,0);
                for(int i=0;i<4;i++)draw(flower,x+(i-2)*.22f,h+.65f+(i%2)*.2f,z+(i%3-1)*.25f,.2f,.2f,.2f,0);break;
            default:
                draw(water,x,h+.03f,z,1.5f,1,1.4f,0);
                draw(rock,x+.45f,h+.16f,z+.25f,.38f,.3f,.40f,0);break;
        }
    }
    private void drawShelter(){
        int level=game.shelterLevel;if(level==0){
            draw(wood,-.6f,.30f,-.6f,.95f,.5f,.95f,0);
            draw(wood,.65f,.30f,-.45f,.95f,.5f,.95f,.2f);
        }else{
            draw(wood,0,.36f,-.5f,2.7f,.65f,2.2f,0);
            draw(limb,-1,.95f,-.5f,.28f,1.4f,2.2f,0);
            draw(limb,1,.95f,-.5f,.28f,1.4f,2.2f,0);
            draw(wood,0,1.6f,-.5f,3.2f,.30f,2.5f,0);
            if(level>=2)draw(iron,0,2.05f,-.5f,3.5f,.27f,2.7f,0);
        }
    }
    private void drawPlayer(float x,float y,float z){
        draw(shadow,x,y+.016f,z,.72f,1,.56f,0);
        float bob=(float)Math.sin(walkPhase)*.055f;
        draw(pants,x-.17f,y+.43f+bob,z,.25f,.8f,.28f,facing);
        draw(pants,x+.17f,y+.43f-bob,z,.25f,.8f,.28f,facing);
        draw(box,x,y+1.20f+bob,z,.87f,1.0f,.45f,facing);
        draw(wood,x,y+1.18f+bob,z+.29f,.70f,.82f,.28f,facing);
        draw(head,x,y+1.91f+bob,z,.69f,.70f,.68f,facing);
        draw(wood,x,y+2.20f+bob,z,.73f,.18f,.73f,facing);
        draw(head,x-.58f,y+1.23f+bob,z,.27f,.83f,.29f,facing);
        draw(head,x+.58f,y+1.23f-bob,z,.27f,.83f,.29f,facing);
        if(game.player.bestWeapon()!=null){
            draw(limb,x+.78f,y+1.04f,z,.11f,1.2f,.12f,facing);
            draw(iron,x+.78f,y+1.79f,z,.18f,.42f,.18f,facing);
        }
    }
    private void drawZombie(Enemy enemy,float x,float y,float z){
        draw(shadow,x,y+.018f,z,.72f,1,.63f,0);
        float bob=(float)Math.sin(game.elapsed*3+enemy.id)*.035f;
        draw(pants,x-.14f,y+.37f,z,.25f,.73f,.27f,0);
        draw(pants,x+.14f,y+.37f,z,.25f,.73f,.27f,0);
        draw(redShirt,x,y+1.08f+bob,z,.78f,.9f,.49f,0);
        draw(skin,x,y+1.74f+bob,z,.66f,.69f,.65f,0);
        draw(skin,x-.5f,y+1.1f+bob,z-.25f,.23f,.80f,.29f,-.25f);
        draw(skin,x+.5f,y+1.1f+bob,z-.25f,.23f,.80f,.29f,.25f);
    }
}
