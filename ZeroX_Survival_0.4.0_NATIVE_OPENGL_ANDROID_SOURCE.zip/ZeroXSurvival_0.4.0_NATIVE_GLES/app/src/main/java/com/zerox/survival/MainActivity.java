package com.zerox.survival;

import android.app.Activity;
import android.opengl.GLSurfaceView;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.WindowManager;
import android.view.View;
import android.widget.FrameLayout;

import com.zerox.survival.core.GameEngine;
import com.zerox.survival.core.Regions;
import com.zerox.survival.core.SaveCodec;
import com.zerox.survival.graphics.NativeRenderer;
import com.zerox.survival.ui.GameHud;

import java.io.File;
import java.nio.charset.StandardCharsets;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ByteArrayOutputStream;

/** Real Android Activity using GLSurfaceView. Does not instantiate WebView. */
public final class MainActivity extends Activity {
    private GameEngine game;
    private GLSurfaceView surface;
    private NativeRenderer renderer;
    private GameHud hud;
    private Handler autosave;
    private final Runnable saveTick=new Runnable(){
        @Override public void run(){
            if(game!=null){saveGame();autosave.postDelayed(this,45000);}
        }
    };
    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_FULLSCREEN|View.SYSTEM_UI_FLAG_HIDE_NAVIGATION|View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
        autosave=new Handler(Looper.getMainLooper());
        game = new GameEngine();
        int region=getPreferences(MODE_PRIVATE).getInt("region",0);
        if(region>=0&&region<Regions.IDS.length)game.changeRegion(region);
        String save=read(new File(getFilesDir(),"game.save"));
        if(save!=null && !SaveCodec.load(game,save)) game.say("Salvamento invalido; iniciado mundo novo");
        renderer = new NativeRenderer(game);
        surface = new GLSurfaceView(this);
        surface.setEGLContextClientVersion(2);
        surface.setEGLConfigChooser(8,8,8,8,16,0);
        surface.setRenderer(renderer);
        surface.setRenderMode(GLSurfaceView.RENDERMODE_CONTINUOUSLY);
        hud = new GameHud(this,game,renderer, this::travel);
        FrameLayout root=new FrameLayout(this);
        root.addView(surface,new FrameLayout.LayoutParams(-1,-1));
        root.addView(hud,new FrameLayout.LayoutParams(-1,-1));
        setContentView(root);
    }
    private static String read(File file){
        if(!file.isFile() || file.length()>131072)return null;
        try(FileInputStream in=new FileInputStream(file); ByteArrayOutputStream out=new ByteArrayOutputStream()){
            byte[] chunk=new byte[4096];int n;
            while((n=in.read(chunk))!=-1)out.write(chunk,0,n);
            return new String(out.toByteArray(),StandardCharsets.UTF_8);
        }catch(Exception ex){return null;}
    }
    private static void write(File file,String data){
        try {
            File tmp=new File(file.getAbsolutePath()+".tmp");
            try(FileOutputStream out=new FileOutputStream(tmp)){
                out.write(data.getBytes(StandardCharsets.UTF_8));
                out.getFD().sync();
            }
            if(!tmp.renameTo(file))throw new IllegalStateException("rename failed");
        }catch(Exception ex){android.util.Log.e("ZeroX","Local save failed",ex);}
    }
    private void travel(){
        synchronized(game) {
            int from=game.region;
            write(new File(getFilesDir(),"region_"+from+".save"),SaveCodec.encode(game));
            int next=(from+1)%Regions.IDS.length;
            game.changeRegion(next);
            String prior=read(new File(getFilesDir(),"region_"+next+".save"));
            if(prior!=null){
                GameEngine temp=new GameEngine();
                if(SaveCodec.load(temp,prior)){
                    game.enemies.clear();game.enemies.addAll(temp.enemies);
                    game.resources.clear();game.resources.addAll(temp.resources);
                    game.say("Regiao explorada restaurada");
                }
            }
            saveGame();
        }
    }
    private void saveGame(){
        synchronized(game){
            getPreferences(MODE_PRIVATE).edit().putInt("region",game.region).apply();
            String data=SaveCodec.encode(game);
            write(new File(getFilesDir(),"game.save"),data);
            write(new File(getFilesDir(),"region_"+game.region+".save"),data);
        }
    }
    @Override protected void onPause(){autosave.removeCallbacks(saveTick);saveGame();surface.onPause();super.onPause();}
    @Override protected void onResume(){super.onResume();if(surface!=null)surface.onResume();if(autosave!=null)autosave.postDelayed(saveTick,45000);}
}
