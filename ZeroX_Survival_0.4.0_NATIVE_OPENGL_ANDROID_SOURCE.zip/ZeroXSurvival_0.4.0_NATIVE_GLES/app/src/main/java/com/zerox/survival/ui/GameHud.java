package com.zerox.survival.ui;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.view.MotionEvent;
import android.view.View;

import com.zerox.survival.core.Crafting;
import com.zerox.survival.core.GameEngine;
import com.zerox.survival.core.Inventory;
import com.zerox.survival.core.Item;
import com.zerox.survival.core.ItemStack;
import com.zerox.survival.core.Regions;
import com.zerox.survival.graphics.NativeRenderer;

/** Touch input + native Android Canvas overlay above GLSurfaceView. */
public final class GameHud extends View {
    private final GameEngine game;
    private final NativeRenderer renderer;
    private final Runnable travel;
    private final Paint p=new Paint(Paint.ANTI_ALIAS_FLAG);
    private boolean inventory=false;
    private int joystickId=-1;
    private float knobX=110,knobY=445;
    private float sx=1,sy=1;
    public GameHud(Context ctx,GameEngine g,NativeRenderer r,Runnable next){super(ctx);game=g;renderer=r;travel=next;}
    private void rect(Canvas c,float l,float t,float r,float b,int color,float radius) {
        p.setColor(color);p.setStyle(Paint.Style.FILL);c.drawRoundRect(new RectF(l,t,r,b),radius,radius,p);
    }
    private void circle(Canvas c,float x,float y,float rad,int color){p.setColor(color);p.setStyle(Paint.Style.FILL);c.drawCircle(x,y,rad,p);}
    private void text(Canvas c,String value,float x,float y,int size,int color,boolean centered) {
        p.setColor(color);p.setStyle(Paint.Style.FILL);p.setTextSize(size);p.setTypeface(android.graphics.Typeface.create("sans-serif",android.graphics.Typeface.BOLD));
        p.setTextAlign(centered?Paint.Align.CENTER:Paint.Align.LEFT);c.drawText(value,x,y,p);
    }
    private static final int WHITE=0xFFFFFFFF, SOFT=0xFFE2F5F5, PANEL=0xD81B3245, DARK=0xD5152734;
    @Override protected void onDraw(Canvas real){
        sx=getWidth()/1000f;sy=getHeight()/560f;
        real.save();real.scale(sx,sy);
        synchronized(game){
            rect(real,13,13,405,115,PANEL,15);
            text(real,"ZEROX  //  SURVIVAL NATIVE 3D",28,39,20,WHITE,false);
            text(real,Regions.NAMES[game.region]+"   •   Nivel "+Regions.difficulty(game.region),28,61,17,SOFT,false);
            bar(real,28,75,113,"VIDA",(float)game.player.health,0xFFFA5B69);
            bar(real,156,75,113,"FOME",(float)game.player.hunger,0xFFFFC65E);
            bar(real,284,75,105,"SEDE",(float)game.player.thirst,0xFF4CCEFF);
            rect(real,417,15,650,68,PANEL,12);
            text(real,"ABATES  "+game.kills+"  •  FPS "+Math.round(renderer.fps),430,38,17,WHITE,false);
            text(real,"CLIMA  "+game.climate.name().replace('_',' '),430,57,14,SOFT,false);
            button(real,715,58,37,"GFX",0xC7266C93);
            button(real,810,58,37,"MAPA",0xD52FA283);
            button(real,917,58,45,"BOLSA",0xDA2986C1);
            if(game.toastSeconds>0){rect(real,306,122,695,159,DARK,13);text(real,game.toast,500,147,17,WHITE,true);}
            circle(real,110,445,82,0x6713293D);circle(real,110,445,59,0x77376F8D);circle(real,knobX,knobY,27,0xD74BC2E5);
            text(real,"MOVER",110,543,16,WHITE,true);
            button(real,884,443,70,"ATACAR",0xDAE75A42);
            button(real,758,484,43,game.player.stealth?"FURT*":"FURT",0xD15676A0);
            button(real,760,385,35,"AGUA",0xD13A94BB);
            button(real,690,440,35,"COMER",0xD1C68F40);
            button(real,664,350,37,"BASE",0xD1779062);
            button(real,840,324,42,"CRIAR",0xD17671D8);
            if(game.player.isDead()){rect(real,225,210,775,300,0xDF421C2A,19);text(real,"SOBREVIVENTE DERROTADO",500,248,29,WHITE,true);text(real,"Toque ATACAR para reiniciar",500,282,19,SOFT,true);}
            if(inventory)drawInventory(real);
        }
        real.restore();postInvalidateDelayed(40);
    }
    private void bar(Canvas c,int x,int y,int w,String title,float value,int color) {
        text(c,title,x,y+3,12,SOFT,false);
        rect(c,x,y+9,x+w,y+24,0xBB061D2B,5);
        rect(c,x,y+9,x+w*Math.max(0,Math.min(100,value))/100f,y+24,color,5);
        text(c,Integer.toString(Math.round(value)),x+w-22,y+22,11,WHITE,false);
    }
    private void button(Canvas c,int x,int y,int r,String label,int color){
        circle(c,x,y+3,r+3,0x6603121D);circle(c,x,y,r,color);
        circle(c,x-r*.28f,y-r*.29f,r*.15f,0x44FFFFFF);
        text(c,label,x,y+5,label.length()>5?14:17,WHITE,true);
    }
    private void drawInventory(Canvas c){
        rect(c,220,60,780,522,0xF4142D40,21);
        text(c,"INVENTARIO  •  15 ESPACOS",250,100,24,WHITE,false);
        text(c,"X",747,95,26,WHITE,true);
        for(int i=0;i<Inventory.SIZE;i++) {
            float x=253+(i%5)*101,y=125+(i/5)*92;
            rect(c,x,y,x+90,y+79,0xDC38566A,9);
            ItemStack s=game.player.bag.at(i);
            if(s!=null){
                int color=s.item.category==Item.Category.ARMA?0xFFFFB16C:s.item.category==Item.Category.CONSUMIVEL?0xFF72E2AC:0xFF93C9ED;
                circle(c,x+45,y+29,18,color);
                String name=s.item.title; if(name.length()>9)name=name.substring(0,9);
                text(c,name,x+45,y+57,14,WHITE,true);
                text(c,"x"+s.count,x+76,y+18,11,WHITE,true);
            }
        }
        rect(c,247,416,436,464,0xFF367CA0,11);text(c,"ORGANIZAR",340,447,18,WHITE,true);
        rect(c,457,416,751,464,0xFF7667B2,11);text(c,"RECEITAS: LANCA / MACHADO / CURA",604,445,14,WHITE,true);
        text(c,"Toque CRIAR fora da mochila para fabricar",500,493,15,SOFT,true);
    }
    private static boolean near(float x,float y,float cx,float cy,float r){float dx=x-cx,dy=y-cy;return dx*dx+dy*dy<r*r;}
    private void joy(float x,float y){float dx=x-110,dy=y-445;float len=(float)Math.hypot(dx,dy);float f=len>65?65/len:1;dx*=f;dy*=f;knobX=110+dx;knobY=445+dy;renderer.inputX=dx/65;renderer.inputY=-dy/65;}
    private void stopJoy(){joystickId=-1;knobX=110;knobY=445;renderer.inputX=0;renderer.inputY=0;}
    private void tap(float x,float y){
        synchronized(game){
            if(inventory){
                if(near(x,y,747,86,32)||x<220||x>780){inventory=false;return;}
                if(x>=247&&x<=436&&y>=416&&y<=464){game.player.bag.autoStackAndSort();game.say("Mochila organizada");}
                return;
            }
            if(near(x,y,917,58,58)){inventory=true;stopJoy();return;}
            if(near(x,y,810,58,44)){travel.run();return;}
            if(near(x,y,715,58,44)){renderer.quality=(renderer.quality+1)%3;game.say("Graficos: "+new String[]{"Economia","Equilibrado","Alto"}[renderer.quality]);return;}
            if(near(x,y,884,443,76)){if(game.player.isDead())game.restart();else game.action();return;}
            if(near(x,y,758,484,49)){game.player.stealth=!game.player.stealth;game.say(game.player.stealth?"Furtividade ativa":"Correndo livre");return;}
            if(near(x,y,760,385,40)){game.use(Item.WATER);return;}
            if(near(x,y,690,440,40)){game.use(Item.BERRY);return;}
            if(near(x,y,664,350,44)){game.upgradeShelter();return;}
            if(near(x,y,840,324,50)){
                for(int i=0;i<Crafting.RECIPES.length;i++)if(game.craft(i))break;
            }
        }
    }
    @Override public boolean onTouchEvent(MotionEvent e){
        int kind=e.getActionMasked();int index=e.getActionIndex();
        if(kind==MotionEvent.ACTION_DOWN||kind==MotionEvent.ACTION_POINTER_DOWN){
            int id=e.getPointerId(index);float x=e.getX(index)/Math.max(.001f,sx),y=e.getY(index)/Math.max(.001f,sy);
            if(!inventory&&joystickId==-1&&x<220&&y>310){joystickId=id;joy(x,y);}else tap(x,y);
        }else if(kind==MotionEvent.ACTION_MOVE){
            if(joystickId>=0){int pos=e.findPointerIndex(joystickId);if(pos>=0)joy(e.getX(pos)/Math.max(.001f,sx),e.getY(pos)/Math.max(.001f,sy));}
        }else if(kind==MotionEvent.ACTION_POINTER_UP||kind==MotionEvent.ACTION_UP||kind==MotionEvent.ACTION_CANCEL){
            if(kind==MotionEvent.ACTION_CANCEL||joystickId==e.getPointerId(index))stopJoy();
        }
        return true;
    }
}
