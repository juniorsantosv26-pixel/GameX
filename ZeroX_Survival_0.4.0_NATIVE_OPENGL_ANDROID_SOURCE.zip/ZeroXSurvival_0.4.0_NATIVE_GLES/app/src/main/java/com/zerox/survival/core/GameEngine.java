package com.zerox.survival.core;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public final class GameEngine {
    public Player player = new Player();
    public final List<Enemy> enemies = new ArrayList<>();
    public final List<ResourceNode> resources = new ArrayList<>();
    public Weather climate = Weather.CLEAR;
    public double weatherSeconds = 0, elapsed = 0;
    public int kills = 0;
    public int shelterLevel = 0;
    public int region = 0;
    public String toast = "Explore, colete e sobreviva";
    public double toastSeconds = 5;
    private final Random random = new Random(7102);
    public GameEngine() { restart(); }
    public void changeRegion(int target) {
        if (target < 0 || target >= Regions.IDS.length) return;
        region = target;
        enemies.clear(); resources.clear();
        player.pos.x = 0; player.pos.y = 0;
        player.biome = Biome.WOODLAND;
        int danger = Regions.difficulty(region);
        int count = region == 0 ? 6 : (4 + danger * 3);
        for (int i = 0; i < count; i++) spawnEnemy(i);
        java.util.Random rng = new java.util.Random(7102L + region * 7919L);
        int kind = Regions.kind(region);
        for (int i = 0; i < 50; i++) {
            double x = rng.nextDouble() * 23 - 11.5;
            double y = rng.nextDouble() * 23 - 11.5;
            if (Math.hypot(x, y) < 2.6) { i--; continue; }
            Item item;
            switch ((i + region * 3) % 8) {
                case 0: case 1: item = kind == 1 ? Item.STONE : Item.WOOD; break;
                case 2: item = Item.STONE; break;
                case 3: case 4: item = Item.FIBER; break;
                case 5: item = Item.BERRY; break;
                case 6: item = Item.WATER; break;
                default: item = kind == 1 ? Item.STONE : Item.WOOD; break;
            }
            resources.add(new ResourceNode(x, y, item, 3));
        }
        say("Regiao: " + Regions.NAMES[region]);
    }
    public void restart() {
        player = new Player();
        player.bag.add(Item.WOOD, 2);
        player.bag.add(Item.FIBER, 2);
        player.bag.add(Item.BERRY, 2);
        enemies.clear(); resources.clear();
        climate = Weather.CLEAR; weatherSeconds = 0; elapsed = 0; kills = 0; shelterLevel = 0;
        for (int i = 0; i < 14; i++) spawnEnemy(i);
        for (int i = 0; i < 48; i++) {
            double x = random.nextDouble() * 23 - 11.5;
            double y = random.nextDouble() * 23 - 11.5;
            if (Math.hypot(x, y) < 2.0) { i--; continue; }
            Item item;
            switch (i % 5) {
                case 0: item = Item.WOOD; break;
                case 1: item = Item.STONE; break;
                case 2: item = Item.FIBER; break;
                case 3: item = Item.BERRY; break;
                default: item = Item.WATER; break;
            }
            resources.add(new ResourceNode(x, y, item, 3));
        }
        changeRegion(0);
        say("Explore, colete e sobreviva.");
    }
    private void spawnEnemy(int id) {
        double theta = random.nextDouble() * Math.PI * 2;
        double radius = 5.2 + random.nextDouble() * 5.3;
        double x = Vec2.clamp(player.pos.x + Math.cos(theta) * radius, -11.5, 11.5);
        double y = Vec2.clamp(player.pos.y + Math.sin(theta) * radius, -11.5, 11.5);
        enemies.add(new Enemy(id, x, y));
    }
    public void say(String text) { toast = text; toastSeconds = 3.2; }
    public void nextWeather() {
        climate = climate.next(); weatherSeconds = 0;
        say("Evento: " + climate.title);
    }
    public void update(double dt, double joyX, double joyY) {
        if (player.isDead()) return;
        dt = Vec2.clamp(dt, 0, 0.065);
        elapsed += dt; weatherSeconds += dt;
        toastSeconds = Math.max(0, toastSeconds - dt);
        if (weatherSeconds >= 45) nextWeather();
        double magnitude = Math.min(1, Math.hypot(joyX, joyY));
        boolean running = magnitude > 0.92 && !player.stealth;
        double wx = joyX + joyY, wy = joyY - joyX;
        double norm = Math.hypot(wx, wy);
        if (norm > 1e-6) {
            double velocity = player.stealth ? 1.35 : running ? 3.25 : 2.55;
            player.pos.x = Vec2.clamp(player.pos.x + wx / norm * velocity * magnitude * dt, -12, 12);
            player.pos.y = Vec2.clamp(player.pos.y + wy / norm * velocity * magnitude * dt, -12, 12);
        }
        player.biome = Biome.at(player.pos.x, player.pos.y);
        player.update(dt, magnitude, climate, running);
        for (ResourceNode node : resources) node.update(dt);
        for (Enemy enemy : enemies) {
            if (enemy.health <= 0) continue;
            int group = 0;
            for (Enemy other : enemies) if (other.health > 0 && enemy.pos.distance(other.pos) < 4.8) group++;
            if (enemy.update(dt, player, climate, group, elapsed)) say("Zumbi atacou! Use furtividade e armas.");
        }
        if (player.isDead()) say("Voce morreu. Toque para reiniciar.");
    }
    public void action() {
        if (player.isDead() || player.attackCooldown > 0) return;
        Enemy nearest = null; double minDistance = 1.75;
        for (Enemy e : enemies) {
            if (e.health > 0 && player.pos.distance(e.pos) < minDistance) {
                minDistance = player.pos.distance(e.pos); nearest = e;
            }
        }
        if (nearest != null) {
            Item weapon = player.bestWeapon();
            int damage = weapon == Item.SPEAR ? 32 : weapon == Item.AXE ? 27 : 14;
            if (player.stealth && nearest.state != Enemy.State.CHASE && nearest.state != Enemy.State.ATTACK) damage *= 2;
            nearest.health -= damage;
            if (weapon != null && player.bag.degrade(weapon)) say("Arma quebrou: +1 sucata");
            player.noiseSeconds = 2.8;
            player.attackCooldown = 0.52;
            if (nearest.health <= 0) {
                kills++;
                if (kills % 2 == 0) player.bag.add(Item.SCRAP, 1);
                say("Inimigo eliminado! Abates: " + kills);
                if (kills % 3 == 0) spawnEnemy(enemies.size());
            } else say("Golpe: -" + damage + " PV inimigo");
            return;
        }
        ResourceNode nearestNode = null;
        minDistance = 1.85;
        for (ResourceNode node : resources) {
            if (node.amount > 0 && player.pos.distance(node.pos) < minDistance) {
                minDistance = player.pos.distance(node.pos); nearestNode = node;
            }
        }
        if (nearestNode != null) {
            if (nearestNode.harvest(player.bag)) {
                if (player.bag.count(Item.AXE) > 0 && (nearestNode.item == Item.WOOD || nearestNode.item == Item.STONE)) {
                    if (player.bag.degrade(Item.AXE)) say("Machado quebrou: +1 sucata");
                    else say("+1 " + nearestNode.item.title + " (machado usado)");
                } else say("+1 " + nearestNode.item.title);
                player.attackCooldown = 0.28;
            } else say("Mochila cheia!");
        } else say("Aproxime-se de um recurso ou inimigo");
    }
    /** Compact offline shelter progression; resource deductions are atomic. */
    public int shelterWoodCost() { return shelterLevel >= 3 ? 0 : 3 + shelterLevel * 2; }
    public int shelterStoneCost() { return shelterLevel >= 3 ? 0 : 1 + shelterLevel; }
    public boolean upgradeShelter() {
        if (player.isDead() || shelterLevel >= 3) {
            say(shelterLevel >= 3 ? "Abrigo no nivel maximo" : "Nao e possivel construir"); return false;
        }
        if (region != 0) { say("Construa apenas no refugio inicial"); return false; }
        if (player.pos.distance(new Vec2(0, 0)) > 3.0) {
            say("Volte para a base no centro do mapa"); return false;
        }
        Inventory draft = player.bag.copy();
        if (!draft.remove(Item.WOOD, shelterWoodCost()) || !draft.remove(Item.STONE, shelterStoneCost())) {
            say("Abrigo: madeira ou pedra insuficiente"); return false;
        }
        player.bag.replace(draft);
        shelterLevel++;
        say("Abrigo ampliado: nivel " + shelterLevel);
        return true;
    }
    public boolean craft(int index) {
        if (index < 0 || index >= Crafting.RECIPES.length) return false;
        boolean result = Crafting.RECIPES[index].craft(player.bag);
        say(result ? "Criado: " + Crafting.RECIPES[index].result.title : "Ingredientes insuficientes / mochila cheia");
        return result;
    }
    public void use(Item item) {
        say(player.consume(item) ? "Consumido: " + item.title : "Item nao consumivel");
    }
}
