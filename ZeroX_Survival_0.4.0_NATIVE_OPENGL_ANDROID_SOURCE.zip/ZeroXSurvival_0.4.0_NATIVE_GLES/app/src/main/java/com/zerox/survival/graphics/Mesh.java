package com.zerox.survival.graphics;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.FloatBuffer;
import java.util.ArrayList;

/** Interleaved static geometry: position xyz, normal xyz, vertex-color rgb. */
public final class Mesh {
    public final FloatBuffer buffer;
    public final int vertices;
    public static final int STRIDE = 9 * 4;
    private Mesh(ArrayList<Float> data) {
        vertices = data.size() / 9;
        buffer = ByteBuffer.allocateDirect(data.size() * 4).order(ByteOrder.nativeOrder()).asFloatBuffer();
        for (Float n : data) buffer.put(n);
        buffer.position(0);
    }
    public static final class Builder {
        private final ArrayList<Float> floats = new ArrayList<>();
        private void vertex(float[] v, float[] n, float[] c, float tint) {
            floats.add(v[0]); floats.add(v[1]); floats.add(v[2]);
            floats.add(n[0]); floats.add(n[1]); floats.add(n[2]);
            floats.add(c[0] * tint); floats.add(c[1] * tint); floats.add(c[2] * tint);
        }
        public Builder triangle(float[] a, float[] b, float[] c, float[] color) {
            float ux=b[0]-a[0],uy=b[1]-a[1],uz=b[2]-a[2];
            float vx=c[0]-a[0],vy=c[1]-a[1],vz=c[2]-a[2];
            float nx=uy*vz-uz*vy,ny=uz*vx-ux*vz,nz=ux*vy-uy*vx;
            float length=(float)Math.sqrt(nx*nx+ny*ny+nz*nz); if(length<0.000001f) length=1;
            // Inward winding is used consistently so reverse flat normals for outward lighting.
            float[] n={-nx/length,-ny/length,-nz/length};
            vertex(a,n,color,1f);vertex(b,n,color,0.975f);vertex(c,n,color,0.94f);
            return this;
        }
        public Builder quad(float[] a,float[] b,float[] c,float[] d,float[] col) {
            triangle(a,b,c,col);triangle(a,c,d,col); return this;
        }
        public Mesh build(){return new Mesh(floats);}
    }
    private static float[] p(float x,float y,float z){return new float[]{x,y,z};}
    public static Mesh cube(float[] color) {
        Builder m=new Builder();float a=-0.5f,b=0.5f;
        m.quad(p(a,b,b),p(a,b,a),p(b,b,a),p(b,b,b),color);
        m.quad(p(a,a,a),p(a,a,b),p(b,a,b),p(b,a,a),color);
        m.quad(p(a,a,b),p(a,b,b),p(b,b,b),p(b,a,b),color);
        m.quad(p(b,a,a),p(b,b,a),p(a,b,a),p(a,a,a),color);
        m.quad(p(b,a,b),p(b,b,b),p(b,b,a),p(b,a,a),color);
        m.quad(p(a,a,a),p(a,b,a),p(a,b,b),p(a,a,b),color);
        return m.build();
    }
    public static Mesh cone(int sides, float[] color) {
        Builder m=new Builder(); float[] top=p(0,0.5f,0);
        for(int i=0;i<sides;i++) {
            double a=2*Math.PI*i/sides,b=2*Math.PI*(i+1)/sides;
            float[] v1=p((float)Math.cos(a)*.5f,-.5f,(float)Math.sin(a)*.5f);
            float[] v2=p((float)Math.cos(b)*.5f,-.5f,(float)Math.sin(b)*.5f);
            m.triangle(v2,top,v1,color);
            m.triangle(p(0,-.5f,0),v2,v1,color);
        }
        return m.build();
    }
    public static Mesh sphere(int lon,int lat,float[] color) {
        Builder m=new Builder();
        for(int i=0;i<lat;i++) {
            double a=Math.PI*i/lat,b=Math.PI*(i+1)/lat;
            for(int j=0;j<lon;j++) {
                double c=Math.PI*2*j/lon,d=Math.PI*2*(j+1)/lon;
                float[] p1=sp(a,c),p2=sp(b,c),p3=sp(b,d),p4=sp(a,d);
                m.quad(p1,p2,p3,p4,color);
            }
        }
        return m.build();
    }
    private static float[] sp(double a,double b){return p((float)(Math.sin(a)*Math.cos(b)*.5), (float)(Math.cos(a)*.5), (float)(Math.sin(a)*Math.sin(b)*.5));}
    public static Mesh disk(int sides,float[] color) {
        Builder m=new Builder();
        for(int i=0;i<sides;i++){
            double a=Math.PI*2*i/sides,b=Math.PI*2*(i+1)/sides;
            m.triangle(p(0,0,0),p((float)Math.cos(a)*.5f,0,(float)Math.sin(a)*.5f),p((float)Math.cos(b)*.5f,0,(float)Math.sin(b)*.5f),color);
        }
        return m.build();
    }
    public static Mesh ground(int width,int kind) {
        Builder m=new Builder(); float w=width/2f;
        for(int x=0;x<width;x++)for(int z=0;z<width;z++){
            float xx=x-w,zz=z-w;
            float h=hill(xx,zz,kind),h2=hill(xx+1,zz,kind),h3=hill(xx+1,zz+1,kind),h4=hill(xx,zz+1,kind);
            float s=(float)(0.90+0.08*Math.sin(x*2.37+z*1.81) +0.03*Math.sin(x*8.1-z*7));
            float[] c;
            if(kind==1)c=new float[]{.58f*s,.72f*s,.48f*s};
            else if(kind==2)c=new float[]{.52f*s,.69f*s,.36f*s};
            else if(kind==3)c=new float[]{.60f*s,.70f*s,.49f*s};
            else c=new float[]{.35f*s,.70f*s,.29f*s};
            m.quad(p(xx,h,zz),p(xx+1,h2,zz),p(xx+1,h3,zz+1),p(xx,h4,zz+1),c);
        }
        return m.build();
    }
    public static float hill(float x,float z,int kind){
        return (float)((Math.sin(x*.55)*Math.cos(z*.48)+Math.sin(z*.24+x*.18))*.055 + ((kind==1)? Math.sin(x*.4+z*.12)*.09:0));
    }
}
