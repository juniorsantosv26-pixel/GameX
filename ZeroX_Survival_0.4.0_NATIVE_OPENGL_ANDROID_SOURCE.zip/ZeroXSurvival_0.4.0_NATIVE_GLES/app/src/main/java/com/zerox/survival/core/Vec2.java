package com.zerox.survival.core;

public final class Vec2 {
    public double x, y;
    public Vec2(double x, double y) { this.x = x; this.y = y; }
    public double distance(Vec2 other) { return Math.hypot(x - other.x, y - other.y); }
    public void toward(Vec2 target, double amount) {
        double dx = target.x - x, dy = target.y - y;
        double len = Math.hypot(dx, dy);
        if (len > 1e-8) { double step = Math.min(amount, len); x += dx / len * step; y += dy / len * step; }
    }
    public static double clamp(double value, double lo, double hi) { return Math.max(lo, Math.min(hi, value)); }
}
