package com.zerox.survival.core;

import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.zip.CRC32;

/** Entirely local, bounded, checksummed world snapshots with v1 migration. */
public final class SaveCodec {
    private static final int MAX_BYTES = 65536;
    private static final int MAX_ENEMIES = 256;
    private static final int MAX_RESOURCES = 256;
    private SaveCodec() { }

    public static String encode(GameEngine game) {
        StringBuilder b = new StringBuilder(8192);
        b.append("version=3\n");
        b.append("x=").append(game.player.pos.x).append('\n');
        b.append("y=").append(game.player.pos.y).append('\n');
        b.append("health=").append(game.player.health).append('\n');
        b.append("hunger=").append(game.player.hunger).append('\n');
        b.append("thirst=").append(game.player.thirst).append('\n');
        b.append("stealth=").append(game.player.stealth ? 1 : 0).append('\n');
        b.append("weather=").append(game.climate.name()).append('\n');
        b.append("weatherSeconds=").append(game.weatherSeconds).append('\n');
        b.append("elapsed=").append(game.elapsed).append('\n');
        b.append("kills=").append(game.kills).append('\n');
        b.append("shelterLevel=").append(game.shelterLevel).append('\n');
        for (int i = 0; i < Inventory.SIZE; i++) {
            ItemStack stack = game.player.bag.at(i);
            if (stack != null) b.append("slot").append(i).append('=').append(stack.item.name()).append(',')
                    .append(stack.count).append(',').append(stack.durability).append('\n');
        }
        if (game.enemies.size() > MAX_ENEMIES || game.resources.size() > MAX_RESOURCES)
            throw new IllegalStateException("world snapshot exceeds entity limits");
        b.append("enemies=").append(game.enemies.size()).append('\n');
        for (int i = 0; i < game.enemies.size(); i++) {
            Enemy e = game.enemies.get(i);
            b.append("enemy").append(i).append('=').append(e.id).append(',').append(e.pos.x).append(',')
                    .append(e.pos.y).append(',').append(e.origin.x).append(',').append(e.origin.y)
                    .append(',').append(e.health).append(',').append(e.hitCooldown).append('\n');
        }
        b.append("resources=").append(game.resources.size()).append('\n');
        for (int i = 0; i < game.resources.size(); i++) {
            ResourceNode r = game.resources.get(i);
            b.append("resource").append(i).append('=').append(r.item.name()).append(',').append(r.pos.x)
                    .append(',').append(r.pos.y).append(',').append(r.amount).append(',').append(r.respawnTimer).append('\n');
        }
        String payload = b.toString();
        if (payload.getBytes(StandardCharsets.UTF_8).length > MAX_BYTES - 32)
            throw new IllegalStateException("snapshot exceeds size limit");
        return payload + "crc=" + Long.toHexString(checksum(payload)) + '\n';
    }

    public static boolean load(GameEngine game, String raw) {
        if (raw == null || raw.isEmpty() || raw.length() > MAX_BYTES) return false;
        try {
            String payload;
            if (raw.startsWith("version=3\n") || raw.startsWith("version=2\n")) {
                if (!raw.endsWith("\n")) return false;
                int marker = raw.lastIndexOf("\ncrc=");
                if (marker < 0) return false;
                payload = raw.substring(0, marker + 1);
                String expected = raw.substring(marker + 5, raw.length() - 1);
                if (!expected.matches("[0-9a-f]{1,8}")) return false;
                if (checksum(payload) != Long.parseLong(expected, 16)) return false;
            } else if (raw.startsWith("version=1\n")) {
                // Old local saves are accepted without a checksum; new writes use v2.
                payload = raw;
                if (payload.length() > 4096) return false;
            } else return false;

            Map<String, String> data = new HashMap<>();
            for (String line : payload.split("\n")) {
                String[] pair = line.split("=", 2);
                if (pair.length != 2 || pair[0].isEmpty() || data.put(pair[0], pair[1]) != null)
                    return false;
            }
            String version = data.get("version");
            double x = bounded(data.get("x"), -12, 12), y = bounded(data.get("y"), -12, 12);
            double health = bounded(data.get("health"), 0, 100);
            double hunger = bounded(data.get("hunger"), 0, 100);
            double thirst = bounded(data.get("thirst"), 0, 100);
            double weatherSeconds = bounded(data.get("weatherSeconds"), 0, 45);
            int kills = integer(data.get("kills"), 0, 10000000);
            int shelterLevel = "3".equals(version) ? integer(data.get("shelterLevel"), 0, 3) : 0;
            boolean stealth;
            if ("1".equals(data.get("stealth"))) stealth = true;
            else if ("0".equals(data.get("stealth"))) stealth = false;
            else return false;
            Weather weather = Weather.valueOf(data.get("weather"));
            Inventory bag = new Inventory();
            for (int i = 0; i < Inventory.SIZE; i++) {
                String value = data.get("slot" + i);
                if (value == null) continue;
                String[] chunk = exact(value, 3);
                Item item = Item.valueOf(chunk[0]);
                int count = integer(chunk[1], 1, item.maxStack);
                int durability = integer(chunk[2], 0, Math.max(0, item.maxDurability));
                bag.setSlot(i, new ItemStack(item, count, durability));
            }
            List<Enemy> nextEnemies = null;
            List<ResourceNode> nextResources = null;
            double elapsed = 0;
            if ("2".equals(version) || "3".equals(version)) {
                elapsed = bounded(data.get("elapsed"), 0, 1e9);
                int n = integer(data.get("enemies"), 0, MAX_ENEMIES);
                int m = integer(data.get("resources"), 0, MAX_RESOURCES);
                nextEnemies = new ArrayList<>(n);
                nextResources = new ArrayList<>(m);
                Set<Integer> ids = new HashSet<>();
                for (int i = 0; i < n; i++) {
                    String[] e = exact(data.get("enemy" + i), 7);
                    int id = integer(e[0], 0, 10000000);
                    if (!ids.add(id)) return false;
                    double ex = bounded(e[1], -12, 12), ey = bounded(e[2], -12, 12);
                    double ox = bounded(e[3], -12, 12), oy = bounded(e[4], -12, 12);
                    double hp = bounded(e[5], 0, 58), hit = bounded(e[6], 0, 1.4);
                    Enemy enemy = new Enemy(id, ex, ey);
                    enemy.origin.x = ox; enemy.origin.y = oy;
                    enemy.health = hp; enemy.hitCooldown = hit;
                    nextEnemies.add(enemy);
                }
                for (int i = 0; i < m; i++) {
                    String[] r = exact(data.get("resource" + i), 5);
                    Item item = Item.valueOf(r[0]);
                    double rx = bounded(r[1], -12, 12), ry = bounded(r[2], -12, 12);
                    int quantity = integer(r[3], 0, 3);
                    double respawn = bounded(r[4], 0, 27);
                    ResourceNode node = new ResourceNode(rx, ry, item, quantity);
                    node.respawnTimer = respawn;
                    nextResources.add(node);
                }
            } else if (!"1".equals(version)) return false;
            // Apply only after *all* fields, counts and checksum are validated.
            game.player.pos.x = x; game.player.pos.y = y;
            game.player.health = health; game.player.hunger = hunger; game.player.thirst = thirst;
            game.player.stealth = stealth; game.player.biome = Biome.at(x, y);
            game.player.bag.replace(bag);
            game.weatherSeconds = weatherSeconds; game.climate = weather; game.kills = kills;
            game.shelterLevel = shelterLevel;
            if (nextEnemies != null) {
                game.enemies.clear(); game.enemies.addAll(nextEnemies);
                game.resources.clear(); game.resources.addAll(nextResources);
                game.elapsed = elapsed;
            }
            game.say("Partida offline restaurada");
            return true;
        } catch (RuntimeException error) { return false; }
    }

    private static String[] exact(String raw, int count) {
        if (raw == null) throw new IllegalArgumentException("missing entry");
        String[] pieces = raw.split(",", -1);
        if (pieces.length != count) throw new IllegalArgumentException("invalid entry");
        return pieces;
    }
    private static int integer(String raw, int min, int max) {
        int value = Integer.parseInt(raw);
        if (value < min || value > max) throw new IllegalArgumentException("out of bounds");
        return value;
    }
    private static double bounded(String raw, double min, double max) {
        double value = Double.parseDouble(raw);
        if (!Double.isFinite(value) || value < min || value > max)
            throw new IllegalArgumentException("out of bounds");
        return value;
    }
    private static long checksum(String payload) {
        CRC32 crc = new CRC32();
        byte[] bytes = payload.getBytes(StandardCharsets.UTF_8);
        crc.update(bytes, 0, bytes.length);
        return crc.getValue();
    }
}
