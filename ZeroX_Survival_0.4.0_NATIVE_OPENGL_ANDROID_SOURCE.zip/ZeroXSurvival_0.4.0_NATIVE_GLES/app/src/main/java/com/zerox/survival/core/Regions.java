package com.zerox.survival.core;

/** Original, offline region profiles informed by historical world-data structure. */
public final class Regions {
    private Regions() { }
    public static final String[] IDS = {
            "home", "easy_forest", "normal_forest", "hard_forest", "easy_rocks", "normal_rocks", "hard_rocks",
            "toxic_forest", "shelter_alpha", "shelter_beta", "shelter_charlie", "airdrop", "trader", "aircraft",
            "aircraft_2", "gas_station", "enemy_01", "enemy_02", "enemy_03", "tier2_default" };
    public static final String[] NAMES = {
            "Refugio Verde", "Floresta Solar", "Bosque Esmeralda", "Mata Selvagem", "Colinas Douradas",
            "Pedreira Azul", "Cordilheira Vermelha", "Pantano Toxico", "Bunker Alfa", "Bunker Beta",
            "Bunker Gama", "Suprimentos", "Acampamento", "Destrocos", "Destrocos II", "Posto Abandonado",
            "Zona Perdida I", "Zona Perdida II", "Zona Perdida III", "Terras Novas" };
    public static int difficulty(int index) {
        switch(index) {
            case 0: case 1: case 4: case 12: return 1;
            case 2: case 5: case 8: case 11: case 13: case 14: return 2;
            case 3: case 6: case 9: case 15: case 16: return 3;
            default: return 4;
        }
    }
    public static int kind(int index) {
        if (index == 4 || index == 5 || index == 6) return 1; // rocky
        if (index == 7 || index == 16 || index == 17 || index == 18) return 2; // toxic
        if (index == 8 || index == 9 || index == 10 || index == 13 || index == 14 || index == 15) return 3; // ruins
        return 0; // woodland
    }
}
