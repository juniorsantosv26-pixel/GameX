package com.zerox.survival.core;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.EnumMap;
import java.util.List;

/** Read-only, offline index of user-imported reference names. No foreign game binaries. */
public final class ReferenceCatalog {
    public enum Type { ITEM, CREATURE, REGION }
    public static final class Entry {
        public final Type type;
        public final String key, name, description;
        public Entry(Type type, String key, String name, String description) {
            this.type = type; this.key = key; this.name = name; this.description = description;
        }
    }
    private final EnumMap<Type, List<Entry>> entries = new EnumMap<>(Type.class);
    private ReferenceCatalog() { for (Type type : Type.values()) entries.put(type, new ArrayList<Entry>()); }
    public static ReferenceCatalog empty() { return new ReferenceCatalog(); }
    public static ReferenceCatalog read(InputStream input) throws IOException {
        ReferenceCatalog result = new ReferenceCatalog();
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(input, StandardCharsets.UTF_8))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] cols = line.split("\t", -1);
                if (cols.length != 4) continue;
                Type type;
                try { type = Type.valueOf(cols[0]); }
                catch (IllegalArgumentException err) { continue; }
                if (cols[1].isEmpty() || cols[2].isEmpty()) continue;
                result.entries.get(type).add(new Entry(type, cols[1], cols[2], cols[3]));
            }
        }
        return result;
    }
    public int count(Type type) { return entries.get(type).size(); }
    public List<Entry> page(Type type, int page, int pageSize) {
        List<Entry> list = entries.get(type);
        if (page < 0 || pageSize <= 0 || page > Integer.MAX_VALUE / pageSize) return Collections.emptyList();
        int from = page * pageSize;
        if (from >= list.size()) return Collections.emptyList();
        return Collections.unmodifiableList(list.subList(from, Math.min(list.size(), from + pageSize)));
    }
    public int maxPage(Type type, int pageSize) {
        return pageSize <= 0 ? 0 : Math.max(0, (count(type) - 1) / pageSize);
    }
}
