package com.zerox.survival.core;

public final class Crafting {
    private Crafting() { }
    public static final Recipe[] RECIPES = {
        Recipe.of(Item.SPEAR, 1, new Item[]{Item.WOOD, Item.STONE, Item.FIBER}, new int[]{2, 1, 1}),
        Recipe.of(Item.AXE, 1, new Item[]{Item.WOOD, Item.STONE, Item.FIBER}, new int[]{1, 2, 1}),
        Recipe.of(Item.BANDAGE, 1, new Item[]{Item.FIBER, Item.BERRY}, new int[]{3, 1}),
        Recipe.of(Item.WATER, 1, new Item[]{Item.BERRY, Item.FIBER}, new int[]{2, 1})
    };
}
