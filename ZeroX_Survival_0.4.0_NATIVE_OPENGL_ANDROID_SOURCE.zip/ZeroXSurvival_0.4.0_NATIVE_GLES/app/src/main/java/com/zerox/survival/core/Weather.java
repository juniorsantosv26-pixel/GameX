package com.zerox.survival.core;

public enum Weather {
    CLEAR("Ceu limpo"), STORM("Tempestade"), TOXIC_FOG("Nevoa toxica");
    public final String title;
    Weather(String title) { this.title = title; }
    public Weather next() { return values()[(ordinal() + 1) % values().length]; }
}
