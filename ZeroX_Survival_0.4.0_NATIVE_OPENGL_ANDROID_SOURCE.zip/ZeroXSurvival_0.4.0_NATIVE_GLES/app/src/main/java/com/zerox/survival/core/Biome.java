package com.zerox.survival.core;

/** Small procedural biomes; can later be replaced by a chunk-based map. */
public enum Biome {
    WOODLAND("Floresta", 1.0), ARID("Regiao seca", 1.65), MARSH("Pantano", 1.10);
    public final String title;
    public final double thirstMultiplier;
    Biome(String title, double thirstMultiplier) { this.title = title; this.thirstMultiplier = thirstMultiplier; }
    public static Biome at(double x, double y) {
        if (x > 3.5 && y < 4.5) return ARID;
        if (x < -3.5 && y > -4.0) return MARSH;
        return WOODLAND;
    }
}
