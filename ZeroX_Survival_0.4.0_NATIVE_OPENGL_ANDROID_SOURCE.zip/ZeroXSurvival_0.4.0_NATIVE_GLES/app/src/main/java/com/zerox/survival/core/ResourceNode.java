package com.zerox.survival.core;

public final class ResourceNode {
    public final Vec2 pos;
    public final Item item;
    public int amount;
    public double respawnTimer = 0;
    public ResourceNode(double x, double y, Item item, int quantity) {
        this.pos = new Vec2(x, y); this.item = item; this.amount = quantity;
    }
    public void update(double dt) {
        if (amount > 0) return;
        respawnTimer -= dt;
        if (respawnTimer <= 0) amount = 3;
    }
    public boolean harvest(Inventory bag) {
        if (amount <= 0 || !bag.add(item, 1)) return false;
        if (--amount == 0) respawnTimer = 27;
        return true;
    }
}
