package com.zerox.survival.core;

public final class ItemStack {
    public final Item item;
    public int count;
    public int durability;
    public ItemStack(Item item, int count, int durability) {
        if (item == null || count < 1 || count > item.maxStack) throw new IllegalArgumentException("Invalid stack");
        if (item.maxDurability > 0 && (count != 1 || durability < 1 || durability > item.maxDurability))
            throw new IllegalArgumentException("Invalid durability");
        this.item = item; this.count = count;
        this.durability = item.maxDurability == 0 ? 0 : durability;
    }
    public ItemStack copy() { return new ItemStack(item, count, durability); }
}
