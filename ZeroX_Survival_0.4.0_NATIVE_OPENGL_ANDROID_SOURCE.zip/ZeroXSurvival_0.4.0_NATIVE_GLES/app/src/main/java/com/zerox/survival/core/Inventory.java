package com.zerox.survival.core;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public final class Inventory {
    public static final int SIZE = 15;
    private final ItemStack[] slots = new ItemStack[SIZE];
    public ItemStack at(int i) { return slots[i] == null ? null : slots[i].copy(); }
    public void clear() { for (int i = 0; i < SIZE; i++) slots[i] = null; }
    public void setSlot(int index, ItemStack stack) { slots[index] = stack == null ? null : stack.copy(); }
    public Inventory copy() {
        Inventory result = new Inventory();
        for (int i = 0; i < SIZE; i++) result.setSlot(i, slots[i]);
        return result;
    }
    public void replace(Inventory incoming) {
        for (int i = 0; i < SIZE; i++) setSlot(i, incoming.slots[i]);
    }
    public int count(Item item) {
        int sum = 0;
        for (ItemStack stack : slots) if (stack != null && stack.item == item) sum += stack.count;
        return sum;
    }
    public boolean add(Item item, int quantity) {
        if (quantity <= 0) return false;
        Inventory preview = copy();
        if (!preview.insert(item, quantity)) return false;
        replace(preview);
        return true;
    }
    private boolean insert(Item item, int quantity) {
        int remaining = quantity;
        if (item.maxStack > 1) {
            for (ItemStack s : slots) {
                if (s != null && s.item == item && s.count < item.maxStack) {
                    int n = Math.min(item.maxStack - s.count, remaining);
                    s.count += n; remaining -= n;
                    if (remaining == 0) return true;
                }
            }
        }
        for (int i = 0; i < SIZE; i++) if (slots[i] == null) {
            int n = Math.min(item.maxStack, remaining);
            slots[i] = new ItemStack(item, n, item.maxDurability);
            remaining -= n;
            if (remaining == 0) return true;
        }
        return false;
    }
    public boolean remove(Item item, int quantity) {
        if (quantity <= 0 || count(item) < quantity) return false;
        int remaining = quantity;
        for (int i = 0; i < SIZE && remaining > 0; i++) {
            ItemStack s = slots[i];
            if (s == null || s.item != item) continue;
            int n = Math.min(s.count, remaining);
            s.count -= n; remaining -= n;
            if (s.count == 0) slots[i] = null;
        }
        return true;
    }
    public boolean degrade(Item tool) {
        if (tool.maxDurability <= 0) return false;
        for (int i = 0; i < SIZE; i++) {
            ItemStack s = slots[i];
            if (s != null && s.item == tool) {
                s.durability--;
                if (s.durability == 0) {
                    slots[i] = null;
                    add(Item.SCRAP, 1);
                    return true;
                }
                return false;
            }
        }
        return false;
    }
    public void autoStackAndSort() {
        // Keep individual durability for non-stackable gear.
        Inventory cleaned = new Inventory();
        List<ItemStack> list = new ArrayList<>();
        for (ItemStack s : slots) if (s != null) list.add(s.copy());
        list.sort(Comparator.comparingInt((ItemStack s) -> s.item.category.ordinal())
                .thenComparingInt(s -> s.item.ordinal()));
        for (ItemStack s : list) {
            if (s.item.maxStack > 1) cleaned.insert(s.item, s.count);
            else {
                for (int i = 0; i < SIZE; i++) if (cleaned.slots[i] == null) {
                    cleaned.slots[i] = s.copy(); break;
                }
            }
        }
        replace(cleaned);
    }
    public List<ItemStack> filtered(Item.Category category) {
        List<ItemStack> result = new ArrayList<>();
        for (ItemStack s : slots) if (s != null && (category == null || s.item.category == category)) result.add(s.copy());
        return result;
    }
}
