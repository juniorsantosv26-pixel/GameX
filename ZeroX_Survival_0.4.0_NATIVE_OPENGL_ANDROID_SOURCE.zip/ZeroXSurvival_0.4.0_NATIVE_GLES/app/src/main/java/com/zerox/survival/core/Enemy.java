package com.zerox.survival.core;

public final class Enemy {
    public enum State { IDLE, ALERT, CHASE, ATTACK }
    public final int id;
    public final Vec2 pos;
    public final Vec2 origin;
    public State state = State.IDLE;
    public double health = 58, hitCooldown = 0, wanderTick = 0, lostTargetTimer = 0;
    private double lastSeenX, lastSeenY;
    public Enemy(int id, double x, double y) {
        this.id = id; pos = new Vec2(x, y); origin = new Vec2(x, y);
        lastSeenX = x; lastSeenY = y;
    }
    public boolean update(double dt, Player player, Weather climate, int packCount, double elapsed) {
        if (health <= 0) return false;
        hitCooldown = Math.max(0, hitCooldown - dt);
        double distance = pos.distance(player.pos);
        double vision = climate == Weather.CLEAR ? 4.4 : climate == Weather.STORM ? 3.4 : 2.6;
        if (player.stealth) vision *= 0.44;
        double hearing = player.stealth ? 0.65 : 1.45;
        if (player.noiseSeconds > 0) hearing = player.stealth ? 2.0 : 4.5;
        boolean spotted = distance <= vision || distance <= hearing;
        if (spotted) {
            lostTargetTimer = 3.2;
            lastSeenX = player.pos.x; lastSeenY = player.pos.y;
        } else lostTargetTimer = Math.max(0, lostTargetTimer - dt);
        if (distance <= 0.86 && (spotted || lostTargetTimer > 0)) state = State.ATTACK;
        else if (spotted) state = State.CHASE;
        else if (lostTargetTimer > 0) state = State.ALERT;
        else state = State.IDLE;
        if (state == State.ATTACK) {
            if (hitCooldown == 0) {
                player.health = Math.max(0, player.health - (climate == Weather.STORM ? 9 : 7));
                hitCooldown = 1.4;
                return true;
            }
        } else if (state == State.CHASE || state == State.ALERT) {
            double targetX = state == State.CHASE ? player.pos.x : lastSeenX;
            double targetY = state == State.CHASE ? player.pos.y : lastSeenY;
            if (state == State.CHASE && packCount >= 2 && distance > 1.15) {
                // Offset flanks tangentially in opposite directions in a group.
                double ux = (player.pos.x - pos.x) / Math.max(0.01, distance);
                double uy = (player.pos.y - pos.y) / Math.max(0.01, distance);
                double side = (id % 2 == 0 ? 1 : -1) * Math.min(1.3, distance * 0.5);
                targetX += -uy * side;
                targetY += ux * side;
            }
            pos.toward(new Vec2(targetX, targetY), dt * (climate == Weather.STORM ? 1.45 : 1.1));
        } else {
            wanderTick -= dt;
            if (wanderTick <= 0) wanderTick = 1.5 + (id % 3);
            double angle = elapsed * 0.42 + id * 2.4;
            Vec2 goal = new Vec2(origin.x + Math.cos(angle) * 0.75, origin.y + Math.sin(angle) * 0.75);
            pos.toward(goal, dt * 0.26);
        }
        pos.x = Vec2.clamp(pos.x, -12, 12);
        pos.y = Vec2.clamp(pos.y, -12, 12);
        return false;
    }
}
