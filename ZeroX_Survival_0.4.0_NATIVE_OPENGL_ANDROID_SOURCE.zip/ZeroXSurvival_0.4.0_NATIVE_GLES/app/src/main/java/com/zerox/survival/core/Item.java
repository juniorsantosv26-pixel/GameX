package com.zerox.survival.core;

public enum Item {
    WOOD("Madeira", Category.COLETA, 20, 0),
    STONE("Pedra", Category.COLETA, 20, 0),
    FIBER("Fibra", Category.COLETA, 20, 0),
    BERRY("Frutas", Category.CONSUMIVEL, 10, 0),
    WATER("Agua", Category.CONSUMIVEL, 10, 0),
    BANDAGE("Curativo", Category.CONSUMIVEL, 5, 0),
    SPEAR("Lanca", Category.ARMA, 1, 18),
    AXE("Machado", Category.ARMA, 1, 25),
    SCRAP("Sucata", Category.COLETA, 20, 0);

    public enum Category { COLETA, ARMA, CONSUMIVEL }
    public final String title;
    public final Category category;
    public final int maxStack;
    public final int maxDurability;
    Item(String title, Category category, int maxStack, int durability) {
        this.title = title; this.category = category; this.maxStack = maxStack; this.maxDurability = durability;
    }
}
