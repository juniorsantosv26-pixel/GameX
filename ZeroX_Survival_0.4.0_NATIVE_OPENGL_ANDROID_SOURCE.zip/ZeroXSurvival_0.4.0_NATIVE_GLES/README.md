# ZeroX Survival 0.4.0 — NATIVE GLES / Code on the Go

**Substitui a versão 0.3.0 WebGL:** este é um projeto Android **Java + OpenGL ES 2.0** verdadeiro, NÃO um navegador disfarçado de aplicativo. A Activity usa `GLSurfaceView`, o renderizador usa `android.opengl.GLES20`, e o HUD é um `android.view.View` desenhado com `android.graphics.Canvas` (somente interface, não a cena 3D).

## Conteúdo do protótipo

- Gráficos 3D nativos: malhas procedurais, vértices coloridos, normais, iluminação difusa por shader, névoa à distância, câmera isométrica móvel, terreno e vegetação em relevo, personagens e zumbis 3D originais, recursos e abrigo 3D.
- **20 regiões offline** inspiradas na organização dos dados históricos de `assets/References/locations.json` do projeto público `apavlinovic/last-day-on-earth` (são implementações e gráficos originais, não modelos redistribuídos do jogo comercial).
- Joystick multitouch, ataque/coleta, furtividade, consumo, mochila com organização automática, crafting de lança/machado/curativos/água, melhoria do abrigo e viagem entre regiões.
- IA local com audição, visão, perseguição, flanqueamento e ataque; fome/sede/vida/clima; 3 perfis de detalhes (economia, equilibrado, alto).
- Salvamento local (CRC32) em `files/game.save`, com versões de região `files/region_N.save`, gravação no pause, viagem e autosave a cada 45 segundos.
- **Nenhuma** permissão `INTERNET`, nenhuma solicitação de login, nenhuma WebView, nenhuma dependência Maven além do Android Gradle Plugin que é exigido para gerar o APK.

## Instalação via Code on the Go / AndroidIDE

1. **Extraia** o ZIP. **Abra a pasta `ZeroXSurvival_0.4.0_NATIVE_GLES` inteira** (que contém `settings.gradle` e `app/`) como projeto Android. Não abra `app` isoladamente nem os arquivos `.java` soltos.
2. Configure Java 17 e Gradle 9.6.1 no Code on the Go, se houver opções. O projeto declara AGP 9.3.1 (mesmo alinhamento indicado pelos logs anteriores).
3. Execute `:app:assembleDebug`.
4. Se concluir, instale `app/build/outputs/apk/debug/app-debug.apk`.
5. Abra o app **ZeroX Survival Nativo** pelo ícone do Android. Ele **não** deve abrir Chrome nem pedir internet.

**Limite de verificação:** o ambiente de produção deste ZIP não possuía Android SDK/Gradle para gerar e instalar um APK. O projeto passou pelos testes do núcleo Java, checagem de tipos contra stubs Android e simulação dos comandos de desenho, **não por renderização GPU real**. Se `:app:assembleDebug` falhar, encaminhe o log completo para corrigirmos o erro exato. O aviso de variáveis de ambiente do daemon do Code on the Go não é, por si só, uma falha de build.

## Jogabilidade

- Esquerda: joystick de movimentação. Direita: **ATACAR** ataca zumbis ou coleta recursos ao alcance; **FURT** alterna furtividade.
- **AGUA / COMER:** consomem recursos da mochila; **BASE:** melhora o abrigo ao estar perto do centro e com materiais.
- **CRIAR:** tenta fabricar a primeira receita possível. **BOLSA:** mostra 15 slots e botão **ORGANIZAR**.
- **MAPA:** percorre circularmente as 20 regiões; seus inimigos/recursos são salvos localmente. **GFX:** alterna o detalhamento 3D.
- Se vida chegar a zero: tocar **ATACAR** para iniciar uma nova partida.

## Fontes e propriedade intelectual

Nenhum recurso binário, textura, som, modelo, APK ou código proprietário de Last Day on Earth ou Grim Soul foi copiado para esta versão. Foram estudados nomes de regiões e a estrutura de progressão do `locations.json` (registro histórico de 2018) como referência técnica. Esta versão não utiliza serviços ou servidores desses jogos.

## Arquitetura

```
app/src/main/java/com/zerox/survival/
  MainActivity.java                  Tela Android + armazenamento privado
  graphics/Mesh.java                Construção de malhas, normais e buffers OpenGL
  graphics/NativeRenderer.java      GLSurfaceView.Renderer/GLES20 + shaders
  ui/GameHud.java                   Controles multitouch, telas e barras Android
  core/GameEngine.java              Simulação determinística de sobrevivência
  core/Regions.java                 Vinte perfis originais de região
  core/SaveCodec.java               Estado persistente com checksum
  core/[demais classes].java        IA, crafting, inventário, recursos e clima
```

> O motor de desenho é 3D real **estilizado e low-poly**, não fotorrealismo ou personagens AAA. Desempenho, shaders e compatibilidade visual precisam de aferição física, antes de prometer taxas de quadros ou "qualidade máxima".

## Teste reproduzível fora do Android

Ambiente desktop com Java 17+: `sh tests/run_mock_tests.sh`. Os stubs em `tests/mock_android` servem apenas para testar sintaxe e simular o pipeline de comandos GLSurfaceView/GLES20, e **não entram no APK**, pois ficam fora de `app/src/main`.
