import android.opengl.GLES20;
import com.zerox.survival.core.*;
import com.zerox.survival.graphics.Mesh;
import com.zerox.survival.graphics.NativeRenderer;
import java.util.Random;

/** Runs on a desktop JVM with mock Android API. Not a real GPU/device test. */
public final class NativeProjectSmoke {
    static int checks;
    static void ok(boolean x,String message){checks++;if(!x)throw new AssertionError("TEST " + checks + " " + message);}
    static void close(double a,double b,String name){ok(Math.abs(a-b)<.01,name+" "+a+" vs "+b);}
    public static void main(String[] args){
        GameEngine g=new GameEngine();
        ok(g.region==0,"default region");ok(g.resources.size()==50,"resources");ok(g.enemies.size()==6,"home enemies");
        ok(g.player.health==100,"health init");ok(g.player.bag.count(Item.WOOD)==2,"wood init");
        g.player.health=78.5;
        g.player.bag.add(Item.WOOD,5);g.player.bag.add(Item.STONE,6);g.player.bag.add(Item.FIBER,8);
        for(int i=0;i<Regions.IDS.length;i++){
            g.changeRegion(i);
            ok(g.region==i,"region index"+i);
            ok(Regions.IDS[i].length()>2,"ID"+i);
            ok(g.resources.size()==50,"region resources"+i);
            ok(g.enemies.size()==(i==0?6:4+Regions.difficulty(i)*3),"region enemies"+i);
            close(g.player.health,78.5,"health persists");
            ok(g.player.bag.count(Item.STONE)==6,"bag persists");
            String save=SaveCodec.encode(g);
            GameEngine h=new GameEngine();ok(SaveCodec.load(h,save),"load region "+i);
            ok(h.enemies.size()==g.enemies.size(),"enemy persistence"+i);
            ok(h.resources.size()==50,"resource persistence"+i);
            ok(!SaveCodec.load(h,save.replace("health=78.5","health=99.5")),"CRC tamper blocked"+i);
        }
        g.changeRegion(0);
        ok(g.craft(0),"create spear");ok(g.player.bag.count(Item.SPEAR)==1,"spear in bag");
        g.player.health=50;g.player.bag.add(Item.BANDAGE,1);g.use(Item.BANDAGE);ok(g.player.health==85,"bandage");
        g.player.bag.autoStackAndSort();ok(g.player.bag.count(Item.STONE)>=1,"autostack");
        g.player.pos.x=2;g.player.pos.y=2;g.update(.05,1,0);ok(g.player.health>0,"update");
        // Mesh validation on JVM: size, finite components, native buffer shape.
        Mesh[] meshes={Mesh.cube(new float[]{1,0,0}),Mesh.cone(8,new float[]{0,1,0}),
                Mesh.sphere(12,8,new float[]{0,0,1}),Mesh.disk(20,new float[]{1,1,0}),Mesh.ground(28,0)};
        ok(meshes[0].buffer.get(4)>.5f,"cube upper face normal faces sunlight");
        ok(meshes[4].buffer.get(4)>.5f,"terrain surface normals face sunlight");
        for(Mesh mesh:meshes){ok(mesh.vertices>12,"nonempty mesh");ok(mesh.buffer.capacity()==mesh.vertices*9,"valid stride");
            for(int j=0;j<mesh.buffer.capacity();j++)ok(Float.isFinite(mesh.buffer.get(j)),"finite vertex component");}
        NativeRenderer renderer=new NativeRenderer(g);
        renderer.onSurfaceCreated(null,null);renderer.onSurfaceChanged(null,1600,900);
        for(int i=0;i<Regions.IDS.length;i++) {
            g.changeRegion(i);
            int before=GLES20.drawCount;
            renderer.inputX=.6f;renderer.inputY=.4f;
            renderer.onDrawFrame(null);
            ok(GLES20.drawCount-before>65,"native draw calls region "+i);
        }
        System.out.println("PASS " +checks+" JVM core/geometry/native-renderer mock checks; GLES draw calls="+GLES20.drawCount);
    }
}
