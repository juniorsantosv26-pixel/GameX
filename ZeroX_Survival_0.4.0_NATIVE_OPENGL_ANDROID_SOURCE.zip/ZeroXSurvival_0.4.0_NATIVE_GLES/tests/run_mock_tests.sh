#!/bin/sh
set -eu
cd "$(dirname "$0")/.."
DEST="$(mktemp -d)"
trap 'rm -rf "$DEST"' EXIT
find tests/mock_android app/src/main/java tests -name '*.java' > "$DEST/sources.txt"
javac -encoding UTF-8 -d "$DEST" @"$DEST/sources.txt"
java -Xmx512m -cp "$DEST" NativeProjectSmoke
