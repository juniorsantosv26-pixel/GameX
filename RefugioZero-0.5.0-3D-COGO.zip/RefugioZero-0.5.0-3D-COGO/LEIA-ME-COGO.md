# Refúgio Zero 0.5.0 — Code on the Go

## Instalar

Abra `apk-pronto/RefugioZero-0.5.0-3D.apk` e use o instalador Android. Para preservar sua partida, instale como atualização, sem desinstalar. O pacote `br.com.zerox.refugio`, a origem local e o certificado são os mesmos da versão 0.4.0.

## Compilar

1. Extraia o ZIP e abra `RefugioZero-0.5.0-3D-COGO`, onde está `settings.gradle`.
2. Execute `:app:assembleDebug` no Code on the Go.
3. Instale `app/build/outputs/apk/debug/app-debug.apk` pela opção do IDE.

Para Release: `:app:assembleRelease`. Em terminal compatível: `sh gradlew :app:assembleDebug`.

| Componente | Configuração |
|---|---|
| Gradle / AGP | 9.6.1 / 9.3.3 |
| Java | JDK 17 compatível com o IDE |
| Compile / Target SDK | 35 / 35 |
| Build Tools verificado | 36.0.0 |
| Android mínimo | API 26 / Android 8 |
| Android WebView | Chromium 108 ou mais recente |
| Renderizador local | Three.js 0.160.1 / WebGL |
| Versão / código | 0.5.0 / 6 |

A primeira sincronização pode precisar baixar ferramentas ausentes no IDE. A partida instalada funciona sem internet. O HTML está pré-compilado: Node.js, Python, Kotlin, NDK, CMake e servidor não são necessários para compilar o APK no CoGo.

## Qualidade e controles

Equilibrado é o padrão; Alto aumenta sombras, vegetação e o limite de resolução; Leve desativa sombras e pós-processo e reduz vegetação/resolução. A qualidade escolhida fica salva separadamente da partida. O modo 2D de compatibilidade é identificado se WebGL estiver indisponível.

| Controle | Ação |
|---|---|
| Direcional / WASD / setas | Caminhar, acompanhando a orientação da câmera |
| Toque no chão | Caminhar até o ponto |
| Toque num recurso | Aproximar-se e coletar |
| ↻ | Girar câmera em 90 graus |
| 1× / 1.2× / 0.85× | Alternar distância da câmera |
| ATACAR / espaço | Combater |
| Mochila / I | Recursos, alimentos e água |
| Oficina / C | Fabricação e reparos |
| Mapa / M | Viagem entre setores |
| Tocha / T | Iluminação noturna |
| H / kit médico | Curar |

Bosque: madeira, pedra, provisões e carne. Distrito: sucata, eletrônicos, tecido e garrafas. Refúgio: depósito, oficina e recuperação de vida. Alimento e hidratação caem fora do refúgio; coma/beba pela mochila. Fogueira cozinha; coletor de chuva reabastece garrafas. Receitas imediatas. A missão do rádio pertence à história local.

Menus, suspensão do app e perda de contexto gráfico pausam a simulação. O jogo tenta salvar na perda de contexto e informa quando o armazenamento está bloqueado. Limpar dados ou desinstalar remove o progresso; não há sincronização.

## Fontes e salvamento

Saves 0.1.0, 0.2.0, 0.2.1, 0.3.0 e 0.4.0 são migrados. A chave de desenvolvimento em `signing` assina Debug e Release: alias `refugio-dev`, senha `android`. Guarde a chave junto com o projeto para permitir atualizações.

Fontes em `src/`; regras em `core.mjs`; renderizador em `renderer3d.mjs`; ambiente, personagens, efeitos e pós-processo em módulos separados. Para alterar e regenerar o HTML: Node.js/JDK 17, `npm ci` e `npm run check`. CoGo usa o HTML pronto.

A verificação opcional de navegador usa Playwright/Chromium: `npm run browser-check`. `CHROME_EXECUTABLE` indica um executável instalado; `BASELINE_HTML` permite uma comparação local com a versão 0.4.0. Essas ferramentas não são necessárias para compilar ou jogar.

Há evidências de testes, WebGL real e compilação em `docs`. Não houve execução em aparelho Android, emulador ou interface CoGo nesta sessão. Desempenho e aparência final no seu aparelho precisam ser avaliados com o APK.
