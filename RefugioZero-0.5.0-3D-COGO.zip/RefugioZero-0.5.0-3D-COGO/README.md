# Refúgio Zero 0.5.0 — revisão gráfica 3D

APK pronto e fontes para Code on the Go. Partida integralmente offline: sem conta, login, loja, anúncios, telemetria ou nuvem. O pacote não solicita permissões Android.

## Novidades visuais

- Personagens arredondados, rosto, roupas, mochila, equipamentos e membros articulados.
- Bosque com copas, folhas com transparência, galhos, tufos de grama, pedras e flores; vegetação instanciada e movimento de vento.
- Solo, trilha, pedra, madeira e concreto com mapas locais de cor, normal e rugosidade.
- Refúgio com piso e paredes texturizados, janela, cama, prateleira e oficina; distrito com ruínas, calçada, barris e veículo abandonado.
- Luz de dia/noite gradual, sombras, neblina, partículas, fogo, disparos e impactos. Pós-processo com preservação HDR nas GPUs compatíveis.
- Câmera mais próxima, giro e zoom; três modos gráficos: Equilibrado, Alto e Leve. Preferência de qualidade salva no aparelho.

Os três setores mantêm coleta, combate, fabricação, inventário, alimento e hidratação e missão do rádio. Saves 0.4.0 e anteriores são migrados. A chave e o pacote são os mesmos.

Instale `apk-pronto/RefugioZero-0.5.0-3D.apk` como atualização. Para compilar, abra a pasta com `settings.gradle` no CoGo e execute `:app:assembleDebug`. O HTML já está pronto em `app/src/main/assets/game.html`; o IDE não precisa de Node.js.

Consulte `LEIA-ME-COGO.md`, `docs/REFERENCIAS-VISUAIS.md`, `docs/VERIFICACAO.md` e `docs/verification.json`.

Este é um protótipo próprio, com cenário volumétrico e terreno lógico plano. Não foi demonstrada superioridade gráfica ao LDOE atual; imagens promocionais e vídeos antigos não são comparação equivalente em GPU Android. A ausência de WebGL apresenta o modo 2D identificado.
