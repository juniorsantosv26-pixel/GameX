package br.com.zerox.refugio;

import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.Collections;

/** Single read-only page served from application assets under a stable local origin. */
class GameAssetClient extends WebViewClient {
    static final String GAME_URL = "https://refugio.zero.local/game.html";
    interface AssetSource { InputStream open() throws IOException; }
    private final AssetSource source;

    GameAssetClient(AssetSource source) { this.source = source; }

    @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
        return !GAME_URL.equals(request.getUrl().toString());
    }
    @Override public boolean shouldOverrideUrlLoading(WebView view, String url) {
        return !GAME_URL.equals(url);
    }
    @Override public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
        return respond(request.getUrl().toString(), request.getMethod());
    }
    @Override public WebResourceResponse shouldInterceptRequest(WebView view, String url) {
        return respond(url, "GET");
    }
    private WebResourceResponse respond(String url, String method) {
        // Embedded PNG resources contain local bytes; returning null lets WebView decode them.
        // This does not permit navigating to data URLs or making a network request.
        if ("GET".equals(method) && url != null && url.startsWith("data:image/png;base64,")) {
            return null;
        }
        if (!GAME_URL.equals(url) || !"GET".equals(method)) {
            return new WebResourceResponse("text/plain", "UTF-8", 403, "Offline", null,
                new ByteArrayInputStream(new byte[0]));
        }
        try {
            return new WebResourceResponse("text/html", "UTF-8", 200, "OK",
                Collections.singletonMap("Cache-Control", "no-store"), source.open());
        } catch (IOException missing) {
            byte[] message = "<!doctype html><meta charset='utf-8'><h1>Conteúdo local ausente</h1><p>Recompile o projeto completo para incluir o jogo.</p>".getBytes(StandardCharsets.UTF_8);
            return new WebResourceResponse("text/html", "UTF-8", 500, "Asset unavailable", null,
                new ByteArrayInputStream(message));
        }
    }
}
