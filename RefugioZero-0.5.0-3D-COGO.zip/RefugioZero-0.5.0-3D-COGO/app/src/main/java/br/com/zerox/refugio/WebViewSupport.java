package br.com.zerox.refugio;

/** Check before loading game scripts, which also protects existing local saves. */
final class WebViewSupport {
    private WebViewSupport() { }

    static boolean supports(String version) {
        if (version == null || !version.matches("[0-9]+(?:\\.[0-9]+)*")) return false;
        try {
            int separator = version.indexOf('.');
            String major = separator < 0 ? version : version.substring(0, separator);
            return Integer.parseInt(major) >= 108;
        } catch (NumberFormatException invalidVersion) {
            return false;
        }
    }
}
