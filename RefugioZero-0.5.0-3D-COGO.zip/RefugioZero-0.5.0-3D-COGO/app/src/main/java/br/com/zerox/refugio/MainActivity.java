package br.com.zerox.refugio;

import android.app.Activity;
import android.app.AlertDialog;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.view.ViewGroup;
import android.view.WindowInsets;
import android.view.WindowManager;
import android.webkit.RenderProcessGoneDetail;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.widget.FrameLayout;

/** Offline game host. No JavaScript bridge, remote pages, or filesystem access. */
public final class MainActivity extends Activity {
    private FrameLayout root;
    private WebView game;
    private boolean activityPaused;
    private boolean exitDialogOpen;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        root = new FrameLayout(this);
        root.setBackgroundColor(Color.rgb(23, 30, 27));
        root.setOnApplyWindowInsetsListener((view, insets) -> {
            if (Build.VERSION.SDK_INT >= 30) {
                android.graphics.Insets safe = insets.getInsets(
                    WindowInsets.Type.systemBars() | WindowInsets.Type.displayCutout());
                view.setPadding(safe.left, safe.top, safe.right, safe.bottom);
            } else {
                view.setPadding(insets.getSystemWindowInsetLeft(), insets.getSystemWindowInsetTop(),
                    insets.getSystemWindowInsetRight(), insets.getSystemWindowInsetBottom());
            }
            return insets;
        });
        setContentView(root);
        root.requestApplyInsets();
        if (Build.VERSION.SDK_INT >= 33) {
            getOnBackInvokedDispatcher().registerOnBackInvokedCallback(
                android.window.OnBackInvokedDispatcher.PRIORITY_DEFAULT, this::handleBack);
        }
        createGame();
    }

    private void createGame() {
        try {
            android.content.pm.PackageInfo engine = WebView.getCurrentWebViewPackage();
            if (!WebViewSupport.supports(engine == null ? null : engine.versionName)) {
                new AlertDialog.Builder(this).setTitle("Atualize a tela do Android")
                    .setMessage("Atualize o Android System WebView (ou o provedor WebView ativo) e abra o jogo novamente. Seu progresso permanece guardado.")
                    .setPositiveButton("Fechar", (dialog, which) -> finish()).setCancelable(false).show();
                return;
            }
            WebView view = new WebView(this);
            game = view;
            view.setBackgroundColor(Color.rgb(23, 30, 27));
            WebSettings settings = view.getSettings();
            settings.setJavaScriptEnabled(true);
            settings.setDomStorageEnabled(true);
            settings.setAllowFileAccess(false);
            settings.setAllowContentAccess(false);
            settings.setBlockNetworkLoads(true);
            settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
            settings.setMediaPlaybackRequiresUserGesture(true);
            settings.setSupportMultipleWindows(false);
            settings.setJavaScriptCanOpenWindowsAutomatically(false);
            view.setWebViewClient(new GameAssetClient(() -> getAssets().open("game.html")) {
                @Override public void onPageFinished(WebView web, String url) {
                    dispatch(activityPaused || exitDialogOpen ? "refugio:pause" : "refugio:resume");
                }
                @Override public boolean onRenderProcessGone(WebView web, RenderProcessGoneDetail detail) {
                    root.removeView(web);
                    if (game == web) game = null;
                    web.destroy();
                    if (!isFinishing()) {
                        new AlertDialog.Builder(MainActivity.this)
                            .setTitle("Reabrir o refúgio")
                            .setMessage("O sistema encerrou a tela do jogo. Reabra para recuperar o último progresso salvo.")
                            .setPositiveButton("Reabrir", (dialog, which) -> createGame())
                            .setNegativeButton("Sair", (dialog, which) -> finish()).show();
                    }
                    return true;
                }
            });
            root.addView(view, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
            view.loadUrl(GameAssetClient.GAME_URL);
        } catch (RuntimeException failure) {
            if (game != null) { root.removeView(game); game.destroy(); game = null; }
            new AlertDialog.Builder(this).setTitle("Não foi possível abrir")
                .setMessage("Confira se o Android System WebView está disponível e tente abrir o jogo novamente.")
                .setPositiveButton("Fechar", (dialog, which) -> finish()).setCancelable(false).show();
        }
    }

    private void dispatch(String event) {
        if (game != null) game.evaluateJavascript("window.dispatchEvent(new Event('" + event + "'));", null);
    }

    private void handleBack() {
        if (game == null) { finish(); return; }
        if (exitDialogOpen) return;
        game.evaluateJavascript("typeof window.refugioBack === 'function' && window.refugioBack()", value -> {
            if ("true".equals(value) || isFinishing() || exitDialogOpen) return;
            exitDialogOpen = true;
            dispatch("refugio:pause");
            AlertDialog dialog = new AlertDialog.Builder(this).setTitle("Sair do Refúgio Zero?")
                .setMessage("Seu progresso fica salvo neste aparelho.")
                .setPositiveButton("Sair", (d, which) -> finish())
                .setNegativeButton("Continuar", null).create();
            dialog.setOnDismissListener(d -> {
                exitDialogOpen = false;
                if (!activityPaused && !isFinishing()) dispatch("refugio:resume");
            });
            dialog.show();
        });
    }

    @Override public void onBackPressed() { handleBack(); }

    @Override protected void onPause() {
        activityPaused = true;
        if (game != null) {
            final WebView pausing = game;
            pausing.evaluateJavascript("window.dispatchEvent(new Event('refugio:pause')); true;", value -> {
                if (activityPaused && game == pausing) pausing.onPause();
            });
        }
        super.onPause();
    }

    @Override protected void onResume() {
        super.onResume();
        activityPaused = false;
        if (game != null) {
            game.onResume();
            dispatch(exitDialogOpen ? "refugio:pause" : "refugio:resume");
        }
    }

    @Override protected void onDestroy() {
        if (game != null) {
            root.removeView(game);
            game.destroy();
            game = null;
        }
        super.onDestroy();
    }
}
