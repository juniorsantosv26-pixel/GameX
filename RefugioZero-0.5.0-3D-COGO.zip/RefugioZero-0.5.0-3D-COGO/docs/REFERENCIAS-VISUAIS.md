# Referências visuais e limites da comparação

## O que foi recuperado

O contexto anterior identifica a série **Last Day do Zero 8**, do **BaltaPlay Games**. A URL completa da playlist não foi recuperada: a mensagem antiga guardava somente um endereço truncado. A análise anterior havia tratado de mecânicas dos episódios 08 e 33, sem conseguir carregar imagens. Esses episódios não foram apresentados como vídeos revistos visualmente nesta atualização.

Foi localizado o episódio 47, **O IMPORTANTE BAÚ DA BAGUNÇA**, publicado em 17/05/2024: https://www.youtube.com/watch?v=zlC6gX8KdSc . A página e os metadados foram obtidos; os endereços de storyboard retornaram página indisponível, não quadros. Também foram encontrados registros dos episódios 02 e 03, úteis apenas para identificar a série e os temas. Não houve reprodução nem revisão de todos os vídeos da playlist.

## Referência atual oficial

- https://kefirgames.com/games/last-day-on-earth
- https://play.google.com/store/apps/details?id=zombie.survival.craft.z&hl=pt_BR

Duas imagens promocionais da ficha oficial foram abertas: combate em interior e montagem/melhoria da base. Elementos observados: silhuetas e equipamento dos personagens, variedade de materiais, direção de luz, contraste entre luz quente e sombras, detalhamento de ambientes e distribuição dos controles. Essas imagens são promocionais; não comprovam como a versão instalada renderiza em todo aparelho ou local.

## Dados locais utilizados

Foram preservados os valores e rótulos de sobrevivência importados do ZIP fornecido, conforme `DADOS-IMPORTADOS.md` e `IMPORTACAO-LAST-DAY.json`. Os 31 recursos do commit fixo do repositório continuam locais, conforme `assets/source-manifest.json`. Os modelos estáticos antigos não foram tratados como prova da qualidade do LDOE atual.

## Melhorias implementadas e comparação válida

A base de comparação executável foi a versão 0.4.0 desta conversa, que o usuário confirmou jogável. O mesmo estado de partida, setor, posição e viewport foi renderizado para inspeção interna nas duas versões. A 0.5.0 acrescenta personagens arredondados, equipamento, materiais com normal/rugosidade, vegetação em camadas, composição dos cenários, qualidade/zoom e efeitos. A câmera mudou de distância, portanto as imagens não são uma medição controlada de resolução de textura ou desempenho.

Não há benchmark ou comparação equivalente, no mesmo aparelho e cenário, contra a versão atual instalada do LDOE. **Não foi demonstrado que a 0.5.0 supera os gráficos do LDOE atual.** Essa é a meta de evolução, não uma certificação desta entrega.

Para revisar a playlist exata, é necessário o endereço completo, sem truncamento. A implementação e os testes não dependem dessa referência para rodar offline.
