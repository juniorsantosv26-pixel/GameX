# Uso dos arquivos enviados

O novo `Last day arquivos.zip` tem 17.394.603 bytes, 24 arquivos e 73.012.047 bytes descompactados. A integridade CRC do ZIP foi conferida. São 14 arquivos de idioma `.loc`, dois `.bytes`, um `.refs.dec`, um `.refs.idx`, cinco `.sdat` e um `.fdat`.

O português contém 25.097 registros. Um `.bytes` tem conteúdo GZIP que foi descompactado e lido como MessagePack, com 126 tabelas de referência. O índice `.refs.idx` identifica 315 seções no `.refs.dec`; esses binários foram inventariados, sem interpretar ou executar suas tabelas. O outro `.bytes`, após normalização XOR 0x63 e GZIP, contém exatamente esses mesmos arquivos de índice e dados.

## Incorporado ao jogo

- Cinco rótulos em português: garrafa de água, garrafa vazia, carne crua, filé suculento e fogueira.
- Máximo 100 para alimento e hidratação; redução de 1 ponto a cada 20 segundos e dano de 1 ponto de vida por segundo para cada necessidade zerada.
- Água: +50 hidratação e devolução de uma garrafa vazia.
- Carne crua: +5 alimento, +5 hidratação e até 8 de vida.
- Filé: +30 alimento, +5 hidratação e até 20 de vida.

O subconjunto está embutido em `src/last-day-data.mjs` e no HTML do APK. Não há download de dados durante a partida.

## Adaptações do protótipo

A vida imediata dos alimentos usa o parâmetro `health_on_use_on_map`; os efeitos temporais de cura do jogo de referência não são reproduzidos. O consumo de necessidades pausa no refúgio. Cozinha e reabastecimento são imediatos, como a fabricação existente: os tempos de referência de 120.000 ms e 600.000 ms não são executados. Custos de construção e combustível e a nutrição das antigas Provisões são ajustes próprios.

## Conteúdo excluído

O APK não incorpora tabelas de loja, pagamentos, publicidade, assinatura, clãs, PvP, conta ou sincronização. Nenhum `.sdat` ou `.fdat` é distribuído. Não são importados dados de sessão, identificadores de conta ou os binários Unity de outros pacotes. O APK não declara permissões, incluindo INTERNET ou BILLING.

O pacote fornecido não contém APK, projeto Gradle/Unity, modelos, texturas ou animações identificáveis. Esses arquivos parciais não bastam para executar ou converter o jogo original. Esta versão é o protótipo Refúgio Zero com os recursos acima implementados.

`IMPORTACAO-LAST-DAY.json` registra os caminhos de origem dos parâmetros, os hashes SHA-256 e o inventário, sem copiar os arquivos de sessão ou o pacote original para o app.
