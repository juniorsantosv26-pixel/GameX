# Recursos da versão 3D

A versão 0.4.0 acrescenta renderização real em perspectiva usando Three.js 0.160.1. A biblioteca está em `vendor/three.module.js` e sua licença MIT em `vendor/THREE-LICENSE.txt`, também incluída no HTML distribuído.

## Recorte do repositório

Origem: https://github.com/apavlinovic/last-day-on-earth

Commit fixo: `3b5bd62b055d3ee50d2ca4a41fa4474f7a6dc09a`.

Foram selecionados 31 arquivos: oito modelos OBJ, oito texturas PNG e quinze ícones PNG. São árvores, pedras, caixa, moto, abrigo, texturas de solo/objetos e ícones de recursos. Cada arquivo foi conferido pelo tamanho, SHA-1 do blob Git e SHA-256. Os caminhos exatos de origem e destino estão em `assets/source-manifest.json`.

O repositório é uma coleção de dados extraídos; não contém um projeto Unity/Android completo para recompilar. A inspeção não identificou licença de distribuição dos recursos de referência. O manifesto registra sua procedência; a licença MIT da biblioteca Three.js se aplica à biblioteca.

## Implementação própria

Personagens são malhas procedurais articuladas, com movimento de braços e pernas e armas próprias. Iluminação, sombras, neblina, câmera, seleção por raio, efeitos de combate e interface são implementados no Refúgio Zero. Não são usadas animações, shaders ou código do jogo de referência.

O parser OBJ triangula faces e preserva normais/UV. O script de preparação incorpora a geometria e PNGs no módulo gerado `src/assets3d.mjs`. O build incorpora esse módulo e Three.js num único HTML, sem CDN ou downloads durante a partida.

A simulação anterior permanece: coordenadas X/Y viram X/Z em escala 1/30 no cenário. O terreno lógico é plano, sem escadas físicas ou navegação por altura. Os três setores têm composição própria. Os dados de sobrevivência do ZIP fornecido permanecem conforme `DADOS-IMPORTADOS.md`.

## Compatibilidade

Normal limita a resolução e usa sombras; Leve reduz a resolução e desativa sombras. A ausência de WebGL ativa o modo 2D identificado. A perda de contexto pausa a partida e tenta salvar localmente; a restauração recupera a renderização.

No host Android, apenas o HTML local e PNGs embutidos são permitidos. O pacote não solicita INTERNET nem outras permissões. Os arquivos de sessão e pacotes binários completos de referência não são distribuídos.

## Evolução 0.5.0

A revisão gráfica acrescenta módulos próprios de superfícies procedurais, personagens, ambiente, efeitos e pós-processo. O solo e a construção usam mapas locais de cor, normal e rugosidade; árvores e vegetação usam instâncias reutilizadas. Folhas com transparência, galhos e grama complementam as copas. As partículas têm limite fixo. O pós-processo usa half-float em GPUs compatíveis e 8 bits como fallback; Leve renderiza diretamente. A distância da câmera e o zoom mudaram, mantendo a orientação dos controles.

Isso não acrescenta mapas completos, animações originais ou física por altura. A comparação com LDOE e a disponibilidade real da playlist estão descritas em REFERENCIAS-VISUAIS.md.
