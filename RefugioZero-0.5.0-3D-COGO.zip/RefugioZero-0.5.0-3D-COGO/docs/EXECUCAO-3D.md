# Execução — plano docs/superpowers/plans/2026-10-15-refugio-3d.md

Projeto isolado em nova pasta; sem repositório Git nesta base. Execução autorizada pelo pedido de avançar até a versão 3D. Plano e especificação acompanham o projeto.

Interfaces: parser OBJ alimenta empacotamento; renderizador usa X/Z em escala 1/30 com as mesmas regras; UI usa render/resize/pickWorld/movement/rotate/setQuality. Android serve a página local e permite decodificação de PNG embutido.

Task 1: complete — testes de geometria, controles e PNG no host escritos antes da implementação; 31 recursos conferidos por hashes Git/SHA-256.

Task 2: complete — renderizador, recursos inline, controles orientados pela câmera e interface integrados. Migração de saves 0.3.0 preservada.

Ruling: a busca antiga por qualquer texto https no HTML foi substituída por verificação de atributos externos e requisições reais bloqueadas no Chromium; a biblioteca contém URLs de documentação sem acessá-las. A fronteira Android permanece sem INTERNET e com URLs remotas bloqueadas.

Task 3: complete — compilação, testes, conferência dos APKs e preparação do pacote final concluídos. 52 testes aprovados. Chromium/WebGL real executado em retrato/paisagem, inclusive perda/restauração do contexto, sem erros e sem requisições externas. Debug, Release e lintVitalRelease concluídos. Assinaturas, versão, permissões, HTML interno e CRC dos dois APKs conferidos.

Correções finais: o manifesto tinha um atributo hardwareAccelerated duplicado, reproduzido com parser XML e corrigido antes da compilação aprovada. A revisão independente não encontrou Critical/Important e apontou dois Minor: mensagem incorreta quando falha o save durante perda de contexto e índices OBJ com barras extras. Ambos reproduzidos RED→GREEN em testes de regressão.

O teste de giro inicialmente dependia de 850 ms de relógio; com WebGL em software e compilação paralela, não garantia quadros suficientes para a interpolação. A espera foi trocada por 30 quadros renderizados, mantendo a mesma exigência de perpendicularidade dos controles. O código de produção não foi alterado para contornar o teste.

Limites: sem aparelho/emulador Android ou interface CoGo; não foram alegados esses testes. Recursos, mapas e animações originais completos permanecem fora do escopo.
