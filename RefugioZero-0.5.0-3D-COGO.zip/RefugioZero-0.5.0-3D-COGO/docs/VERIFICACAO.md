# Verificação — Refúgio Zero 0.5.0

- **62 testes aprovados**, sem falhas ou testes ignorados. Cobrem regras, sobrevivência, combate, fabricação, migração, interface, host Android, parser OBJ, controles, presets, mapas procedurais, personagens e seleção HDR/fallback.
- **Chromium 155.0.8059.79 com WebGL/SwiftShader real**: movimento, giro, três modos gráficos, persistência de qualidade, zoom, viagem, toque, coleta, combate, save/reload, pausa por menu/suspensão e perda/restauração do contexto. Zero erros JavaScript/WebGL e zero solicitações externas observadas.
- Renderização em Alto do refúgio, bosque, distrito e noite com tocha. Imagens internas foram inspecionadas, incluindo retrato e paisagem. Também foi renderizada a versão 0.4.0 com os mesmos estados, posições e viewport para comparação interna; a câmera mudou, portanto não se trata de benchmark controlado.
- **Gradle real**: `:app:assembleDebug :app:assembleRelease :app:lintVitalRelease` terminou com BUILD SUCCESSFUL.
- Debug e Release: assinaturas verificadas, alinhamento/CRC válidos, HTML interno idêntico ao gerado; `br.com.zerox.refugio`, versão 0.5.0/código 6, minSdk26/targetSdk35. Certificado e chave correspondem à 0.4.0.
- Nenhuma permissão Android declarada. Sem bibliotecas nativas ou pacotes Unity, arquivos completos de sessão, `.sdat`, `.fdat` ou traduções completas da referência.
- Os 31 recursos do repositório foram novamente conferidos por tamanho, SHA-1 de blob Git e SHA-256. Os recursos novos são gerados localmente por código, sem CDN.
- Revisão independente sem achados Critical/Important. Dois achados visuais Minor foram reproduzidos e corrigidos com testes: armas sobrepostas dos infectados e perda de realces no pós-processo de 8 bits. O alvo usa half-float quando a GPU oferece renderização/filtragem compatíveis; permanece fallback de 8 bits.

## Limites reais

Não houve teste em aparelho/emulador Android nem interface do Code on the Go. A execução Chromium em Linux não comprova FPS, bateria, temperatura, gestos ou desempenho de GPU de um celular. Os modos gráficos permitem reduzir o custo; não há meta de FPS medida em aparelho nesta entrega.

Os testes VM/Canvas verificam interface/regras e a compatibilidade 2D; o Chromium verifica WebGL real. Os testes de capacidades HDR usam cenários de disponibilidade e fallback; isso não equivale a validar todas as GPUs Android.

O mundo é volumétrico e o terreno lógico é plano. Não há física por altura, animações originais ou mapas completos do LDOE. A superioridade gráfica ao LDOE atual não foi demonstrada. A URL completa da playlist não foi recuperada e seus quadros não foram revistos; ver `REFERENCIAS-VISUAIS.md`.

Gradle emitiu avisos de APIs antigas e incompatibilidade futura com Gradle10; a versão está fixada em 9.6.1/AGP9.3.3. O npm avisou sobre configuração de proxy do ambiente, sem falhas.

## Evidências e uso

`verification.json`, `TESTES.txt`, `BUILD-GRADLE.txt`, `BROWSER.json`, manifesto de assets e registros de importação acompanham o projeto. As imagens internas de inspeção não são distribuídas.

Instale como atualização para preservar o save. Experimente Equilibrado; Alto aumenta o custo; Leve reduz sombras/vegetação/pós-processo. Confira o indicador 3D, gire/aproxime a câmera, viaje, colete, combata e feche/reabra. Limpar dados ou desinstalar remove a partida.
