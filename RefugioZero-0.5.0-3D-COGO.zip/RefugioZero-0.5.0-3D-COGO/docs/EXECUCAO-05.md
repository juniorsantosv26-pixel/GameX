# SDD ledger — plan: docs/superpowers/plans/2026-10-15-visual-05.md

Base isolada: cópia da versão jogável 0.4.0, preservada em commit inicial. Pedido do usuário autoriza implementação completa; sem novas perguntas de aprovação para alterações reversíveis.
Pre-flight: Task1 produz presets e superfícies usados por Task2; nomes e limites coincidem. Task2 mantém API de simulação e acrescenta apenas zoom/efeitos; Task3 usa HTML pré-compilado e chave existentes.
Referências: nome da série recuperado em contexto; vídeo #47 identificado no YouTube e metadados obtidos. Storyboards retornaram página indisponível, não quadros; nenhuma alegação de assistir à playlist inteira. Imagens promocionais atuais da ficha oficial Google Play foram abertas; não equivalem a benchmark de gameplay no aparelho.

Task 1: complete — 57 testes aprovados; presets, superfícies e migração RED→GREEN.
Task 2: em verificação — 58 testes aprovados e Chromium real aprovou três modos, zoom, giro, toque, coleta, combate, pausa, save e restauração WebGL, sem erros/rede. Inspeção visual mostrou copas excessivamente lisas; acrescentadas folhas locais com transparência e tufos de grama mais ricos antes da revisão final.

Revisão independente: sem Critical/Important; dois achados visuais Minor foram reproduzidos por testes e corrigidos dentro do escopo gráfico autorizado: infectados exibiam armas sobrepostas; alvo de pós-processo usava 8 bits antes do ACES. Agora infectados ficam desarmados e a renderização usa half-float quando a GPU suporta, com fallback de 8 bits. Sem nova rodada de revisão.

Task 2: complete — 62 testes aprovados; Chromium real verificou todos os modos/zoom, persistência, cenários de dia/noite e recuperação de contexto; sem erros nem solicitações externas. Copas refinadas e decoração removida do piso do abrigo após inspeção.
Final: limites mantidos — sem avaliação em Android físico/CoGo; sem certificação de superioridade ao LDOE. Metadados de vídeo e imagens promocionais não foram tratados como reprodução da playlist.

Task 3: complete — Debug, Release e lintVitalRelease compilados, assinatura/alinhamento/CRC/HTML/permissões conferidos; 31 hashes de assets e chave anterior confirmados. Instruções e evidências atualizadas. Arquivos finais preparados para entrega persistente.
Finalização: fonte preservada no branch local visual-0.5 para o pacote solicitado; sem integração com repositório remoto. Limitações de aparelho/CoGo e comparação comercial explicitadas.
