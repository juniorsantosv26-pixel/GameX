import {readFileSync,writeFileSync,mkdirSync,renameSync} from 'node:fs';
import {buildSync} from 'esbuild';
import {prepareAssets} from './prepare-assets.mjs';
prepareAssets();
const license=readFileSync('vendor/THREE-LICENSE.txt','utf8');
const result=buildSync({entryPoints:['src/game.mjs'],bundle:true,write:false,format:'iife',target:'chrome108',minifyWhitespace:true,minifySyntax:true,minifyIdentifiers:false,legalComments:'none',banner:{js:'/*! Three.js r160.1\n'+license+'*/'}});
const script=result.outputFiles[0].text;new Function(script);
const css=readFileSync('src/style.css','utf8');
const html=readFileSync('src/index.html','utf8').replace('/*STYLE*/',()=>css).replace('/*SCRIPT*/',()=>script);
function atomic(path,bytes){const temp=path+'.'+process.pid+'.tmp';writeFileSync(temp,bytes);renameSync(temp,path);}
mkdirSync('dist',{recursive:true});mkdirSync('app/src/main/assets',{recursive:true});
atomic('dist/index.html',html);atomic('dist/refugio-zero-offline.html',html);
atomic('app/src/main/assets/game.html',html.replace('<html lang="pt-BR">','<html lang="pt-BR" data-platform="android">'));
console.log('Built Refúgio Zero 0.5.0 3D — '+Buffer.byteLength(html)+' bytes, Three.js and all assets embedded.');
