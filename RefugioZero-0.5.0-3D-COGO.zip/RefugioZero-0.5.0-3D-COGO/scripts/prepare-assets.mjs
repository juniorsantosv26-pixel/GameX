import {readFileSync,writeFileSync} from 'node:fs';
import {parseOBJ} from '../src/obj.mjs';
export function prepareAssets(){
 const manifest=JSON.parse(readFileSync('assets/source-manifest.json','utf8'));
 const data={models:{},textures:{},icons:{}};
 for(const e of manifest.entries){
  const bytes=readFileSync('assets/'+e.local);
  if(e.kind==='models')data.models[e.id]=parseOBJ(bytes.toString('utf8'));
  else data[e.kind][e.id]='data:image/png;base64,'+bytes.toString('base64');
 }
 const text='// Generated locally from the verified assets in assets/source-manifest.json.\nexport const assets3D='+JSON.stringify(data)+';\n';
 writeFileSync('src/assets3d.mjs',text);return data;
}
