import assert from 'node:assert/strict';
import {createServer} from 'node:http';
import {readFileSync,mkdirSync,writeFileSync,existsSync} from 'node:fs';
import {createRequire} from 'node:module';
import {createGame} from '../src/core.mjs';
const require=createRequire(import.meta.url);
let chromium;
try{({chromium}=require('playwright'));}catch{({chromium}=createRequire((process.env.CODEX_PRIMARY_RUNTIME_NODE_MODULES||'/opt/codex/runtimes/codex-primary-runtime/dependencies/node/node_modules')+'/qa.cjs')('playwright'));}
const baseline=process.env.BASELINE_HTML;
const server=createServer((req,res)=>{if(req.url==='/'||req.url==='/game.html'||req.url==='/baseline'&&baseline){res.setHeader('Content-Type','text/html; charset=utf-8');res.end(readFileSync(req.url==='/baseline'?baseline:'app/src/main/assets/game.html'));}else{res.statusCode=404;res.end();}});
await new Promise(r=>server.listen(0,'127.0.0.1',r));
const base='http://127.0.0.1:'+server.address().port;
const browser=await chromium.launch({headless:true,...(process.env.CHROME_EXECUTABLE?{executablePath:process.env.CHROME_EXECUTABLE}:{}),args:['--no-sandbox','--enable-webgl','--use-angle=swiftshader','--enable-unsafe-swiftshader']});
const errors=[],external=[],results=[];mkdirSync('artifacts',{recursive:true});
async function pageFor(size,save,path='/game.html'){
 const context=await browser.newContext({...size,deviceScaleFactor:1});
 await context.route('**/*',route=>{const u=route.request().url();if(u.startsWith(base+'/')||u.startsWith('data:'))return route.continue();external.push(u);return route.abort();});
 const page=await context.newPage();page.on('pageerror',e=>errors.push(String(e)));
 page.on('console',m=>{if(m.type()==='error'&&!m.text().includes('favicon'))errors.push(m.text());});
 if(save)await context.addInitScript(s=>{localStorage.setItem('refugio-zero-01',s);localStorage.setItem('refugio-zero-01-started','1');},JSON.stringify(save));
 await page.goto(base+path);
 assert.match(await page.locator('body').innerText(),/3D.*WebGL/,'a real WebGL renderer must initialize');
 await page.waitForTimeout(600);
 return {page,context};
}
// Serialize production state even while a modal occupies the browser top layer.
const saved=async p=>{await p.evaluate(()=>document.querySelector('#save').click());return JSON.parse(await p.evaluate(()=>localStorage.getItem('refugio-zero-01')));};
// Camera easing advances per rendered frame; software WebGL can be slower than wall time.
const frames=async(p,n)=>p.evaluate(n=>new Promise(resolve=>{const next=()=>--n>0?requestAnimationFrame(next):resolve();requestAnimationFrame(next);}),n);
async function step(p,key,ms=260){await p.keyboard.down(key);await p.waitForTimeout(ms);await p.keyboard.up(key);return saved(p);}
try{
 const {page,context}=await pageFor({viewport:{width:1280,height:800}});
 await page.locator('#start').click();const a=await saved(page);const b=await step(page,'d');assert.ok(Math.hypot(b.player.x-a.player.x,b.player.y-a.player.y)>8);
 await page.locator('#rotate-camera').click();await frames(page,30);const c=await saved(page);const d=await step(page,'d');
 const u={x:b.player.x-a.player.x,y:b.player.y-a.player.y},v={x:d.player.x-c.player.x,y:d.player.y-c.player.y};
 assert.ok(Math.abs(u.x*v.x+u.y*v.y)/(Math.hypot(u.x,u.y)*Math.hypot(v.x,v.y))<.25,'directional controls must follow the rotated camera: '+JSON.stringify({u,v}));
 assert.equal(await page.locator('#quality').innerText(),'Equilibrado');
 await page.locator('#quality').click();assert.equal(await page.locator('#quality').innerText(),'Alto');await frames(page,3);
 await page.locator('#quality').click();assert.equal(await page.locator('#quality').innerText(),'Leve');await frames(page,3);
 await page.locator('#quality').click();assert.equal(await page.locator('#quality').innerText(),'Equilibrado');await frames(page,3);
 await page.locator('#quality').click();await page.reload();await frames(page,3);assert.equal(await page.locator('#quality').innerText(),'Alto');
 await page.locator('#quality').click();await page.locator('#quality').click();assert.equal(await page.locator('#quality').innerText(),'Equilibrado');
 const zoomBefore=await page.locator('#zoom-camera').innerText();await page.locator('#zoom-camera').click();await frames(page,12);assert.notEqual(await page.locator('#zoom-camera').innerText(),zoomBefore);
 await page.screenshot({path:'artifacts/3d-desktop.png'});
 await page.locator('[data-open="map"]:visible').first().click();await page.locator('[data-travel="forest"]').click();assert.equal((await saved(page)).zone,'forest');
 const tapStart=await saved(page),canvas=page.locator('#world');await canvas.click({position:{x:360,y:430}});await frames(page,8);const tapEnd=await saved(page);
 assert.ok(Math.hypot(tapEnd.player.x-tapStart.player.x,tapEnd.player.y-tapStart.player.y)>8,'a tap on the scene must move the player');
 const before=await saved(page);await page.reload();await page.waitForTimeout(400);assert.equal((await saved(page)).zone,before.zone);
 results.push('desktop: WebGL, movement, camera rotation, three graphics modes, zoom, travel, tap movement and reload');
 await context.close();
 const g=createGame();g.version='0.4.0';g.zone='forest';g.player.x=g.world.forest.nodes[0].x;g.player.y=g.world.forest.nodes[0].y;g.weapon='pistol';g.built.bench=true;
 const mobile=await pageFor({viewport:{width:390,height:844},isMobile:true,hasTouch:true},g);const p=mobile.page;
 await p.locator('#interact').click();assert.ok((await saved(p)).bag.wood>=7,'resource collection must work in the 3D scene');
 await p.keyboard.down(' ');await p.waitForTimeout(900);await p.keyboard.up(' ');assert.ok((await saved(p)).ammo<24,'combat must consume ammunition');
 await p.locator('[data-open="inventory"]:visible').first().click();const frozen=await saved(p);await p.waitForTimeout(350);const paused=await saved(p);assert.equal(paused.survival.clock,frozen.survival.clock);await p.locator('#close-panel').click();
 await p.screenshot({path:'artifacts/3d-mobile.png'});
 await p.setViewportSize({width:844,height:390});await p.waitForTimeout(400);await p.screenshot({path:'artifacts/3d-landscape.png'});
 const hasContext=await p.evaluate(()=>{const c=document.querySelector('#world');return !!(c.getContext('webgl2')||c.getContext('webgl'));});assert.ok(hasContext);
 await p.evaluate(()=>window.dispatchEvent(new Event('refugio:pause')));const initial=await saved(p);await p.waitForTimeout(350);assert.equal((await saved(p)).survival.clock,initial.survival.clock);await p.evaluate(()=>window.dispatchEvent(new Event('refugio:resume')));
 await p.evaluate(()=>{const c=document.querySelector('#world'),gl=c.getContext('webgl2')||c.getContext('webgl');window.__qaLost=gl.getExtension('WEBGL_lose_context');window.__qaLost.loseContext();});
 await p.waitForTimeout(200);assert.match(await p.locator('#engine-mode').innerText(),/Recuperando/);
 const lostState=await saved(p);await p.waitForTimeout(300);assert.equal((await saved(p)).survival.clock,lostState.survival.clock);
 await p.evaluate(()=>window.__qaLost.restoreContext());await p.waitForFunction(()=>document.querySelector('#engine-mode').textContent==='3D · WebGL');await p.waitForTimeout(400);
 results.push('mobile: migrated save, collect, combat, modal/native pause, portrait/landscape WebGL, context loss and recovery');
 await mobile.context.close();
 for(const [zone,clock] of [['base',0],['forest',0],['district',0],['forest',180]]){
  const state=createGame();state.zone=zone;state.player.x=600;state.player.y=zone==='base'?570:400;
  for(const key of Object.keys(state.built))state.built[key]=true;state.won=true;state.survival.clock=clock;state.survival.torch=clock>150;
  const view=await pageFor({viewport:{width:1000,height:700}},state);const shot=view.page;
  await shot.evaluate(()=>window.dispatchEvent(new Event('refugio:pause')));
  await shot.locator('#quality').click();assert.equal(await shot.locator('#quality').innerText(),'Alto');await frames(shot,5);
  const name=clock?'night':zone;await shot.screenshot({path:'artifacts/showcase-'+name+'.png'});await view.context.close();
  if(!clock&&baseline&&existsSync(baseline)){
   state.version='0.4.0';const old=await pageFor({viewport:{width:1000,height:700}},state,'/baseline');await old.page.evaluate(()=>window.dispatchEvent(new Event('refugio:pause')));await frames(old.page,3);await old.page.screenshot({path:'artifacts/baseline-'+name+'.png'});await old.context.close();
  }
 }
 results.push('scenes: refuge, forest, district and torch-lit night rendered in Alto; fixed-state comparison with 0.4.0 when supplied');
 assert.deepEqual(external,[],'the game must not request external resources');assert.deepEqual(errors,[],'no browser/JavaScript/WebGL errors');
 writeFileSync('artifacts/browser-results.json',JSON.stringify({browser:await browser.version(),passed:results,errors,external,androidDeviceTested:false},null,2));
 console.log(JSON.stringify({passed:results,errors,external}));
}finally{await browser.close();await new Promise(r=>server.close(r));}
