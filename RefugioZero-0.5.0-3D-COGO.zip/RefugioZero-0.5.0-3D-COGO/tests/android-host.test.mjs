import test from 'node:test';
import assert from 'node:assert/strict';
import {mkdtempSync,writeFileSync,rmSync} from 'node:fs';
import {tmpdir} from 'node:os';
import {join,resolve} from 'node:path';
import {execFileSync} from 'node:child_process';

test('WebView compatibility rejects old or unidentified engines and accepts Chromium 108 or newer',()=>{
 const dir=mkdtempSync(join(tmpdir(),'refugio-webview-'));
 try{
  const runner=join(dir,'WebViewSupportTest.java');
  writeFileSync(runner,`package br.com.zerox.refugio;
public final class WebViewSupportTest {
 public static void main(String[] args) {
  for (String version : new String[]{"108.0.5359.79", "140.0.7339.53", "150.0.0.0"}) {
   if (!WebViewSupport.supports(version)) throw new AssertionError("Must support "+version);
  }
  for (String version : new String[]{null, "", "107.0.5304.141", "93.0.0.0", "60.0.3112.116", "old", "-108.0", "999999999999999999.0"}) {
   if (WebViewSupport.supports(version)) throw new AssertionError("Must block "+version);
  }
  System.out.println("WebView compatibility: 11 cases passed");
 }
}`);
  execFileSync('java',['com.sun.tools.javac.Main','--release','8','-d',dir,
   resolve('app/src/main/java/br/com/zerox/refugio/WebViewSupport.java'),runner],{stdio:'pipe'});
  const output=execFileSync('java',['-cp',dir,'br.com.zerox.refugio.WebViewSupportTest'],{encoding:'utf8'});
  assert.ok(output.includes('11 cases passed'));
 }finally{rmSync(dir,{recursive:true,force:true});}
});
