import test from 'node:test';
import assert from 'node:assert/strict';
import {existsSync,readFileSync} from 'node:fs';
const obj=existsSync('src/obj.mjs')?await import('../src/obj.mjs'):{};
const view=existsSync('src/view-math.mjs')?await import('../src/view-math.mjs'):{};

test('OBJ quads become finite triangles with generated normals and correct bounds',()=>{
 assert.equal(typeof obj.parseOBJ,'function','OBJ importer is required');
 const g=obj.parseOBJ('v 0 0 0\nv 2 0 0\nv 2 2 0\nv 0 2 0\nf 1 2 3 4');
 assert.equal(g.triangles,2);assert.equal(g.positions.length,18);assert.equal(g.normals.length,18);
 assert.deepEqual(g.bounds,{min:[0,0,0],max:[2,2,0]});
 assert.deepEqual(g.normals.slice(0,3),[0,0,1]);
 assert.deepEqual(g.positions.slice(9),[0,0,0,2,2,0,0,2,0]);
});
test('OBJ negative indices preserve UV coordinates and supplied normals',()=>{
 assert.equal(typeof obj.parseOBJ,'function');
 const g=obj.parseOBJ('v 0 0 0\nv 1 0 0\nv 0 1 0\nvt 0 0\nvt 1 0\nvt 0 1\nvn 0 0 1\nf -3/1/1 -2/2/1 -1/3/1');
 assert.deepEqual(g.uvs,[0,0,1,0,0,1]);assert.deepEqual(g.normals,[0,0,1,0,0,1,0,0,1]);
});
test('OBJ rejects missing geometry, invalid indices and non-finite vertices',()=>{
 assert.equal(typeof obj.parseOBJ,'function');
 for(const s of ['', 'v NaN 0 0\nf 1 1 1','v 0 0 0\nf 0 1 1','v 0 0 0\nf 1 2 3','v 0 0 0\nf 1 1','v Infinity 0 0\nf 1 1 1'])assert.throws(()=>obj.parseOBJ(s));
});
test('OBJ rejects extra empty slash components in face indices',()=>{
 assert.throws(()=>obj.parseOBJ('v 0 0 0\nv 1 0 0\nv 0 1 0\nf 1/// 2/// 3///'),/Invalid OBJ index/);
});
test('camera-relative movement rotates correctly and preserves analog control length',()=>{
 assert.equal(typeof view.screenMovement,'function','camera-relative controls are required');
 assert.deepEqual(view.screenMovement(1,0,0),{x:1,y:0});
 const right=view.screenMovement(1,0,Math.PI/2);assert.ok(Math.abs(right.x)<1e-10);assert.equal(right.y,-1);
 const down=view.screenMovement(0,1,Math.PI/2);assert.equal(down.x,1);assert.ok(Math.abs(down.y)<1e-10);
 const analog=view.screenMovement(.3,.4,.7);assert.ok(Math.abs(Math.hypot(analog.x,analog.y)-.5)<1e-10);
});
test('world coordinates round-trip through scene coordinates at the chosen meter scale',()=>{
 assert.equal(typeof view.worldToScene,'function');assert.equal(typeof view.sceneToWorld,'function');
 assert.deepEqual(view.worldToScene({x:600,y:570}),{x:20,z:19});
 assert.deepEqual(view.sceneToWorld({x:20,z:19}),{x:600,y:570});
});
