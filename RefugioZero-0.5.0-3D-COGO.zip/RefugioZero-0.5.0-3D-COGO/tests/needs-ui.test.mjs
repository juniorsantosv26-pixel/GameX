import test from 'node:test';
import assert from 'node:assert/strict';
import {execFileSync} from 'node:child_process';
import {harness} from './support/harness.mjs';
import {createGame} from '../src/core.mjs';
execFileSync(process.execPath,['scripts/build.mjs']);

test('mobile inventory consumes the imported water item and updates the visible needs and local save',()=>{
 const g=createGame();g.survival.thirst=30;g.bag={water:2};
 const h=harness({initialSave:JSON.stringify(g),width:390,height:640});
 assert.ok(h.ids.has('thirst-value'),'thirst must be visible on the game HUD');
 h.click(h.find('open','inventory'));h.click(h.find('use','water'));
 const s=JSON.parse(h.store.get('refugio-zero-01'));assert.equal(s.survival.thirst,80);assert.equal(s.bag.water,1);assert.equal(s.bag.emptyBottle,1);
 assert.ok(h.ids.get('thirst-value').textContent.includes('80'));assert.ok(h.ids.get('inventory-grid').innerHTML.includes('Garrafa Vazia'));
});

test('native pause and an open inventory freeze hunger and thirst, then resume continues depletion',()=>{
 const g=createGame();g.zone='forest';g.world.forest.enemies=[];
 const h=harness({initialSave:JSON.stringify(g)});h.advance(1);h.windowEvent('refugio:pause',{});
 const first=JSON.parse(h.store.get('refugio-zero-01'));h.advance(3);h.click('save');
 assert.equal(JSON.parse(h.store.get('refugio-zero-01')).survival.hunger,first.survival.hunger);
 h.windowEvent('refugio:resume',{});h.advance(1);h.click('save');
 assert.ok(JSON.parse(h.store.get('refugio-zero-01')).survival.hunger<first.survival.hunger);
 h.click(h.find('open','inventory'));h.click('save');const paused=JSON.parse(h.store.get('refugio-zero-01'));
 h.advance(2);h.click('save');assert.equal(JSON.parse(h.store.get('refugio-zero-01')).survival.thirst,paused.survival.thirst);
});
