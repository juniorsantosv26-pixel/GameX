import test from 'node:test';
import assert from 'node:assert/strict';
import {execFileSync} from 'node:child_process';
import {harness} from './support/harness.mjs';
import {createGame} from '../src/core.mjs';
execFileSync(process.execPath,['scripts/build.mjs']);

test('real UI buttons open inventory and deposit favourited supplies correctly',()=>{
 const h=harness();h.click('start');h.click(h.find('open','inventory'));
 assert.equal(h.ids.get('panel').open,true);assert.ok(h.ids.get('inventory-grid').innerHTML.includes('Kit médico'));
 h.click(h.find('action','deposit'));const s=JSON.parse(h.store.get('refugio-zero-01'));
 assert.equal(s.bag.medkit,3);assert.equal(s.store.wood,2);assert.equal(s.store.scrap,2);
 assert.ok(h.ids.get('panel-feedback').textContent.includes('guardados'));
});
test('map action changes sector and modal pauses keyboard movement',()=>{
 const h=harness();h.click('start');h.click(h.find('open','map'));h.click(h.find('travel','forest'));
 assert.equal(h.ids.get('zone-title').textContent,'Bosque cinzento');const before=h.ids.get('coordinates').textContent;
 h.key('d');h.advance(1);h.key('d',true);assert.notEqual(h.ids.get('coordinates').textContent,before);
 h.click(h.find('open','inventory'));const paused=h.ids.get('coordinates').textContent;h.key('d');h.advance(2);assert.equal(h.ids.get('coordinates').textContent,paused);
 h.render('artifacts/forest-desktop.png');
});
test('mobile-size canvas can initialize and render the playable scene',()=>{
 const h=harness({width:390,height:640});h.click('start');h.advance(.3);h.render('artifacts/refuge-mobile.png');assert.equal(h.ids.get('zone-title').textContent,'Refúgio');
});
test('blocked storage is reported while the game remains playable',()=>{
 const h=harness({storageBlocked:true});h.click('start');h.click('save');assert.equal(h.ids.get('save-status').textContent,'Sem salvamento');assert.ok(h.ids.get('toast').textContent.includes('bloqueou'));h.advance(.2);
});
test('GPU loss does not claim a successful save when storage is blocked',()=>{
 const h=harness({storageBlocked:true});h.click('start');h.ids.get('world').emit('webglcontextlost');
 assert.equal(h.ids.get('save-status').textContent,'Sem salvamento');
 assert.ok(!h.ids.get('toast').textContent.includes('progresso foi salvo'));
 assert.ok(h.ids.get('toast').textContent.includes('salvamento'));
});
test('graphics preference is separate from game progress and invalid values recover',()=>{
 const g=createGame();g.bag.wood=9;
 const h=harness({initialSave:JSON.stringify(g),initialStorage:{'refugio-zero-graphics-v1':'__proto__'}});
 assert.equal(h.ids.get('quality').textContent,'Equilibrado');h.click('save');
 assert.equal(JSON.parse(h.store.get('refugio-zero-01')).bag.wood,9);
});
test('saved high quality is restored without WebGL or cloud requirements',()=>{
 const h=harness({initialStorage:{'refugio-zero-graphics-v1':'high'}});
 assert.equal(h.ids.get('quality').textContent,'Alto');
 assert.equal(h.ids.get('engine-mode').textContent,'2D · Compatibilidade');
});
test('lifting a joystick finger does not release a separately held attack finger',()=>{
 const g=createGame();g.zone='forest';g.player.x=450;g.player.y=220;g.weapon='pistol';
 const h=harness({initialSave:JSON.stringify(g),width:390,height:640});h.ids.get('attack').emit('pointerdown',{pointerId:11});h.advance(.4);
 const before=JSON.parse(h.store.get('refugio-zero-01')).ammo;
 h.windowEvent('pointerup',{pointerId:22});h.advance(.5);
 const after=JSON.parse(h.store.get('refugio-zero-01')).ammo;assert.ok(after<before,'attack finger 11 must remain held');
 h.windowEvent('pointerup',{pointerId:11});h.advance(.5);assert.equal(JSON.parse(h.store.get('refugio-zero-01')).ammo,after);
});
test('automatic later save failure provides visible persistent feedback on mobile',()=>{
 const h=harness({width:390,height:640});h.click('start');h.blockStorage();h.advance(5.2);
 assert.equal(h.ids.get('save').textContent,'!');assert.ok(h.ids.get('toast').textContent.includes('bloqueou'));
});

test('native Android pause saves the game and freezes simulation until resume',()=>{
 const h=harness();h.click('start');h.click(h.find('open','map'));h.click(h.find('travel','forest'));
 h.key('d');h.advance(.2);h.windowEvent('refugio:pause',{});
 const paused=JSON.parse(h.store.get('refugio-zero-01'));h.key('d');h.advance(3);
 h.click('save');const still=JSON.parse(h.store.get('refugio-zero-01'));
 assert.equal(still.player.x,paused.player.x);assert.equal(still.survival.clock,paused.survival.clock);
 h.windowEvent('refugio:resume',{});h.key('d');h.advance(.5);h.click('save');
 assert.ok(JSON.parse(h.store.get('refugio-zero-01')).player.x>paused.player.x);
});

test('torch touch button updates its state and map shows advisory preparation feedback',()=>{
 const g=createGame();g.survival={clock:180,fuel:10,torch:false};g.player.hp=30;
 const h=harness({initialSave:JSON.stringify(g),width:390,height:640});h.click('torch');
 assert.equal(h.ids.get('torch')['aria-pressed'],'true');
 h.click(h.find('open','map'));assert.ok(h.ids.get('panel-body').innerHTML.includes('PREPARAÇÃO'));
 assert.ok(h.ids.get('panel-body').innerHTML.includes('vida'));
});

test('Android Back closes a game panel before allowing the host to ask about exiting',()=>{
 const h=harness();h.click('start');assert.equal(h.androidBack(),false);
 h.click(h.find('open','inventory'));assert.equal(h.ids.get('panel').open,true);
 assert.equal(h.androidBack(),true);assert.equal(h.ids.get('panel').open,false);
 assert.equal(h.androidBack(),false);
});
