import test from 'node:test';
import assert from 'node:assert/strict';
import * as core from '../src/core.mjs';

const near=(a,b)=>assert.ok(Math.abs(a-b)<1e-7,`${a} should be ${b}`);
const expedition=()=>{const g=core.createGame();g.zone='forest';g.world.forest.enemies=[];return g;};

test('needs use the supplied twenty-second rate outside the refuge, with bounded frame gaps',()=>{
 const g=expedition();
 for(let i=0;i<200;i++)core.tick(g,.1);
 near(g.survival.hunger,99);near(g.survival.thirst,99);
 g.zone='base';for(let i=0;i<200;i++)core.tick(g,.1);
 near(g.survival.hunger,99);near(g.survival.thirst,99);
 g.zone='forest';core.tick(g,3600);near(g.survival.hunger,98.995);
});

test('starvation bypasses armor and rescue restores needs while preserving the lost load',()=>{
 const g=expedition();g.survival.hunger=0;g.survival.thirst=0;
 for(let i=0;i<10;i++)core.tick(g,.1);
 near(g.player.hp,98);assert.equal(g.durability.armor,100);
 g.player.hp=.05;g.bag={water:1};const events=core.tick(g,.1);
 assert.ok(events.some(e=>e.type==='death'));assert.equal(g.zone,'base');
 assert.equal(g.survival.hunger,100);assert.equal(g.survival.thirst,100);
 assert.equal(g.drop.items.water,1);
});

test('drinking replaces one full bottle with an empty one even in a full backpack',()=>{
 assert.equal(typeof core.consume,'function','consumption must be implemented');
 const g=core.createGame();g.survival.thirst=40;g.bag={wood:59,water:1};
 assert.equal(core.consume(g,'water').ok,true);assert.equal(g.survival.thirst,90);
 assert.equal(g.bag.water,undefined);assert.equal(g.bag.emptyBottle,1);assert.equal(core.cargo(g),60);
 const after=JSON.stringify(g);assert.equal(core.consume(g,'water').ok,false);assert.equal(JSON.stringify(g),after);
});

test('food applies the imported nutrition and healing, caps values and never wastes a full-needs item',()=>{
 assert.equal(typeof core.consume,'function');
 const g=core.createGame();g.survival.hunger=50;g.survival.thirst=60;g.player.hp=65;g.bag={cookedMeat:2,rawMeat:1};
 assert.equal(core.consume(g,'cookedMeat').ok,true);
 assert.equal(g.survival.hunger,80);assert.equal(g.survival.thirst,65);assert.equal(g.player.hp,85);
 assert.equal(core.consume(g,'rawMeat').ok,true);assert.equal(g.survival.hunger,85);assert.equal(g.player.hp,93);
 assert.equal(core.consume(g,'cookedMeat').ok,true);assert.equal(g.survival.hunger,100);assert.equal(g.player.hp,100);
 g.survival.thirst=100;g.bag.water=1;const before=JSON.stringify(g);
 assert.equal(core.consume(g,'water').ok,false);assert.equal(JSON.stringify(g),before);
 for(const id of ['wood','__proto__',['water'],null])assert.equal(core.consume(g,id).ok,false);
});

test('campfire and rain collector enable local recipes without allowing prerequisite bypasses',()=>{
 const g=core.createGame();g.bag={};g.store={wood:30,stone:20,cloth:10,rawMeat:2,emptyBottle:2};
 const before=JSON.stringify(g);assert.equal(core.craft(g,'cook').ok,false);assert.equal(JSON.stringify(g),before);
 assert.equal(core.craft(g,'bonfire').ok,true);assert.equal(core.craft(g,'cook').ok,true);
 assert.equal(g.bag.cookedMeat,1);assert.equal(g.store.rawMeat,1);
 assert.equal(core.craft(g,'refillWater').ok,false);assert.equal(core.craft(g,'bench').ok,true);
 assert.equal(core.craft(g,'rainCollector').ok,true);assert.equal(core.craft(g,'refillWater').ok,true);
 assert.equal(g.bag.water,1);assert.equal(g.store.emptyBottle,1);
 const done=JSON.stringify(g);assert.equal(core.craft(g,'rainCollector').ok,false);assert.equal(JSON.stringify(g),done);
 g.zone='forest';assert.equal(core.craft(g,'cook').ok,false);
});

test('migration preserves a 0.2.1 expedition and defaults absent needs without duplicating starting supplies',()=>{
 const g=core.createGame();g.version='0.2.1';g.built.bench=true;g.built.pack=true;g.bag={wood:85};g.stats.kills=17;
 delete g.survival.hunger;delete g.survival.thirst;
 const r=core.restore(JSON.stringify(g));assert.equal(r.bag.wood,85);assert.equal(r.bag.water,undefined);
 assert.equal(r.stats.kills,17);assert.equal(r.built.pack,true);assert.equal(r.survival.hunger,100);assert.equal(r.survival.thirst,100);
 const roundtrip=core.createGame();roundtrip.survival.hunger=12.5;roundtrip.survival.thirst=30;
 roundtrip.built.bonfire=true;roundtrip.built.bench=true;roundtrip.built.rainCollector=true;roundtrip.bag={rawMeat:3,emptyBottle:2};
 const loaded=core.restore(JSON.stringify(roundtrip));assert.equal(loaded.survival.hunger,12.5);assert.equal(loaded.bag.rawMeat,3);assert.equal(loaded.bag.emptyBottle,2);assert.equal(loaded.built.bonfire,true);assert.equal(loaded.built.rainCollector,true);
 roundtrip.survival.hunger=-9;roundtrip.survival.thirst='cheia';
 const safe=core.restore(JSON.stringify(roundtrip));assert.equal(safe.survival.hunger,0);assert.equal(safe.survival.thirst,100);
});

test('expeditions supply raw food and bottles that are collectible, renewable and restorable',()=>{
 const g=core.createGame();core.travel(g,'forest');
 const meat=g.world.forest.nodes.find(n=>n.item==='rawMeat');assert.ok(meat,'forest needs a local meat source');
 g.player.x=meat.x;g.player.y=meat.y;assert.equal(core.collect(g,meat.id).ok,true);assert.ok(g.bag.rawMeat>0);
 const loaded=core.restore(JSON.stringify(g));assert.equal(loaded.world.forest.nodes.find(n=>n.id===meat.id).amount,0);
 for(const n of g.world.forest.nodes)n.amount=0;g.world.forest.enemies=[];
 assert.equal(core.travel(g,'base').ok,true);assert.equal(core.travel(g,'forest').ok,true);
 assert.ok(g.world.forest.nodes.some(n=>n.item==='rawMeat'&&n.amount>0));
 assert.ok(g.world.district.nodes.some(n=>n.item==='water'&&n.amount>0));
});


test('3D migration preserves the complete 0.3.0 survival inventory and facilities',()=>{
 const g=core.createGame();g.version='0.3.0';g.zone='district';g.built.bench=true;g.built.bonfire=true;g.built.rainCollector=true;g.built.pack=true;
 g.bag={wood:70,water:3,rawMeat:4,emptyBottle:2};g.store={cookedMeat:8};g.survival.hunger=37.5;g.survival.thirst=62;g.stats.kills=19;
 const r=core.restore(JSON.stringify(g));assert.equal(r.version,core.VERSION);assert.equal(r.zone,'district');assert.deepEqual(r.bag,g.bag);assert.deepEqual(r.store,g.store);
 assert.equal(r.built.rainCollector,true);assert.equal(r.built.bonfire,true);assert.equal(r.survival.hunger,37.5);assert.equal(r.survival.thirst,62);assert.equal(r.stats.kills,19);
});
