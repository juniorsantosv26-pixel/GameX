import test from 'node:test';
import assert from 'node:assert/strict';
import {existsSync} from 'node:fs';
import {VERSION,createGame,restore} from '../src/core.mjs';
const config=existsSync('src/visual-config.mjs')?await import('../src/visual-config.mjs'):{};
const surfaces=existsSync('src/surface-data.mjs')?await import('../src/surface-data.mjs'):{};
const characters=existsSync('src/character3d.mjs')?await import('../src/character3d.mjs'):{};
const post=existsSync('src/postfx.mjs')?await import('../src/postfx.mjs'):{};
import {HalfFloatType,UnsignedByteType} from '../vendor/three.module.js';

test('graphics modes have bounded costs and invalid preferences recover safely',()=>{
 assert.equal(typeof config.qualityProfile,'function');
 const a=config.qualityProfile('balanced'),b=config.qualityProfile('high'),c=config.qualityProfile('light');
 assert.equal(a.label,'Equilibrado');assert.equal(b.label,'Alto');assert.equal(c.label,'Leve');
 assert.equal(a.pixelRatio,1.25);assert.equal(b.pixelRatio,1.75);assert.equal(c.pixelRatio,1);
 assert.equal(a.shadowSize,1024);assert.equal(b.shadowSize,2048);assert.equal(c.shadowSize,0);
 assert.equal(c.post,false);assert.ok(b.grass>a.grass&&a.grass>c.grass);
 for(const v of [undefined,null,'__proto__','cinema',{},42])assert.equal(config.qualityProfile(v).id,'balanced');
});
test('quality cycle visits all modes and zoom never returns non-finite distances',()=>{
 assert.equal(typeof config.nextQuality,'function');assert.equal(typeof config.cameraZoom,'function');
 assert.deepEqual(['balanced','high','light'].map(config.nextQuality),['high','light','balanced']);
 assert.equal(config.nextQuality('bad'),'high');
 assert.deepEqual([0,1,2,3].map(config.cameraZoom),[1,.82,1.17,1]);
 for(const n of [NaN,Infinity,null])assert.equal(config.cameraZoom(n),1);
});
test('surface maps are deterministic opaque RGBA with usable outward normals',()=>{
 assert.equal(typeof surfaces.surfaceData,'function');
 for(const kind of ['grass','dirt','stone','wood','concrete']){
  const a=surfaces.surfaceData(kind,32,17),b=surfaces.surfaceData(kind,32,17);
  assert.equal(a.size,32);assert.deepEqual(a.color,b.color);assert.deepEqual(a.normal,b.normal);
  for(const key of ['color','normal','roughness']){
   assert.equal(a[key].length,32*32*4);
   for(let i=3;i<a[key].length;i+=4)assert.equal(a[key][i],255);
  }
  for(let i=2;i<a.normal.length;i+=4)assert.ok(a.normal[i]>=180);
  assert.notDeepEqual(a.color,surfaces.surfaceData(kind,32,18).color);
 }
 assert.throws(()=>surfaces.surfaceData('grass',Infinity),RangeError);
 assert.throws(()=>surfaces.surfaceData('grass',2048),RangeError);
});
test('scene scatter stays deterministic, finite and inside bounds at its capacity limit',()=>{
 assert.equal(typeof surfaces.deterministicScatter,'function');
 const bounds={minX:1,maxX:39,minZ:2,maxZ:26};
 const a=surfaces.deterministicScatter(12,9,bounds);
 assert.equal(a.length,12);assert.deepEqual(a,surfaces.deterministicScatter(12,9,bounds));
 assert.notDeepEqual(a,surfaces.deterministicScatter(12,10,bounds));
 for(const p of a){assert.ok(p.x>=1&&p.x<=39&&p.z>=2&&p.z<=26);assert.ok(Number.isFinite(p.rotation));}
 assert.equal(surfaces.deterministicScatter(1e8,1,bounds).length,4096);
 assert.deepEqual(surfaces.deterministicScatter(NaN,1,bounds),[]);
 assert.throws(()=>surfaces.deterministicScatter(2,1,{...bounds,maxX:NaN}),RangeError);
});
test('0.4.0 saves migrate to the visual release with inventory and facilities intact',()=>{
 assert.equal(VERSION,'0.5.0');const g=createGame();g.version='0.4.0';g.bag={wood:16,water:2};g.store={stone:42};g.built.bench=true;g.built.bonfire=true;g.stats.kills=7;
 const s=restore(JSON.stringify(g));assert.equal(s.version,'0.5.0');assert.deepEqual(s.bag,g.bag);assert.deepEqual(s.store,g.store);assert.equal(s.built.bench,true);assert.equal(s.built.bonfire,true);assert.equal(s.stats.kills,7);
});
test('detailed survivor and enemy have finite geometry and articulated limbs within mobile budget',()=>{
 assert.equal(typeof characters.createCharacter3D,'function');
 for(const enemy of [false,true]){
  const a=characters.createCharacter3D({enemy,big:enemy});let vertices=0,meshes=0;
  assert.equal(a.limbs.length,2);assert.ok(a.body&&a.blade&&a.gun&&a.health&&a.fill);
  a.group.traverse(o=>{if(o.isMesh){meshes++;const p=o.geometry.getAttribute('position');vertices+=p.count;assert.ok(Array.from(p.array).every(Number.isFinite));}});
  assert.ok(vertices>1500&&vertices<30000);assert.ok(meshes<65);
  assert.ok(a.limbs.every(l=>l.arm.children.length&&l.leg.children.length));
 }
});
test('unarmed infected do not display player weapons',()=>{
 const a=characters.createCharacter3D({enemy:true});assert.equal(a.blade.visible,false);assert.equal(a.gun.visible,false);
});
test('post processing preserves HDR only when supported and has an LDR fallback',()=>{
 assert.equal(typeof post.renderTargetType,'function');
 const gpu=(isWebGL2,extensions)=>({capabilities:{isWebGL2},extensions:{has:name=>extensions.includes(name)}});
 assert.equal(post.renderTargetType(gpu(true,['EXT_color_buffer_float'])),HalfFloatType);
 assert.equal(post.renderTargetType(gpu(false,['OES_texture_half_float','EXT_color_buffer_half_float','OES_texture_half_float_linear'])),HalfFloatType);
 for(const g of [gpu(true,[]),gpu(false,[]),gpu(false,['OES_texture_half_float'])])assert.equal(post.renderTargetType(g),UnsignedByteType);
});
