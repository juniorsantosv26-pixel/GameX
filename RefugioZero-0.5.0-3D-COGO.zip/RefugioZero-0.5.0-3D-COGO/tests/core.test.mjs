import test from 'node:test';
import assert from 'node:assert/strict';
import {createGame,addItem,deposit,craft,attack,tick,die,recover,restore,travel,collect,recipes,move,distance,heal,total} from '../src/core.mjs';

test('deposit preserves favourited supplies while moving materials',()=>{
 const g=createGame(); g.bag={wood:8,medkit:2};g.favorites=['medkit'];
 assert.equal(deposit(g).ok,true);assert.equal(g.store.wood,8);assert.equal(g.bag.medkit,2);assert.equal(g.bag.wood,undefined);
});
test('craft fails atomically and cannot craft outside the refuge',()=>{
 const g=createGame();g.bag={wood:8};g.store={};const before=JSON.stringify(g);
 assert.equal(craft(g,'bench').ok,false);assert.equal(JSON.stringify(g),before);
 g.zone='forest';g.store={wood:99,stone:99};assert.equal(craft(g,'bench').ok,false);assert.equal(g.built.bench,false);
});
test('complete resource cycle builds the radio using both storage and backpack',()=>{
 const g=createGame();g.bag={wood:16,stone:8};g.store={scrap:20,electronics:8};
 assert.equal(craft(g,'bench').ok,true);assert.equal(craft(g,'scanner').ok,true);assert.equal(craft(g,'radio').ok,true);
 assert.equal(g.won,true);assert.equal(g.built.radio,true);assert.equal(craft(g,'radio').ok,false);
});
test('missing prerequisites cannot be bypassed with resources',()=>{
 const g=createGame();g.store={wood:99,stone:99,scrap:99,electronics:99};
 assert.equal(craft(g,'radio').ok,false);assert.equal(g.built.radio,false);
});
test('full resource stacks never disappear during collection',()=>{
 const g=createGame();travel(g,'forest');const n=g.world.forest.nodes[0];g.player.x=n.x;g.player.y=n.y;g.bag={[n.item]:99};
 assert.equal(collect(g,n.id).ok,false);assert.equal(n.amount>0,true);assert.equal(addItem(g,n.item,1),0);
});
test('melee damage is bounded by range and cooldown',()=>{
 const g=createGame();travel(g,'forest');const e=g.world.forest.enemies[0];g.player.x=e.x-20;g.player.y=e.y;
 const hp=e.hp;assert.equal(attack(g).ok,true);assert.ok(e.hp<hp);const after=e.hp;attack(g);assert.equal(e.hp,after);
 tick(g,1);g.player.x=50;g.player.y=50;const atRange=e.hp;assert.equal(attack(g).ok,false);assert.equal(e.hp,atRange);
});
test('firearm with no ammo and broken melee weapon do not damage enemies',()=>{
 const g=createGame();travel(g,'forest');const e=g.world.forest.enemies[0];g.player.x=e.x-20;g.player.y=e.y;
 g.weapon='pistol';g.ammo=0;const hp=e.hp;assert.equal(attack(g).ok,false);g.weapon='blade';g.durability.blade=0;assert.equal(attack(g).ok,false);assert.equal(e.hp,hp);
});
test('death keeps construction and drops cargo that is recovered once',()=>{
 const g=createGame();g.built.bench=true;travel(g,'forest');g.bag={wood:6};die(g);assert.equal(g.built.bench,true);assert.deepEqual(g.bag,{});
 const d=structuredClone(g.drop);travel(g,d.zone);g.player.x=d.x;g.player.y=d.y;assert.equal(recover(g).ok,true);assert.equal(g.bag.wood,6);assert.equal(recover(g).ok,false);
});
test('save loader rejects tampered structures and recovers from corrupt JSON',()=>{
 assert.equal(restore('{broken').zone,'base');assert.equal(restore('null').zone,'base');
 const g=createGame();g.bag={wood:-20,electronics:Infinity,'<img>':7};g.player.x=Infinity;g.zone='evil';g.favorites=['<img>'];g.durability.blade=NaN;
 const r=restore(JSON.stringify(g));assert.equal(r.zone,'base');assert.ok(Number.isFinite(r.player.x));assert.equal(r.bag.wood,undefined);assert.equal(r.bag['<img>'],undefined);assert.deepEqual(r.favorites,[]);assert.ok(Number.isFinite(r.durability.blade));
});
test('large frame gaps cannot apply minutes of damage',()=>{
 const g=createGame();travel(g,'forest');const hp=g.player.hp;tick(g,3600);assert.ok(g.player.hp>=hp-15);
});
test('radio recipe is finite and has an explicit scanner prerequisite',()=>{
 assert.equal(recipes.radio.requires,'scanner');for(const n of Object.values(recipes.radio.cost))assert.ok(Number.isInteger(n)&&n>0);
});
test('inherited property names are rejected by saved zones and public model actions',()=>{
 for(const key of ['__proto__','constructor','toString']){
  const saved=createGame();saved.zone=key;assert.equal(restore(JSON.stringify(saved)).zone,'base');
  const g=createGame();assert.equal(travel(g,key).ok,false);assert.equal(craft(g,key).ok,false);assert.equal(addItem(g,key,1),0);
 }
});
test('saved identifiers must be strings, not arrays that coerce to valid names',()=>{
 const g=createGame();g.zone=['base'];g.weapon=['pistol'];g.favorites=[['medkit'],'wood'];
 const r=restore(JSON.stringify(g));assert.equal(r.zone,'base');assert.equal(r.weapon,'blade');assert.deepEqual(r.favorites,['wood']);
});
test('a complete expedition wins with actual movement, collection, fighting and crafting',()=>{
 const g=createGame();g.weapon='pistol';let simulated=0;
 function walk(point){let guard=0;const startZone=g.zone;while(distance(g.player,point)>58&&guard++<1600){if(g.player.hp<55)heal(g);attack(g);move(g,point.x-g.player.x,point.y-g.player.y,.05);tick(g,.05);simulated+=.05;assert.equal(g.zone,startZone,'the route must not require a death teleport');}assert.ok(guard<1600,'destination must remain reachable');}
 function returnHome(){walk({x:70,y:740});assert.equal(travel(g,'base').ok,true);deposit(g);}
 function obtain(id,n){while(total(g,id)<n){const node=g.world[g.zone].nodes.find(v=>v.item===id&&v.amount);assert.ok(node,'sector must supply the required resource');walk(node);assert.equal(collect(g,node.id).ok,true);}}
 travel(g,'forest');obtain('wood',8);obtain('stone',6);returnHome();assert.equal(craft(g,'bench').ok,true);
 travel(g,'district');obtain('scrap',6);obtain('electronics',2);returnHome();assert.equal(craft(g,'scanner').ok,true);
 travel(g,'forest');obtain('wood',8);returnHome();travel(g,'district');obtain('scrap',10);obtain('electronics',4);returnHome();
 assert.equal(craft(g,'radio').ok,true);assert.equal(g.won,true);assert.ok(g.stats.kills>0);assert.ok(simulated>0);
});
