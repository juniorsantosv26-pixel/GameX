import vm from 'node:vm';
import {readFileSync,mkdirSync,writeFileSync} from 'node:fs';
import {createRequire} from 'node:module';
let nativeCanvas;
try{const req=createRequire((process.env.CODEX_PRIMARY_RUNTIME_NODE_MODULES||'/opt/codex/runtimes/codex-primary-runtime/dependencies/node/node_modules')+'/__harness__.cjs');nativeCanvas=req('@napi-rs/canvas');}catch{}
const stub=new Proxy({createRadialGradient:()=>({addColorStop(){}})}, {get:(o,k)=>k in o?o[k]:(()=>{})});
export function harness({width=800,height=620,storageBlocked=false,initialSave=null,initialStorage={}}={}){
 const ids=new Map(),elements=[],events=new Map(),windowEvents=new Map(),store=new Map(),timers=[];let raf=null,now=0;
 for(const [key,value] of Object.entries(initialStorage))store.set(key,value);
 if(initialSave){store.set('refugio-zero-01',initialSave);store.set('refugio-zero-01-started','1');}
 function parse(html){for(const match of html.matchAll(/<([a-z][\w-]*)\b([^>]*)>/gi)){const [_,tag,attrs]=match;const id=attrs.match(/\bid="([^"]+)"/)?.[1];const node=element(tag,id);node.hidden=/\bhidden(?:\s|$)/.test(attrs);node.disabled=/\bdisabled(?:\s|$)/.test(attrs);for(const a of attrs.matchAll(/\bdata-([\w-]+)="([^"]*)"/g))node.dataset[a[1].replace(/-([a-z])/g,(_,x)=>x.toUpperCase())]=a[2];elements.push(node);if(id)ids.set(id,node);}}
 function element(tag,id){const listeners=new Map();let html='';const c=(tag==='canvas'&&nativeCanvas)?nativeCanvas.createCanvas(id==='minimap'?156:width,id==='minimap'?96:height):null;const node={tagName:tag.toUpperCase(),id,dataset:{},style:{},hidden:false,disabled:false,open:false,textContent:'',value:'',classList:{add(){},remove(){},toggle(){}},setAttribute(k,v){this[k]=v;},getBoundingClientRect:()=>({left:0,top:0,width,height}),getContext:()=>c?.getContext('2d')||stub,focus(){},matches:s=>s.split(',').includes(tag),closest:s=>s===tag?node:null,setPointerCapture(){},addEventListener(type,fn){listeners.set(type,[...(listeners.get(type)||[]),fn]);},showModal(){this.open=true;},close(){this.open=false;for(const fn of listeners.get('close')||[])fn({target:this});},emit(type,event={}){for(const fn of listeners.get(type)||[])fn({target:this,preventDefault(){},...event});},nativeCanvas:c};Object.defineProperty(node,'innerHTML',{get:()=>html,set(v){html=v;parse(v);}});return node;}
 const source=readFileSync('dist/index.html','utf8');parse(source.split('<script>')[0]);
 const document={hidden:false,getElementById(id){return ids.get(id)||null;},querySelectorAll(selector){const attr=selector.match(/^\[data-([\w-]+)\]$/)?.[1];return attr?elements.filter(e=>Object.hasOwn(e.dataset,attr.replace(/-([a-z])/g,(_,x)=>x.toUpperCase()))):[];},addEventListener(type,fn){events.set(type,[...(events.get(type)||[]),fn]);}};
 const window={devicePixelRatio:1,matchMedia:()=>({matches:false}),addEventListener(type,fn){windowEvents.set(type,[...(windowEvents.get(type)||[]),fn]);}};
 const localStorage={getItem(k){if(storageBlocked)throw Error('blocked');return store.get(k)||null;},setItem(k,v){if(storageBlocked)throw Error('blocked');store.set(k,v);}};
 const sandbox={document,window,localStorage,performance:{now:()=>now},requestAnimationFrame:fn=>raf=fn,setTimeout:fn=>timers.push(fn),clearTimeout(){},console};
 const code=source.match(/<script>([\s\S]*)<\/script>/)[1];vm.runInNewContext(code,sandbox,{timeout:2000});
 const dispatch=(type,event)=>{for(const fn of events.get(type)||[])fn({preventDefault(){},...event});};
 return {ids,store,androidBack:()=>window.refugioBack(),native:!!nativeCanvas,blockStorage(){storageBlocked=true;},windowEvent(type,event){for(const fn of windowEvents.get(type)||[])fn(event);},find(key,val){const found=elements.filter(e=>e.dataset[key]===val).at(-1);assertFound(found,key,val);return found;},click(e){if(typeof e==='string')e=ids.get(e);if(!e||e.disabled)throw Error('Button missing or disabled');e.onclick?.({target:e});dispatch('click',{target:e});},key(k,up=false){dispatch(up?'keyup':'keydown',{key:k,target:ids.get('world'),repeat:false});},advance(seconds=1){for(let i=0;i<Math.ceil(seconds*60);i++){now+=1000/60;const fn=raf;raf=null;fn?.(now);}},render(path){if(nativeCanvas){this.advance(.1);mkdirSync('artifacts',{recursive:true});writeFileSync(path,ids.get('world').nativeCanvas.toBuffer('image/png'));}},source};
}
function assertFound(value,key,val){if(!value)throw Error('Missing UI action '+key+'='+val);}
