import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {execFileSync} from 'node:child_process';

test('standalone package includes all game logic and an exact offline copy',()=>{
 execFileSync(process.execPath,['scripts/build.mjs']);
 const main=readFileSync('dist/index.html','utf8'),offline=readFileSync('dist/refugio-zero-offline.html','utf8');
 assert.equal(main,offline);assert.ok(main.includes('function createGame'));
 assert.ok(!main.includes('/*STYLE*/'));assert.ok(!main.includes('/*SCRIPT*/'));
 assert.ok(!/<script[^>]+src=/i.test(main));assert.ok(!/<(?:img|link|iframe|audio|video|source)\b[^>]*(?:src|href)\s*=\s*["'](?:https?:)?\/\//i.test(main),'no external resource attributes');assert.ok(!/@import\s+(?:url\()?['"]?https?:/i.test(main),'no external styles');assert.ok(!/^\s*(import|export) /m.test(main));
 for(const id of ['start','inventory-grid','attack','interact','joystick','hp-bar','panel','minimap'])assert.ok(main.includes(id));
});
