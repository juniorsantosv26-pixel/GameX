import test from 'node:test';
import assert from 'node:assert/strict';
import {mkdtempSync,writeFileSync,mkdirSync,rmSync,readFileSync} from 'node:fs';
import {tmpdir} from 'node:os';
import {join,resolve,dirname} from 'node:path';
import {execFileSync} from 'node:child_process';

test('the actual WebView client returns the packaged game with HTTP 200 and blocks unrelated requests',()=>{
 const dir=mkdtempSync(join(tmpdir(),'refugio-offline-'));
 try{
  const sources={
   'android/net/Uri.java':`package android.net; public final class Uri {
    private final String value; private Uri(String value){this.value=value;}
    public static Uri parse(String value){return new Uri(value);} public String toString(){return value;}
   }`,
   'android/webkit/WebView.java':'package android.webkit; public class WebView {}',
   'android/webkit/WebResourceRequest.java':`package android.webkit; public interface WebResourceRequest {
    android.net.Uri getUrl(); String getMethod();
   }`,
   'android/webkit/WebViewClient.java':`package android.webkit; public class WebViewClient {
    public boolean shouldOverrideUrlLoading(WebView w,WebResourceRequest r){return false;}
    public boolean shouldOverrideUrlLoading(WebView w,String u){return false;}
    public WebResourceResponse shouldInterceptRequest(WebView w,WebResourceRequest r){return null;}
    public WebResourceResponse shouldInterceptRequest(WebView w,String u){return null;}
   }`,
   'android/webkit/WebResourceResponse.java':`package android.webkit; public class WebResourceResponse {
    public final String mime,encoding; public final int status; public final java.io.InputStream data;
    public final java.util.Map<String,String> headers;
    public WebResourceResponse(String m,String e,int s,String reason,java.util.Map<String,String> h,java.io.InputStream d){mime=m;encoding=e;status=s;headers=h;data=d;}
    public int getStatusCode(){return status;} public String getMimeType(){return mime;}
    public String getEncoding(){return encoding;} public java.io.InputStream getData(){return data;}
    public java.util.Map<String,String> getResponseHeaders(){return headers;}
   }`,
   'br/com/zerox/refugio/GameAssetClientTest.java':`package br.com.zerox.refugio;
import android.webkit.*;
import java.io.*;
public final class GameAssetClientTest {
 static WebResourceRequest request(final String url, final String method){return new WebResourceRequest(){
  public android.net.Uri getUrl(){return android.net.Uri.parse(url);} public String getMethod(){return method;}
 };}
 static String text(WebResourceResponse r)throws Exception {
  try(InputStream in=r.getData();ByteArrayOutputStream out=new ByteArrayOutputStream()){
   byte[] bytes=new byte[8192];int n;while((n=in.read(bytes))!=-1)out.write(bytes,0,n);return out.toString("UTF-8");
  }
 }
 static void check(boolean value,String message){if(!value)throw new AssertionError(message);}
 public static void main(String[] args)throws Exception {
  final byte[] html=java.nio.file.Files.readAllBytes(java.nio.file.Paths.get(args[0]));
  final int[] opened={0};GameAssetClient client=new GameAssetClient(()->{opened[0]++;return new ByteArrayInputStream(html);});
  WebResourceResponse page=client.shouldInterceptRequest(null,request(GameAssetClient.GAME_URL,"GET"));
  check(page.getStatusCode()==200,"The packaged page must return HTTP 200, not the old 403");
  check("text/html".equals(page.getMimeType()),"HTML MIME");check("UTF-8".equals(page.getEncoding()),"UTF-8");
  check(text(page).equals(new String(html,"UTF-8")),"The exact packaged game must be served");
  check("no-store".equals(page.getResponseHeaders().get("Cache-Control")),"Updates must not use stale HTML");
  check(!client.shouldOverrideUrlLoading(null,request(GameAssetClient.GAME_URL,"GET")),"Allow game navigation");
  check(client.shouldInterceptRequest(null,GameAssetClient.GAME_URL).getStatusCode()==200,"Legacy callback must serve the same local asset");
  String png="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAAB";
  check(client.shouldInterceptRequest(null,request(png,"GET"))==null,"Inline PNG bytes must be decoded locally, not blocked");
  check(client.shouldInterceptRequest(null,png)==null,"Legacy callback allows embedded PNG too");
  check(client.shouldOverrideUrlLoading(null,png),"Embedded images must never become a navigation destination");
  check(client.shouldInterceptRequest(null,request(png,"POST")).getStatusCode()==403,"PNG is GET only");
  int validOpens=opened[0];
  for(String url:new String[]{"https://example.com/","http://refugio.zero.local/game.html","https://refugio.zero.local.evil/game.html","file:///sdcard/test.html","data:text/html;base64,AA==","data:image/svg+xml,<svg/>","https://refugio.zero.local/../secret","https://refugio.zero.local/game.html?remote=1"}){
   check(client.shouldInterceptRequest(null,request(url,"GET")).getStatusCode()==403,"Block "+url);
   check(client.shouldOverrideUrlLoading(null,url),"Do not navigate to "+url);
  }
  check(client.shouldInterceptRequest(null,request(GameAssetClient.GAME_URL,"POST")).getStatusCode()==403,"Read only");
  check(opened[0]==validOpens,"Blocked requests must not open any assets");
  GameAssetClient missing=new GameAssetClient(()->{throw new IOException("missing game");});
  check(missing.shouldInterceptRequest(null,GameAssetClient.GAME_URL).getStatusCode()==500,"Missing content must have a distinct error");
  System.out.println("Offline loading regression passed");
 }
}`
  };
  const paths=[];
  for(const [name,body] of Object.entries(sources)){const file=join(dir,name);mkdirSync(dirname(file),{recursive:true});writeFileSync(file,body);paths.push(file);}
  execFileSync('java',['com.sun.tools.javac.Main','--release','8','-d',dir,
   resolve('app/src/main/java/br/com/zerox/refugio/GameAssetClient.java'),...paths],{stdio:'pipe'});
  const result=execFileSync('java',['-cp',dir,'br.com.zerox.refugio.GameAssetClientTest',resolve('app/src/main/assets/game.html')],{encoding:'utf8'});
  assert.ok(result.includes('Offline loading regression passed'));
 }finally{rmSync(dir,{recursive:true,force:true});}
});
