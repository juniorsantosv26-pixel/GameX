import test from 'node:test';
import assert from 'node:assert/strict';
import * as core from '../src/core.mjs';

test('reinforced backpack is crafted once and safely restores cargo above the original limit',()=>{
 const g=core.createGame();g.built.bench=true;g.store={wood:6,cloth:6,scrap:4};g.bag={};
 assert.ok(core.recipes.pack,'pack recipe must exist');
 assert.equal(core.craft(g,'pack').ok,true);assert.equal(core.capacity(g),90);
 assert.equal(core.addItem(g,'wood',85),85);assert.equal(core.addItem(g,'stone',10),5);
 const r=core.restore(JSON.stringify(g));assert.equal(core.capacity(r),90);assert.equal(core.cargo(r),90);
 assert.equal(core.craft(r,'pack').ok,false);
});
test('backpack upgrade requires a workbench and insufficient ingredients are never consumed',()=>{
 const g=core.createGame();g.store={wood:6,cloth:6,scrap:4};const before=JSON.stringify(g);
 assert.equal(core.craft(g,'pack').ok,false);assert.equal(JSON.stringify(g),before);
 g.built.bench=true;g.store.cloth=5;const partial=JSON.stringify(g);
 assert.equal(core.craft(g,'pack').ok,false);assert.equal(JSON.stringify(g),partial);
});
test('torch burns only while enabled at night outside the refuge and stops at empty',()=>{
 const g=core.createGame();assert.equal(core.toggleTorch(g).ok,true);
 core.tick(g,.1);assert.equal(g.survival.fuel,100);
 g.zone='forest';g.survival.clock=149;core.tick(g,.1);assert.equal(g.survival.fuel,100);
 g.survival.clock=180;core.tick(g,.1);assert.ok(g.survival.fuel<100);assert.equal(core.isNight(g),true);
 g.survival.fuel=.01;core.tick(g,.1);assert.equal(g.survival.fuel,0);assert.equal(g.survival.torch,false);
 assert.equal(core.toggleTorch(g).ok,false);
 g.zone='base';g.survival.fuel=40;g.survival.torch=true;core.tick(g,.1);assert.equal(g.survival.fuel,40);
 g.zone='forest';g.survival.torch=false;core.tick(g,.1);assert.equal(g.survival.fuel,40);
});
test('refilling a torch uses the base stock atomically and does not charge for a full torch',()=>{
 const g=core.createGame();g.store={wood:4,cloth:2};g.bag={};
 assert.ok(core.recipes.fuel);const full=JSON.stringify(g);
 assert.equal(core.craft(g,'fuel').ok,false);assert.equal(JSON.stringify(g),full);
 g.survival.fuel=20;g.zone='forest';const away=JSON.stringify(g);
 assert.equal(core.craft(g,'fuel').ok,false);assert.equal(JSON.stringify(g),away);
 g.zone='base';assert.equal(core.craft(g,'fuel').ok,true);assert.equal(g.survival.fuel,100);
 assert.equal(g.store.wood,2);assert.equal(g.store.cloth,1);
});
test('version 0.1 saves migrate without resetting existing construction and resources',()=>{
 const g=core.createGame();g.version='0.1.0';delete g.survival;g.built.bench=true;g.bag={wood:13};
 const r=core.restore(JSON.stringify(g));assert.equal(r.version,core.VERSION);assert.equal(r.built.bench,true);
 assert.equal(r.bag.wood,13);assert.equal(r.survival.fuel,100);assert.equal(core.capacity(r),60);
});

test('the loading hotfix preserves version 0.2.0 progress and an upgraded backpack',()=>{
 const g=core.createGame();g.version='0.2.0';g.built.bench=true;g.built.pack=true;g.bag={wood:85};g.stats.kills=23;
 const r=core.restore(JSON.stringify(g));assert.equal(r.version,core.VERSION);assert.equal(r.bag.wood,85);
 assert.equal(core.capacity(r),90);assert.equal(r.built.bench,true);assert.equal(r.stats.kills,23);
});
test('malformed survival data are bounded and empty fuel cannot keep the torch on',()=>{
 const g=core.createGame();g.survival={clock:-200,fuel:-9,torch:true};
 const r=core.restore(JSON.stringify(g));assert.equal(r.survival.clock,0);assert.equal(r.survival.fuel,0);assert.equal(r.survival.torch,false);
 g.survival={clock:'noite',fuel:'cheia',torch:[]};const s=core.restore(JSON.stringify(g));
 assert.equal(s.survival.clock,0);assert.equal(s.survival.fuel,100);assert.equal(s.survival.torch,false);
});
test('night cycle rolls into day without advancing after a huge frame gap',()=>{
 const g=core.createGame();g.survival.clock=239.99;assert.equal(core.isNight(g),true);
 core.tick(g,.1);assert.equal(core.isNight(g),false);assert.ok(g.survival.clock<.11);
 const start=g.survival.clock;core.tick(g,3600);assert.ok(g.survival.clock-start<=.100001);
});
test('preparation warnings identify shortages but do not block travel',()=>{
 const g=core.createGame();g.player.hp=25;g.bag={wood:60};g.durability.blade=0;g.ammo=0;g.survival.clock=180;g.survival.fuel=0;
 const warnings=core.preparation(g,'forest');assert.ok(warnings.some(x=>/vida/i.test(x)));assert.ok(warnings.some(x=>/mochila/i.test(x)));assert.ok(warnings.some(x=>/tocha/i.test(x)));
 assert.equal(core.travel(g,'forest').ok,true);assert.deepEqual(core.preparation(g,'base'),[]);
});
