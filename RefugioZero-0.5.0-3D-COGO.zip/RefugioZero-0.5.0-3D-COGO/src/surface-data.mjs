const clamp=(x,a,b)=>Math.max(a,Math.min(b,x));
function random(seed){let n=seed>>>0;return ()=>{n+=0x6d2b79f5;let t=n;t=Math.imul(t^(t>>>15),t|1);t^=t+Math.imul(t^(t>>>7),t|61);return ((t^(t>>>14))>>>0)/4294967296;};}
function noise(x,y,seed){let n=Math.imul(x+seed*19,374761393)^Math.imul(y+seed*7,668265263);n=Math.imul(n^(n>>>13),1274126177);return ((n^(n>>>16))>>>0)/4294967295;}
export function deterministicScatter(count,seed,bounds){
 const {minX,maxX,minZ,maxZ}=bounds||{};
 if(![minX,maxX,minZ,maxZ].every(Number.isFinite)||maxX<minX||maxZ<minZ)throw new RangeError('Invalid scatter bounds');
 const n=Number.isFinite(count)?clamp(Math.floor(count),0,4096):0,r=random(Number.isFinite(seed)?seed:1);
 return Array.from({length:n},()=>({x:minX+r()*(maxX-minX),z:minZ+r()*(maxZ-minZ),rotation:r()*Math.PI*2,scale:.65+r()*.7}));
}
export function surfaceData(kind,size=128,seed=1){
 if(!Number.isInteger(size)||size<16||size>512)throw new RangeError('Surface size must be 16..512');
 seed=Number.isFinite(seed)?seed:1;
 const palettes={grass:[81,121,48],dirt:[143,113,76],stone:[116,131,129],wood:[131,88,49],concrete:[116,125,122]};
 if(!Object.hasOwn(palettes,kind))throw new RangeError('Unknown surface');
 const height=new Float32Array(size*size),color=new Uint8Array(size*size*4),normal=new Uint8Array(size*size*4),roughness=new Uint8Array(size*size*4);
 for(let y=0;y<size;y++)for(let x=0;x<size;x++){
  const i=y*size+x,n=noise(x,y,seed),coarse=noise(Math.floor(x/8),Math.floor(y/8),seed+2),wave=Math.sin(x*.12+Math.sin(y*.16)*2);
  let h=n*.42+coarse*.38+.2;
  if(kind==='wood')h=.55+.18*Math.sin(x*.47+Math.sin(y*.08)*.65)+n*.12;
  if(kind==='stone'||kind==='concrete')h=coarse*.42+n*.2+((x%32<2||y%32<2)?-.22:.18);
  height[i]=h;
  const variation=(h-.5)*53+(kind==='grass'?wave*5:0),base=palettes[kind];
  for(let k=0;k<3;k++)color[i*4+k]=clamp(base[k]+variation+(kind==='grass'&&k===1?n*14:0),0,255);
  color[i*4+3]=255;
  const r=clamp((kind==='wood'?178:kind==='stone'?194:223)+n*22,0,255);
  roughness.set([r,r,r,255],i*4);
 }
 const at=(x,y)=>height[((y+size)%size)*size+(x+size)%size];
 for(let y=0;y<size;y++)for(let x=0;x<size;x++){
  const strength=kind==='grass'?.9:kind==='wood'?.65:.85,dx=(at(x-1,y)-at(x+1,y))*strength,dy=(at(x,y-1)-at(x,y+1))*strength,inv=1/Math.hypot(dx,dy,1);
  normal.set([Math.round((dx*inv*.5+.5)*255),Math.round((dy*inv*.5+.5)*255),Math.round((inv*.5+.5)*255),255],(y*size+x)*4);
 }
 return {size,color,normal,roughness};
}
