export const WORLD_SCALE=1/30;
export function worldToScene(p){return {x:p.x*WORLD_SCALE,z:p.y*WORLD_SCALE};}
export function sceneToWorld(p){return {x:p.x/WORLD_SCALE,y:p.z/WORLD_SCALE};}
export function screenMovement(x,y,yaw){
 const c=Math.cos(yaw),s=Math.sin(yaw);
 return {x:x*c+y*s,y:-x*s+y*c};
}
