import * as T from '../vendor/three.module.js';
export function renderTargetType(renderer){
 const has=name=>renderer.extensions.has(name);
 const supported=renderer.capabilities.isWebGL2?has('EXT_color_buffer_float'):has('OES_texture_half_float')&&has('EXT_color_buffer_half_float')&&has('OES_texture_half_float_linear');
 return supported?T.HalfFloatType:T.UnsignedByteType;
}
// One bounded render target and a five-tap filter; Leve renders directly.
export function createPostFX(renderer){
 const target=new T.WebGLRenderTarget(1,1,{type:renderTargetType(renderer),minFilter:T.LinearFilter,magFilter:T.LinearFilter,depthBuffer:true});
 const uniforms={tScene:{value:target.texture},uPixel:{value:new T.Vector2(1,1)},uGlow:{value:.08}};
 const material=new T.ShaderMaterial({uniforms,depthTest:false,depthWrite:false,toneMapped:true,
  vertexShader:'varying vec2 vUv; void main(){vUv=uv;gl_Position=vec4(position.xy,0.0,1.0);}',
  fragmentShader:`varying vec2 vUv;uniform sampler2D tScene;uniform vec2 uPixel;uniform float uGlow;
  void main(){
   vec3 c=texture2D(tScene,vUv).rgb;
   vec3 a=texture2D(tScene,vUv+uPixel*vec2(1.,0.)).rgb;
   vec3 b=texture2D(tScene,vUv-uPixel*vec2(1.,0.)).rgb;
   vec3 d=texture2D(tScene,vUv+uPixel*vec2(0.,1.)).rgb;
   vec3 e=texture2D(tScene,vUv-uPixel*vec2(0.,1.)).rgb;
   vec3 avg=(a+b+d+e)*.25;float edge=length(c-avg);
   c=mix(c,avg,smoothstep(.12,.5,edge)*.23);
   vec3 glow=texture2D(tScene,vUv+uPixel*vec2(5.,3.)).rgb+texture2D(tScene,vUv-uPixel*vec2(5.,3.)).rgb;
   c+=max(glow*.5-vec3(.7),vec3(0.))*uGlow;
   float l=dot(c,vec3(.2126,.7152,.0722));c=mix(vec3(l),c,1.085);
   vec2 q=vUv*2.-1.;c*=1.-.13*pow(clamp(dot(q,q)*.5,0.,1.),1.4);
   gl_FragColor=vec4(max(c,0.),1.);
   #include <tonemapping_fragment>
   #include <colorspace_fragment>
  }`});
 const scene=new T.Scene(),camera=new T.OrthographicCamera(-1,1,1,-1,0,1),quad=new T.Mesh(new T.PlaneGeometry(2,2),material);quad.frustumCulled=false;scene.add(quad);
 return {
  resize(w,h,dpr){const width=Math.min(4096,Math.max(1,Math.round((Number.isFinite(w)?w:1)*(Number.isFinite(dpr)?dpr:1)))),height=Math.min(4096,Math.max(1,Math.round((Number.isFinite(h)?h:1)*(Number.isFinite(dpr)?dpr:1))));target.setSize(width,height);uniforms.uPixel.value.set(1/width,1/height);},
  render(world,camera3D,enabled){if(!enabled){renderer.setRenderTarget(null);renderer.render(world,camera3D);return;}renderer.setRenderTarget(target);renderer.render(world,camera3D);renderer.setRenderTarget(null);renderer.render(scene,camera);},
  dispose(){target.dispose();quad.geometry.dispose();material.dispose();}
 };
}
