import * as T from '../vendor/three.module.js';
import {assets3D} from './assets3d.mjs';
import {qualityProfile,cameraZoom} from './visual-config.mjs';
import {createCharacter3D} from './character3d.mjs';
import {createEnvironment3D} from './environment3d.mjs';
import {createEffects3D} from './effects3d.mjs';
import {createPostFX} from './postfx.mjs';
import {worldToScene,sceneToWorld,screenMovement,WORLD_SCALE} from './view-math.mjs';

const hash=n=>{const v=Math.sin(n*127.1+311.7)*43758.5453;return v-Math.floor(v);};
export function create3DRenderer(canvas){
 if(!window.WebGLRenderingContext&&!window.WebGL2RenderingContext)return null;
 let renderer;
 try{renderer=new T.WebGLRenderer({canvas,antialias:true,alpha:false,powerPreference:'high-performance'});}catch(error){console.warn('3D indisponível:',error.message);return null;}
 renderer.outputColorSpace=T.SRGBColorSpace;renderer.toneMapping=T.ACESFilmicToneMapping;renderer.toneMappingExposure=1.05;
 renderer.shadowMap.enabled=true;renderer.shadowMap.type=T.PCFSoftShadowMap;
 const scene=new T.Scene();scene.background=new T.Color('#899b91');scene.fog=new T.FogExp2('#a2b8ae',.011);
 const camera=new T.PerspectiveCamera(42,1,.1,150),focus=new T.Vector3(20,.6,19);
 let yaw=.62,targetYaw=yaw,quality=qualityProfile('balanced'),zone='',worldGroup=null,environment=null,lost=false,lastTime=0,zoomIndex=0,zoomFactor=1;
 const ray=new T.Raycaster(),plane=new T.Plane(new T.Vector3(0,1,0),0),hit=new T.Vector3();
 const hemi=new T.HemisphereLight('#cce6ff','#465d3f',2.35);scene.add(hemi);
 const sun=new T.DirectionalLight('#ffdfad',3.1);sun.position.set(-8,28,-12);sun.castShadow=true;
 sun.shadow.mapSize.set(1024,1024);sun.shadow.camera.left=-26;sun.shadow.camera.right=26;sun.shadow.camera.top=22;sun.shadow.camera.bottom=-22;sun.shadow.camera.near=1;sun.shadow.camera.far=75;sun.shadow.bias=-.0015;sun.shadow.normalBias=.035;sun.shadow.radius=3;scene.add(sun,sun.target);
 const torch=new T.PointLight('#ffbd6b',0,13,1.7),fireLight=new T.PointLight('#ff9d40',7,12,1.7);scene.add(torch,fireLight);
 const geometry={box:new T.BoxGeometry(1,1,1),sphere:new T.IcosahedronGeometry(1,1),cylinder:new T.CylinderGeometry(1,1,1,8),cone:new T.ConeGeometry(1,1,7),ring:new T.RingGeometry(.38,.44,32),circle:new T.CircleGeometry(1,24),bar:new T.PlaneGeometry(1,1)};
 const materials=new Map(),textures=new Map(),models=new Map();
 function mat(color,opts={}){
  // Sector texture materials are owned by that sector, never retained in this pool.
  if(opts.map?.userData.sectorOwned)return new T.MeshStandardMaterial({color,roughness:.88,metalness:0,...opts});
  const key=color+Object.entries(opts).map(([k,v])=>k+':'+(v?.isTexture?v.uuid:String(v))).join('|');
  if(!materials.has(key))materials.set(key,new T.MeshStandardMaterial({color,roughness:.88,metalness:0,...opts}));return materials.get(key);
 }
 function texture(id,icons=false){const key=(icons?'icon:':'tex:')+id;if(textures.has(key))return textures.get(key);const image=new Image(),tex=new T.Texture(image);tex.colorSpace=T.SRGBColorSpace;tex.anisotropy=Math.min(4,renderer.capabilities.getMaxAnisotropy());image.onload=()=>{tex.needsUpdate=true;};image.src=(icons?assets3D.icons:assets3D.textures)[id];textures.set(key,tex);return tex;}
 function mesh(group,kind,x,y,z,sx,sy,sz,color,opts={}){const m=new T.Mesh(geometry[kind],mat(color,opts));m.position.set(x,y,z);m.scale.set(sx,sy,sz);m.castShadow=true;m.receiveShadow=true;group.add(m);return m;}
 function imported(group,id,x,y,z,size,tint='#ffffff'){
  if(!models.has(id)){
   const d=assets3D.models[id],g=new T.BufferGeometry();g.setAttribute('position',new T.Float32BufferAttribute(d.positions,3));g.setAttribute('normal',new T.Float32BufferAttribute(d.normals,3));g.setAttribute('uv',new T.Float32BufferAttribute(d.uvs,2));
   const lo=d.bounds.min,hi=d.bounds.max,extent=Math.max(...hi.map((v,i)=>v-lo[i]));g.translate(-(lo[0]+hi[0])/2,-lo[1],-(lo[2]+hi[2])/2);g.scale(1/extent,1/extent,1/extent);g.computeBoundingSphere();models.set(id,g);
  }
  const mapId=id==='rock2'?'rock':id;
  const m=new T.Mesh(models.get(id),mat(tint,{...(assets3D.textures[mapId]?{map:texture(mapId)}:{}),side:T.DoubleSide,alphaTest:id.startsWith('pine')||id==='deadTree'?.25:0}));
  m.position.set(x,y,z);m.scale.setScalar(size);m.castShadow=true;m.receiveShadow=true;group.add(m);return m;
 }
 const actor=(enemy=false,big=false)=>createCharacter3D({enemy,big,mat});
 const player=actor();scene.add(player.group);
 const marker=new T.Mesh(geometry.ring,new T.MeshBasicMaterial({color:'#eed195',transparent:true,opacity:.9,side:T.DoubleSide,depthWrite:false}));marker.rotation.x=-Math.PI/2;marker.position.y=.04;scene.add(marker);
 const nodes=new Map(),enemies=new Map(),buildings=new Map();let cargoObject=null,flame=null;
 const postFX=createPostFX(renderer),fx=createEffects3D(scene),follow=new T.Vector3(),daySky=new T.Color('#afc7bc'),nightSky=new T.Color('#253e50'),daySun=new T.Color('#ffe2b5'),nightSun=new T.Color('#a7c7f5');
 function crate(group,x,y,z,size=1){return imported(group,'chest',x,y,z,size,'#d6cfb7');}
 function makeNode(n){
  const g=new T.Group(),p=worldToScene(n);g.position.set(p.x,0,p.z);g.userData.resource={x:n.x,y:n.y};worldGroup.add(g);
  if(n.item==='wood')for(let i=0;i<3;i++){const log=mesh(g,'cylinder',0,.14+(i===2?.23:0),(i%2-.5)*.26,.14,1.3,.14,'#967450');log.rotation.z=Math.PI/2;}
  else if(n.item==='stone')imported(g,'rock',0,0,0,1.65,'#b8c3a1');
  else if(n.item==='water'||n.item==='emptyBottle'){mesh(g,'cylinder',0,.3,0,.16,.58,.16,n.item==='water'?'#75b6c4':'#afc5b2',{metalness:.15,roughness:.35});mesh(g,'cylinder',0,.63,0,.085,.15,.085,'#bac9ad');}
  else{crate(g,0,0,0,1.15);if(n.item==='electronics')mesh(g,'box',0,.65,0,.4,.06,.32,'#507b6d');if(n.item==='cloth')mesh(g,'box',0,.65,0,.45,.16,.35,'#c6c2a2');if(n.item==='rawMeat')mesh(g,'sphere',0,.69,0,.28,.12,.18,'#b77c66');}
  const glow=new T.Mesh(geometry.ring,new T.MeshBasicMaterial({color:'#ead4a2',transparent:true,opacity:.65,side:T.DoubleSide,depthWrite:false}));glow.rotation.x=-Math.PI/2;glow.position.y=.03;glow.scale.setScalar(1.75);g.add(glow);
  const sprite=new T.Sprite(new T.SpriteMaterial({map:texture(n.item,true),transparent:true,depthTest:false,opacity:.95}));sprite.position.y=1.4;sprite.scale.set(.52,.52,1);g.add(sprite);nodes.set(n.id,{group:g,glow,sprite});
 }
 function buildRefuge(){
  mesh(worldGroup,'box',20,-.02,11,14,.2,9,'#d2ac7a',environment.maps('wood',5));
  for(let i=0;i<25;i++)mesh(worldGroup,'box',13.3+i*.55,.09,11,.025,.012,9,'#584f3e');
  mesh(worldGroup,'box',20,1.28,6.5,14,2.6,.18,'#b39c78',environment.maps('wood',4));mesh(worldGroup,'box',13,1.28,11,.18,2.6,9,'#829c8f',environment.maps('wood',3));
  for(const x of [13,20,27])mesh(worldGroup,'box',x,1.35,6.3,.16,2.8,.24,'#615b4c');
  mesh(worldGroup,'box',20,2.7,6.35,14.3,.22,.35,'#534e42');
  mesh(worldGroup,'box',19,1.55,6.33,2.1,1.25,.05,'#405a61',{metalness:.3,roughness:.25});
  for(const x of [17.9,19,20.1])mesh(worldGroup,'box',x,1.55,6.25,.06,1.35,.07,'#c4be9d');
  mesh(worldGroup,'box',19,1.55,6.23,2.3,.055,.07,'#c4be9d');
  const bed=new T.Group();bed.position.set(24,.15,8.2);worldGroup.add(bed);mesh(bed,'box',0,.22,0,2.1,.35,1.1,'#6a685c');mesh(bed,'box',0,.46,0,2.05,.2,1.05,'#728f91');mesh(bed,'sphere',-.68,.61,0,.38,.12,.43,'#ddd4b2');
  mesh(worldGroup,'box',14,1.5,9.3,.8,.12,3.4,'#665b47');for(let i=0;i<6;i++)mesh(worldGroup,'cylinder',14,1.73,8+i*.48,.1,.35,.1,i%2?'#789b84':'#aa8b61',{metalness:.2});
  for(let i=0;i<7;i++)mesh(worldGroup,'box',14+i*1.95,1.8,6.35,.12,.12,.12,'#b4ac8b');
  for(let i=0;i<3;i++)crate(worldGroup,15+i*1.8,.1,8.1,1.35);
  imported(worldGroup,'bike',10.5,0,17,2.4,'#bbc4ab');
  const bench=new T.Group();bench.position.set(15,.1,12);mesh(bench,'box',0,.85,0,2.5,.18,1,'#9e855b');for(const x of [-1,1])mesh(bench,'box',x,.4,0,.15,.8,.8,'#544f3b');mesh(bench,'box',.5,1.03,0,.55,.18,.5,'#6c7e74');worldGroup.add(bench);buildings.set('bench',bench);
  const scanner=new T.Group();scanner.position.set(22,.1,9);mesh(scanner,'box',0,.7,0,.9,1.4,.8,'#657d74');mesh(scanner,'box',0,1.15,.43,.65,.35,.04,'#95c29f',{emissive:'#668a73',emissiveIntensity:.5});mesh(scanner,'cylinder',0,1.8,0,.025,.8,.025,'#bfc5a6');worldGroup.add(scanner);buildings.set('scanner',scanner);
  const radio=new T.Group();radio.position.set(24,0,13);mesh(radio,'box',0,.5,0,1.4,1,1,'#53675e');mesh(radio,'cylinder',0,2.5,0,.045,4.5,.045,'#bac3ac');const aerial=mesh(radio,'box',0,4.4,0,2.3,.05,.05,'#c5c8ac');worldGroup.add(radio);buildings.set('radio',radio);
  const tank=new T.Group();tank.position.set(28,0,15.5);mesh(tank,'cylinder',0,.65,0,.65,1.3,.65,'#6e9696');mesh(tank,'cone',0,1.4,0,.98,.35,.98,'#b2b7a0');worldGroup.add(tank);buildings.set('rainCollector',tank);
  for(let i=0;i<8;i++){const a=i*Math.PI/4;mesh(worldGroup,'sphere',24+Math.cos(a)*.55,.13,18.7+Math.sin(a)*.55,.23,.16,.2,'#8d9179');}
  flame=new T.Group();flame.position.set(24,.2,18.7);mesh(flame,'cone',0,.48,0,.33,.96,.33,'#f0b564',{emissive:'#f0a43a',emissiveIntensity:1});mesh(flame,'cone',.1,.35,.05,.18,.65,.18,'#ffe3a0',{emissive:'#ffca70',emissiveIntensity:1});worldGroup.add(flame);buildings.set('bonfire',flame);fireLight.position.set(24,1.4,18.7);
 }
 function rebuild(g){
  if(worldGroup){
   const pooled=new Set(materials.values()),disposed=new Set();
   worldGroup.traverse(obj=>{if(obj.isInstancedMesh)obj.dispose();if(obj.material&&!pooled.has(obj.material)&&!disposed.has(obj.material)){obj.material.dispose();disposed.add(obj.material);}});
   for(const geo of worldGroup.userData.ownedGeometry||[])geo.dispose();
   for(const tex of worldGroup.userData.ownedTextures||[])tex.dispose();
   scene.remove(worldGroup);
  }
  worldGroup=new T.Group();scene.add(worldGroup);nodes.clear();enemies.clear();buildings.clear();flame=null;cargoObject=null;
  environment=createEnvironment3D({root:worldGroup,zone:g.zone,mesh,mat,imported,quality});environment.setQuality(quality);
  if(g.zone==='base')buildRefuge();
  if(g.zone==='district'){
   for(const [x,z,w,d] of [[15,3,6,4],[32,5,5,4],[26,24,7,3]]){
    mesh(worldGroup,'box',x,.01,z,w,.2,d,'#b6bbae',environment.maps('concrete',3));
    mesh(worldGroup,'box',x,1.4,z-d/2,w,2.8,.25,'#9faaa0',environment.maps('concrete',3));
    mesh(worldGroup,'box',x-w/2,1,z,.25,2,d,'#7d9089',environment.maps('concrete',3));
    for(let i=0;i<5;i++)mesh(worldGroup,'box',x-w/3+i*1.1,.25,z+hash(i)*d,.7,.5,.6,'#949b8b');
    for(let i=0;i<3;i++)mesh(worldGroup,'box',x-w*.3+i*1.6,1.6,z-d/2+.16,.7,.9,.06,'#425d64',{metalness:.25,roughness:.32});
   }
   imported(worldGroup,'shelter',35,0,18,4,'#a7c1b7');imported(worldGroup,'bike',7,0,6,2.3,'#bdcfc2');
  }
  for(const n of g.world[g.zone].nodes)makeNode(n);
  for(const e of g.world[g.zone].enemies){const a=actor(true,e.maxHp>100);worldGroup.add(a.group);enemies.set(e.id,a);}
  cargoObject=new T.Group();crate(cargoObject,0,0,0,1.25);const ring=new T.Mesh(geometry.ring,new T.MeshBasicMaterial({color:'#e8ca82',side:T.DoubleSide}));ring.rotation.x=-Math.PI/2;ring.scale.setScalar(2);ring.position.y=.025;cargoObject.add(ring);worldGroup.add(cargoObject);
  zone=g.zone;focus.copy(new T.Vector3(g.player.x*WORLD_SCALE,.6,g.player.y*WORLD_SCALE));
 }
 function updateActor(a,p,dt,time,enemy=false,facing=null){
  const pos=worldToScene(p),moving=a.oldX!==null&&Math.hypot(pos.x-a.oldX,pos.z-a.oldZ)>.001;
  if(moving){a.group.rotation.y=Math.atan2(pos.x-a.oldX,pos.z-a.oldZ);a.phase+=dt*(enemy?6.5:11);}else if(facing&&!enemy)a.group.rotation.y=Math.atan2(facing.x,facing.y);
  a.group.position.set(pos.x,0,pos.z);a.oldX=pos.x;a.oldZ=pos.z;a.body.position.y=moving?Math.sin(a.phase*2)*.035:Math.sin(time*2)*.01;
  for(const l of a.limbs){l.leg.rotation.x=moving?Math.sin(a.phase)*.6*l.sign:0;l.arm.rotation.x=(enemy?-.65:0)+(moving?-Math.sin(a.phase)*.42*l.sign:Math.sin(time*2)*.025);}
  a.warning.visible=enemy&&p.windup>0;a.health.visible=enemy||p.hp<100;a.health.quaternion.copy(camera.quaternion);const hp=Math.max(0,p.hp)/(p.maxHp||100);a.fill.scale.x=.86*hp;a.fill.position.x=-(1-hp)*.43;
 }
 function resize(w,h){
  w=Number.isFinite(w)?Math.max(1,w):1;h=Number.isFinite(h)?Math.max(1,h):1;
  const ratio=Math.min(window.devicePixelRatio||1,quality.pixelRatio);renderer.setPixelRatio(ratio);renderer.setSize(w,h,false);camera.aspect=w/h;camera.updateProjectionMatrix();postFX.resize(w,h,ratio);
 }
 const api={
  get lost(){return lost;},
  render(g,options={}){
   if(lost)return;const time=options.time||0,dt=Math.min(.1,Math.max(0,time-lastTime));lastTime=time;
   if(zone!==g.zone)rebuild(g);
   yaw+=(targetYaw-yaw)*Math.min(1,(dt||.016)*9);
   const p=worldToScene(g.player);follow.set(p.x,.82,p.z);focus.lerp(follow,Math.min(1,(dt||.016)*9));zoomFactor+=(cameraZoom(zoomIndex)-zoomFactor)*Math.min(1,(dt||.016)*8);camera.position.set(focus.x+Math.sin(yaw)*13.7*zoomFactor,focus.y+15.2*zoomFactor,focus.z+Math.cos(yaw)*13.7*zoomFactor);camera.lookAt(focus);camera.updateMatrixWorld();
   const clock=g.survival.clock,fade=T.MathUtils.smoothstep(clock,126,156)*(1-T.MathUtils.smoothstep(clock,218,240)),night=fade>.5;hemi.intensity=2.35-fade*1.5;sun.intensity=3.2-fade*2.6;sun.color.copy(daySun).lerp(nightSun,fade);scene.background.copy(daySky).lerp(nightSky,fade);scene.fog.color.copy(scene.background);environment.update(time,g.player);
   sun.target.position.set(p.x,0,p.z);sun.position.set(p.x-12,28,p.z-16);sun.target.updateMatrixWorld();
   torch.position.set(p.x,1.35,p.z);torch.intensity=night&&g.survival.torch&&g.survival.fuel>0?11:0;
   fireLight.intensity=g.zone==='base'&&g.built.bonfire?7+Math.sin(time*9)*.7:0;if(flame)flame.scale.set(1,1+Math.sin(time*8)*.1,1);
   updateActor(player,g.player,dt,time,false,options.facing);player.blade.visible=g.weapon==='blade';player.gun.visible=g.weapon==='pistol';
   if(g.cooldown>.05)player.limbs[1].arm.rotation.x=-1.3;
   for(const e of g.world[g.zone].enemies){const a=enemies.get(e.id);a.group.visible=e.hp>0;if(e.hp>0)updateActor(a,e,dt,time,true);}
   for(const n of g.world[g.zone].nodes){const a=nodes.get(n.id);a.group.visible=n.amount>0;const near=Math.hypot(n.x-g.player.x,n.y-g.player.y)<125;a.sprite.visible=near;a.glow.visible=near;}
   for(const [id,obj] of buildings)obj.visible=!!g.built[id];
   cargoObject.visible=g.drop?.zone===g.zone;if(cargoObject.visible){const d=worldToScene(g.drop);cargoObject.position.set(d.x,.03,d.z);}
   marker.visible=!!options.target;if(options.target){const t=worldToScene(options.target);marker.position.set(t.x,.05,t.z);marker.scale.setScalar(1+Math.sin(time*6)*.15);}
   fx.update(g,time,dt,options.effects||[],quality.id==='light');postFX.render(scene,camera,quality.post);
  },
  resize,
  pickWorld(clientX,clientY){const r=canvas.getBoundingClientRect();ray.setFromCamera(new T.Vector2((clientX-r.left)/r.width*2-1,-(clientY-r.top)/r.height*2+1),camera);const found=ray.intersectObjects([...nodes.values()].map(n=>n.group).filter(g=>g.visible),true)[0];if(found){let o=found.object;while(o&&!o.userData.resource)o=o.parent;if(o)return {...o.userData.resource};}return ray.ray.intersectPlane(plane,hit)?sceneToWorld(hit):null;},
  movement(x,y){return screenMovement(x,y,yaw);},
  rotate(){targetYaw+=Math.PI/2;},
  zoom(){zoomIndex=(zoomIndex+1)%3;return [1,1.2,.85][zoomIndex];},
  setQuality(value){const next=qualityProfile(value);if(next.shadowSize!==quality.shadowSize&&sun.shadow.map){sun.shadow.map.dispose();sun.shadow.map=null;}quality=next;renderer.shadowMap.enabled=quality.shadowSize>0;sun.shadow.mapSize.set(quality.shadowSize||512,quality.shadowSize||512);environment?.setQuality(quality);const r=canvas.getBoundingClientRect();resize(r.width,r.height);return quality.id;}
 };
 canvas.addEventListener('webglcontextlost',event=>{event.preventDefault();lost=true;});canvas.addEventListener('webglcontextrestored',()=>{lost=false;});
 return api;
}
