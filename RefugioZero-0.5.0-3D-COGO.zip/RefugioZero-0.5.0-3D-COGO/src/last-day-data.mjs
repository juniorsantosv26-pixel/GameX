// Subconjunto permitido: valores locais de sobrevivência e rótulos PT-BR.
// Não contém endpoints, identificadores de conta, preços ou anúncios.
export const lastDayData = {
  "sourceSha256": "5bde82fb81a227f04e2f39c6cee5a021551686c306164de23b824954b96333e2",
  "labels": {
    "water": "Garrafa de Água",
    "emptyBottle": "Garrafa Vazia",
    "rawMeat": "Carne Crua",
    "cookedMeat": "Filé Suculento",
    "bonfire": "Fogueira"
  },
  "needs": {
    "hunger": {
      "maximum": 100,
      "drainPerSecond": 0.05,
      "damagePerSecond": 1.0
    },
    "thirst": {
      "maximum": 100,
      "drainPerSecond": 0.05,
      "damagePerSecond": 1.0
    }
  },
  "consumables": {
    "water": {
      "hunger": 0,
      "thirst": 50,
      "health": 0,
      "returns": "emptyBottle"
    },
    "rawMeat": {
      "hunger": 5,
      "thirst": 5,
      "health": 8
    },
    "cookedMeat": {
      "hunger": 30,
      "thirst": 5,
      "health": 20
    }
  }
};
