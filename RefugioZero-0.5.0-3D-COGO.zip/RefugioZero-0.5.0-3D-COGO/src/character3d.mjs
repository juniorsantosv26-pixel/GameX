import * as T from '../vendor/three.module.js';
// Shared geometry survives sector changes. Only per-actor indicator materials are owned.
const shapes={sphere:new T.SphereGeometry(1,12,8),capsule:new T.CapsuleGeometry(.5,1,3,8),box:new T.BoxGeometry(1,1,1),cylinder:new T.CylinderGeometry(1,1,1,10),ring:new T.RingGeometry(.38,.43,36),plane:new T.PlaneGeometry(1,1)};
const palette=new Map();
function material(color,options={}){const key=color+JSON.stringify(options);if(!palette.has(key))palette.set(key,new T.MeshStandardMaterial({color,roughness:.86,...options}));return palette.get(key);}
export function createCharacter3D({enemy=false,big=false,mat=material}={}){
 const group=new T.Group(),body=new T.Group();group.add(body);group.scale.setScalar(big?1.28:1);
 const skin=enemy?'#8e9e78':'#cb9a76',shirt=enemy?'#67734d':'#326a72',pants=enemy?'#574d44':'#354653',dark='#263038',leather='#65503a';
 const add=(parent,kind,x,y,z,sx,sy,sz,color,options={})=>{const m=new T.Mesh(shapes[kind],mat(color,options));m.position.set(x,y,z);m.scale.set(sx,sy,sz);m.castShadow=true;m.receiveShadow=true;parent.add(m);return m;};
 add(body,'sphere',0,1.15,0,.36,.43,.22,shirt);
 add(body,'capsule',0,.82,0,.55,.19,.32,pants);
 add(body,'cylinder',0,.87,0,.32,.075,.22,leather);
 add(body,'box',0,.86,.227,.09,.09,.04,'#b9a67a',{metalness:.65,roughness:.42});
 add(body,'cylinder',0,1.52,0,.115,.21,.11,skin);
 add(body,'sphere',0,1.76,.018,.235,.29,.225,skin);
 add(body,'sphere',0,1.64,.11,.177,.12,.15,enemy?'#7a8066':'#977157');
 add(body,'sphere',0,1.75,.232,.055,.075,.06,skin);
 for(const sign of [-1,1]){
  add(body,'sphere',sign*.224,1.76,.015,.055,.082,.055,skin);
  add(body,'sphere',sign*.082,1.82,.214,.043,.025,.021,'#e9e4d0');
  add(body,'sphere',sign*.083,1.82,.233,.018,.019,.01,enemy?'#deb25c':'#293b38');
  const brow=add(body,'box',sign*.085,1.866,.217,.09,.023,.025,enemy?'#4b503f':'#44372f');brow.rotation.z=sign*(enemy?-.18:.08);
 }
 add(body,'sphere',0,1.965,-.015,.238,.12,.231,enemy?'#454d39':'#263e44');
 if(!enemy){
  add(body,'box',0,1.946,.235,.34,.035,.2,'#29474d');
  add(body,'sphere',0,1.18,-.27,.3,.36,.16,'#8c714f');
  add(body,'box',0,1.13,-.42,.35,.23,.085,'#a18c62');
  for(const sign of [-1,1]){
   const strap=add(body,'box',sign*.225,1.23,.18,.075,.62,.06,leather);strap.rotation.z=-sign*.1;
   add(body,'box',sign*.17,1.1,.244,.18,.23,.07,'#375559');
   add(body,'box',sign*.17,1.12,.291,.15,.04,.025,'#789282');
  }
  add(body,'box',.35,.78,.08,.13,.24,.16,leather);
 }else{
  add(body,'sphere',-.2,1.15,.19,.07,.19,.015,'#704b39');
  add(body,'sphere',.12,1.7,.19,.06,.11,.02,'#786251');
 }
 const limbs=[];
 for(const sign of [-1,1]){
  const leg=new T.Group();leg.position.set(sign*.17,.78,0);body.add(leg);
  add(leg,'capsule',0,-.22,0,.26,.3,.27,pants);
  add(leg,'sphere',0,-.42,.055,.14,.125,.15,enemy?pants:'#52616a');
  add(leg,'capsule',0,-.54,0,.22,.21,.22,pants);
  add(leg,'sphere',0,-.705,.08,.15,.105,.245,dark);
  const arm=new T.Group();arm.position.set(sign*.37,1.43,0);body.add(arm);
  add(arm,'sphere',0,-.04,0,.16,.18,.16,shirt);
  add(arm,'capsule',0,-.22,.015,.19,.24,.2,shirt);
  add(arm,'capsule',0,-.45,.035,.155,.23,.16,skin);
  add(arm,'sphere',0,-.62,.045,.105,.125,.11,enemy?skin:dark);
  limbs.push({leg,arm,sign});
 }
 const blade=new T.Group(),gun=new T.Group();body.add(blade,gun);blade.position.set(.37,.82,.1);gun.position.copy(blade.position);
 const knife=add(blade,'box',0,0,.32,.065,.035,.5,'#c4d4d8',{metalness:.9,roughness:.28});knife.rotation.x=-.15;
 add(blade,'box',0,-.025,.04,.1,.07,.15,dark);
 add(gun,'box',0,.06,.17,.105,.13,.32,'#4f5a63',{metalness:.8,roughness:.35});
 add(gun,'cylinder',0,.07,.37,.035,.13,.035,'#273139',{metalness:.85}).rotation.x=Math.PI/2;
 blade.visible=!enemy;gun.visible=false;
 const basic=(color,opacity=1)=>new T.MeshBasicMaterial({color,transparent:opacity<1,opacity,side:T.DoubleSide,depthWrite:false});
 const ring=new T.Mesh(shapes.ring,basic(enemy?'#c18b63':'#8bddc8',enemy?.2:.55));ring.rotation.x=-Math.PI/2;ring.position.y=.026;group.add(ring);
 const warning=new T.Mesh(shapes.ring,basic('#f28c50',.8));warning.rotation.x=-Math.PI/2;warning.position.y=.04;warning.scale.setScalar(4.1);warning.visible=false;group.add(warning);
 const health=new T.Group();health.position.y=2.26;group.add(health);
 const bg=new T.Mesh(shapes.plane,basic('#172629'));bg.material.depthTest=false;bg.scale.set(.94,.075,1);health.add(bg);
 const fill=new T.Mesh(shapes.plane,basic(enemy?'#e09463':'#9ee7bd'));fill.material.depthTest=false;fill.scale.set(.88,.045,1);fill.position.z=.001;health.add(fill);
 return {group,body,limbs,blade,gun,warning,health,fill,ring,oldX:null,oldZ:null,phase:0};
}
