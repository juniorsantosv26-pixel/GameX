/** Read the geometry subset used by the selected OBJ exports. Never evaluates source. */
export function parseOBJ(text){
 const vertices=[],texcoords=[],normalVectors=[],faces=[];
 const finite=(parts,n)=>{const v=parts.slice(0,n).map(Number);if(v.length!==n||v.some(x=>!Number.isFinite(x)))throw new TypeError('Invalid OBJ number');return v;};
 for(const raw of text.split(/\r?\n/)){
  const line=raw.split('#')[0].trim();if(!line)continue;
  const [kind,...parts]=line.split(/\s+/);
  if(kind==='v')vertices.push(finite(parts,3));
  else if(kind==='vt')texcoords.push(finite(parts,2));
  else if(kind==='vn')normalVectors.push(finite(parts,3));
  else if(kind==='f'){
   if(parts.length<3)throw new TypeError('OBJ face requires at least three vertices');
   const counts=[vertices.length,texcoords.length,normalVectors.length];
   const refs=parts.map(p=>p.split('/').map((s,k)=>{
    if(k>2)throw new RangeError('Invalid OBJ index');
    if(!s&&k>0)return null;const n=Number(s);
    if(!Number.isInteger(n)||n===0)throw new RangeError('Invalid OBJ index');
    const i=n>0?n-1:counts[k]+n;if(i<0||i>=counts[k])throw new RangeError('OBJ index outside source');return i;
   }));
   for(let i=1;i<refs.length-1;i++)faces.push([refs[0],refs[i],refs[i+1]]);
  }
 }
 if(!faces.length)throw new TypeError('OBJ has no faces');
 const positions=[],normals=[],uvs=[],min=[Infinity,Infinity,Infinity],max=[-Infinity,-Infinity,-Infinity];
 for(const face of faces){
  const [a,b,c]=face.map(ref=>vertices[ref[0]]);
  const ab=b.map((v,i)=>v-a[i]),ac=c.map((v,i)=>v-a[i]);
  const cross=[ab[1]*ac[2]-ab[2]*ac[1],ab[2]*ac[0]-ab[0]*ac[2],ab[0]*ac[1]-ab[1]*ac[0]];
  const length=Math.hypot(...cross)||1,normal=cross.map(v=>v/length);
  for(const ref of face){
   const p=vertices[ref[0]];positions.push(...p);normals.push(...(ref[2]!=null?normalVectors[ref[2]]:normal));uvs.push(...(ref[1]!=null?texcoords[ref[1]]:[0,0]));
   for(let k=0;k<3;k++){min[k]=Math.min(min[k],p[k]);max[k]=Math.max(max[k],p[k]);}
  }
 }
 return {positions,normals,uvs,bounds:{min,max},triangles:faces.length};
}
