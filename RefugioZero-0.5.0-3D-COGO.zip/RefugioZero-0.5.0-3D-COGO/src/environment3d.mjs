import * as T from '../vendor/three.module.js';
import {surfaceData,deterministicScatter} from './surface-data.mjs';

export function createEnvironment3D({root,zone,mesh,mat,imported,quality}){
 const city=zone==='district',base=zone==='base',geometries=[],ownedTextures=[],cache=new Map(),wind={value:0},hero={value:new T.Vector3()};
 const own=g=>(geometries.push(g),g);
 function maps(kind,repeat=1){
  const key=kind+repeat;if(cache.has(key))return cache.get(key);
  const data=surfaceData(kind,kind==='grass'?256:128,37),result={};
  for(const [name,field] of [['map','color'],['normalMap','normal'],['roughnessMap','roughness']]){
   const t=new T.DataTexture(data[field],data.size,data.size,T.RGBAFormat);t.userData.sectorOwned=true;t.colorSpace=name==='map'?T.SRGBColorSpace:T.NoColorSpace;t.wrapS=t.wrapT=T.RepeatWrapping;t.repeat.set(repeat,repeat);t.magFilter=T.LinearFilter;t.minFilter=T.LinearMipmapLinearFilter;t.generateMipmaps=true;t.needsUpdate=true;ownedTextures.push(t);result[name]=t;
  }
  result.normalScale=new T.Vector2(.55,.55);cache.set(key,result);return result;
 }
 const floor=new T.Mesh(own(new T.PlaneGeometry(120,110)),mat(city?'#bec8ba':'#b8d294',maps(city?'concrete':'grass',22)));floor.rotation.x=-Math.PI/2;floor.position.set(20,-.11,14);floor.receiveShadow=true;root.add(floor);
 function ribbon(){
  const pos=[],uv=[],indices=[],steps=60,width=city?1.8:1.3;
  for(let i=0;i<=steps;i++){
   const x=-25+i*1.5,z=city?20-x*.08:18.2+Math.sin(x*.11)*1.7;
   pos.push(x,-.08,z-width,x,-.08,z+width);uv.push(i/5,0,i/5,1);
   if(i<steps){const j=i*2;indices.push(j,j+1,j+2,j+1,j+3,j+2);}
  }
  const g=own(new T.BufferGeometry());g.setAttribute('position',new T.Float32BufferAttribute(pos,3));g.setAttribute('uv',new T.Float32BufferAttribute(uv,2));g.setIndex(indices);g.computeVertexNormals();
  const road=new T.Mesh(g,mat(city?'#546167':'#e7d1a1',maps(city?'stone':'dirt',1)));road.receiveShadow=true;root.add(road);
 }
 ribbon();
 function breeze(color,fade=false,options={}){
  const m=new T.MeshStandardMaterial({color,roughness:.86,side:T.DoubleSide,...options});
  m.onBeforeCompile=s=>{
   s.uniforms.uWind=wind;s.uniforms.uHero=hero;
   s.vertexShader=s.vertexShader.replace('#include <common>','#include <common>\nuniform float uWind; varying vec3 vLeafWorld;');
   s.vertexShader=s.vertexShader.replace('#include <begin_vertex>',`#include <begin_vertex>
    #ifdef USE_INSTANCING
    transformed.x+=sin(uWind*1.4+instanceMatrix[3].x*.63+instanceMatrix[3].z*.29)*.075*max(0.,position.y+.6);
    #endif`);
   s.vertexShader=s.vertexShader.replace('#include <worldpos_vertex>',`#include <worldpos_vertex>
    vec4 leafPos=vec4(transformed,1.);
    #ifdef USE_INSTANCING
    leafPos=instanceMatrix*leafPos;
    #endif
    vLeafWorld=(modelMatrix*leafPos).xyz;`);
   if(fade){
    s.fragmentShader=s.fragmentShader.replace('#include <common>','#include <common>\nuniform vec3 uHero; varying vec3 vLeafWorld;');
    s.fragmentShader=s.fragmentShader.replace('#include <clipping_planes_fragment>',`#include <clipping_planes_fragment>
     float clearHero=smoothstep(.55,2.1,length(vLeafWorld.xz-uHero.xz));
     if(vLeafWorld.y>1.5 && fract(sin(dot(gl_FragCoord.xy,vec2(12.9898,78.233)))*43758.5453)>clearHero)discard;`);
   }
  };
  m.customProgramCacheKey=()=>fade?'refugio-crown-v05':'refugio-grass-v05';return m;
 }
 const dummy=new T.Object3D(),color=new T.Color();
 const leafPixels=new Uint8Array(128*128*4),leaflets=[];
 for(let i=0;i<58;i++){const a=i*2.399,r=43*Math.sqrt((i+.5)/58);leaflets.push({x:64+Math.cos(a)*r,y:64+Math.sin(a)*r,angle:a,rx:4.5+(i%3)*1.1,ry:7+(i%4)*.65});}
 for(let y=0;y<128;y++)for(let x=0;x<128;x++){
  let inside=false,vein=false;
  for(const l of leaflets){const dx=x-l.x,dy=y-l.y,c=Math.cos(l.angle),s=Math.sin(l.angle),u=dx*c-dy*s,v=dx*s+dy*c;if(u*u/(l.rx*l.rx)+v*v/(l.ry*l.ry)<1){inside=true;vein=Math.abs(u)<.65;break;}}
  if(inside){const n=((x*17+y*31)%19);leafPixels.set([vein?218:184+n,vein?236:213+n,vein?169:145+n,255],(y*128+x)*4);}
 }
 const leafTexture=new T.DataTexture(leafPixels,128,128,T.RGBAFormat);leafTexture.colorSpace=T.SRGBColorSpace;leafTexture.magFilter=T.LinearFilter;leafTexture.minFilter=T.LinearMipmapLinearFilter;leafTexture.generateMipmaps=true;leafTexture.needsUpdate=true;ownedTextures.push(leafTexture);
 const leafGeo=own(new T.SphereGeometry(1,9,6)),trunkGeo=own(new T.CylinderGeometry(.16,.27,1,7));
 const trunksMat=mat('#89705a',maps('wood',2)),leafMat=breeze('#ffffff',true);
 const candidates=deterministicScatter(city?10:base?24:44,zone==='forest'?119:71,{minX:-5,maxX:45,minZ:-5,maxZ:32});
 const trees=candidates.filter(p=>!(base&&p.x>8&&p.x<32&&p.z>3&&p.z<22));
 // Open center and dense borders keep the player readable while giving the world depth.
 const border=deterministicScatter(25,921,{minX:-10,maxX:48,minZ:-11,maxZ:38}).filter(p=>p.x<0||p.x>40||p.z<0||p.z>28);
 trees.push(...border);
 const trunks=new T.InstancedMesh(trunkGeo,trunksMat,trees.length),leaves=new T.InstancedMesh(leafGeo,leafMat,trees.length*5);trunks.castShadow=true;trunks.receiveShadow=true;leaves.castShadow=true;leaves.receiveShadow=true;
 trees.forEach((p,i)=>{
  const h=3.1+p.scale*1.2;dummy.position.set(p.x,h/2,p.z);dummy.rotation.set(0,p.rotation,0);dummy.scale.set(p.scale,h,p.scale);dummy.updateMatrix();trunks.setMatrixAt(i,dummy.matrix);
   for(let n=0;n<5;n++){
   const a=n*2.4+p.rotation;dummy.position.set(p.x+Math.cos(a)*.72,h+.2+(n%2)*.8,p.z+Math.sin(a)*.72);dummy.rotation.set(.12*n,p.rotation,.11*n);dummy.scale.set(p.scale*(.63+n*.035),p.scale*(.58+(n%2)*.21),p.scale*.67);dummy.updateMatrix();leaves.setMatrixAt(i*5+n,dummy.matrix);
   color.set(city?'#78866b':['#51925a','#6d9d4b','#93b75d','#447c53','#77a45b'][i%5]);leaves.setColorAt(i*5+n,color);
  }
 });
 root.add(trunks,leaves);
 const branches=new T.InstancedMesh(trunkGeo,trunksMat,trees.length*3);branches.castShadow=true;
 trees.forEach((p,i)=>{const h=3.1+p.scale*1.2;for(let n=0;n<3;n++){const a=n*2.09+p.rotation;dummy.position.set(p.x+Math.cos(a)*.25,h*.77,p.z+Math.sin(a)*.25);dummy.rotation.set(Math.sin(a)*.6,0,Math.cos(a)*.6);dummy.scale.set(p.scale*.5,h*.48,p.scale*.5);dummy.updateMatrix();branches.setMatrixAt(i*3+n,dummy.matrix);}});root.add(branches);
 const fronds=new T.InstancedMesh(own(new T.PlaneGeometry(1,1)),breeze('#ffffff',true,{map:leafTexture,alphaTest:.45}),trees.length*28);fronds.castShadow=true;fronds.receiveShadow=true;
 trees.forEach((p,i)=>{const h=3.1+p.scale*1.2;for(let n=0;n<28;n++){
  const a=n*2.399+p.rotation,r=.55+(n%5)*.18;dummy.position.set(p.x+Math.cos(a)*r,h-.3+(n%4)*.5,p.z+Math.sin(a)*r);dummy.rotation.set(-.45-(n%3)*.25,a,Math.sin(a)*.5);dummy.scale.set(p.scale*1.65,p.scale*1.7,1);dummy.updateMatrix();fronds.setMatrixAt(i*28+n,dummy.matrix);fronds.setColorAt(i*28+n,color.set(['#83ab64','#619652','#a2bc6d','#73a36a'][i%4]));
 }});root.add(fronds);
 const grassGeo=own(new T.BufferGeometry());
 const blades=[];for(let i=0;i<8;i++){const a=i*2.399,h=.22+(i%4)*.095,x=Math.cos(a)*.055,z=Math.sin(a)*.055,w=.018;blades.push(x-w,0,z,x+w,0,z,x+.035,h*.6,z+.025,x-w,0,z,x+.035,h*.6,z+.025,x+.06,h,z+.04);}
 grassGeo.setAttribute('position',new T.Float32BufferAttribute(blades,3));grassGeo.computeVertexNormals();
 const grassMat=breeze('#ffffff'),spots=deterministicScatter(2200,287,{minX:-3,maxX:43,minZ:-3,maxZ:31}).filter(p=>{
  const roadZ=city?20-p.x*.08:18.2+Math.sin(p.x*.11)*1.7;
  return Math.abs(p.z-roadZ)>1.65&&!(base&&p.x>9&&p.x<31&&p.z>4&&p.z<20);
 }).slice(0,700);
 const grass=new T.InstancedMesh(grassGeo,grassMat,spots.length);grass.receiveShadow=true;
 spots.forEach((p,i)=>{dummy.position.set(p.x,0,p.z);dummy.rotation.set(0,p.rotation,0);dummy.scale.setScalar((city?.65:1)*p.scale);dummy.updateMatrix();grass.setMatrixAt(i,dummy.matrix);grass.setColorAt(i,color.set(['#689d48','#8db451','#4d854e','#a4b773'][i%4]));});root.add(grass);
 const outsideHouse=p=>!(base&&p.x>12&&p.x<28&&p.z>5&&p.z<16);
 const stoneSpots=deterministicScatter(90,509,{minX:0,maxX:40,minZ:0,maxZ:28}).filter(outsideHouse);
 const pebbles=new T.InstancedMesh(own(new T.IcosahedronGeometry(1,0)),mat('#a0aaa0',maps('stone')),stoneSpots.length);
 stoneSpots.forEach((p,i)=>{dummy.position.set(p.x,.07,p.z);dummy.rotation.set(p.rotation,.2,p.rotation);dummy.scale.set(p.scale*.11,p.scale*.07,p.scale*.12);dummy.updateMatrix();pebbles.setMatrixAt(i,dummy.matrix);});pebbles.receiveShadow=true;root.add(pebbles);
 const flowerSpots=deterministicScatter(55,561,{minX:1,maxX:39,minZ:1,maxZ:27}).filter(outsideHouse);
 const flowers=new T.InstancedMesh(own(new T.SphereGeometry(1,5,3)),mat('#ffffff'),flowerSpots.length);
 flowerSpots.forEach((p,i)=>{dummy.position.set(p.x,.25,p.z);dummy.rotation.set(0,0,0);dummy.scale.set(.055,.045,.055);dummy.updateMatrix();flowers.setMatrixAt(i,dummy.matrix);flowers.setColorAt(i,color.set(i%3?'#f6d18d':'#c4adf0'));});root.add(flowers);flowers.visible=!city;
 // Large distant silhouettes are backdrop only; the playable surface stays flat.
 const mountainGeo=own(new T.ConeGeometry(1,1,7));
 for(let i=0;i<9;i++){const m=new T.Mesh(mountainGeo,mat(i%2?'#718b88':'#7d9b93'));m.position.set(-30+i*13,4.3,-31-(i%3)*6);m.scale.set(15+i%4,12+i%3*3,11);root.add(m);}
 const rocks=deterministicScatter(base?7:14,631,{minX:0,maxX:40,minZ:1,maxZ:27});
 for(const [i,p] of rocks.entries())if(!(base&&p.x>10&&p.x<31&&p.z<21)){
  const rock=imported(root,i%2?'rock':'rock2',p.x,0,p.z,.75+p.scale,'#c3d2c8');rock.material=mat('#a9b9af',maps('stone',2));
 }
 if(city){
  for(let i=0;i<15;i++){const x=1+i*2.8;mesh(root,'box',x,-.045,20-x*.08,.85,.025,.08,'#dfcf91');}
  // Broken sidewalk, drainage, rusty barrels and a salvaged utility vehicle.
  for(let i=0;i<17;i++){mesh(root,'box',3+i*2.15,-.005,15.9,2.05,.16,.65,'#b4beb8',maps('concrete'));}
  for(let i=0;i<5;i++){
   const barrel=mesh(root,'cylinder',29+(i%3)*.9,.55,8+Math.floor(i/3),.34,1.1,.34,i%2?'#8d613b':'#527879',{metalness:.45,roughness:.72});
   for(const y of [.2,.8])mesh(root,'cylinder',barrel.position.x,y,barrel.position.z,.352,.055,.352,'#414d4d',{metalness:.7});
  }
  const car=new T.Group();car.position.set(11,0,23);car.rotation.y=.3;root.add(car);
  mesh(car,'box',0,.65,0,2.1,.65,4.2,'#9e573b',{metalness:.55,roughness:.64});mesh(car,'box',0,1.25,.25,1.9,.65,2.25,'#bf8050',{metalness:.4});mesh(car,'box',0,1.28,1.4,1.63,.43,.03,'#597b86',{metalness:.7,roughness:.16});
  for(const x of [-1.04,1.04])for(const z of [-1.27,1.27]){const wheel=mesh(car,'cylinder',x,.42,z,.4,.24,.4,'#263336');wheel.rotation.z=Math.PI/2;}
  for(const x of [-.72,.72])mesh(car,'box',x,.7,2.12,.43,.2,.04,'#e5c383',{emissive:'#a48247',emissiveIntensity:.2});
 }else{
  const fallen=mesh(root,'cylinder',34,.25,22,.25,3.5,.25,'#847157',maps('wood',2));fallen.rotation.z=Math.PI/2;fallen.rotation.y=.6;
 }
 root.userData.ownedGeometry=geometries;root.userData.ownedTextures=ownedTextures;
 return {
  maps,
  update(time,player){wind.value=time;hero.value.set(player.x/30,0,player.y/30);},
  setQuality(profile){grass.count=Math.min(spots.length,profile.grass);flowers.count=Math.min(flowerSpots.length,profile.id==='light'?15:55);fronds.visible=profile.id!=='light';leaves.visible=true;}
 };
}
