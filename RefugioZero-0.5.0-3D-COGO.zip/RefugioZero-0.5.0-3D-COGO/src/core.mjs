import {lastDayData} from './last-day-data.mjs';
export const VERSION='0.5.0';
export const CAPACITY=60;
export const items={wood:{name:'Madeira',icon:'wood',cat:'Materiais',where:'Bosque'},stone:{name:'Pedra',icon:'stone',cat:'Materiais',where:'Bosque'},scrap:{name:'Sucata',icon:'scrap',cat:'Materiais',where:'Distrito'},electronics:{name:'Eletrônicos',icon:'chip',cat:'Materiais',where:'Distrito'},cloth:{name:'Tecido',icon:'cloth',cat:'Materiais',where:'Distrito'},medkit:{name:'Kit médico',icon:'medkit',cat:'Suprimentos',where:'Fabricação'},food:{name:'Provisões',icon:'food',cat:'Suprimentos',where:'Bosque'}};
export const recipes={bench:{name:'Bancada de trabalho',description:'Organize a produção do refúgio.',cost:{wood:8,stone:6},build:true},scanner:{name:'Scanner de sinal',description:'Localize uma frequência de emergência.',cost:{scrap:6,electronics:2},requires:'bench',build:true},radio:{name:'Rádio de emergência',description:'Envie o sinal. Há alguém lá fora.',cost:{wood:8,scrap:10,electronics:4},requires:'scanner',build:true},medkit:{name:'Kit médico',description:'Recupera 45 pontos de vida.',cost:{cloth:2,food:1},requires:'bench',give:'medkit',amount:1},ammo:{name:'Munição ×12',description:'Mantenha distância dos infectados.',cost:{scrap:3,stone:2},requires:'bench',ammo:12},repair:{name:'Reparar equipamento',description:'Restaura lâmina, pistola e proteção.',cost:{scrap:4},repair:true}};
export const zones={base:{name:'Refúgio',tag:'ÁREA SEGURA',subtitle:'Prepare. Organize. Recomece.',risk:'Seguro'},forest:{name:'Bosque cinzento',tag:'SETOR 01',subtitle:'A mata guarda recursos. E outras coisas.',risk:'Moderado'},district:{name:'Distrito abandonado',tag:'SETOR 02',subtitle:'Procure componentes entre as ruínas.',risk:'Elevado'}};
export const weapons={blade:{name:'Lâmina',damage:28,range:88,cooldown:.52},pistol:{name:'Pistola',damage:36,range:280,cooldown:.35},fists:{name:'Punhos',damage:10,range:75,cooldown:.7}};
recipes.pack={name:'Mochila reforçada',description:'Aumenta a carga de 60 para 90 unidades. Melhoria permanente.',cost:{wood:6,cloth:6,scrap:4},requires:'bench',build:true};
recipes.fuel={name:'Recarregar tocha',description:'Restaura a iluminação para expedições noturnas.',cost:{wood:2,cloth:1},fuel:true};
for(const [id,icon,where] of [['water','water','Distrito ou coletor'],['emptyBottle','water','Consumo de água'],['rawMeat','food','Bosque'],['cookedMeat','food','Fogueira']])items[id]={name:lastDayData.labels[id],icon,cat:'Suprimentos',where,use:lastDayData.consumables[id]};
items.rawMeat.icon='rawMeat';items.cookedMeat.icon='cookedMeat';items.emptyBottle.icon='emptyBottle';
items.food.use={hunger:25,thirst:0,health:0};
recipes.bonfire={name:lastDayData.labels.bonfire,description:'Permite cozinhar carne usando madeira.',cost:{wood:5,stone:4},build:true};
recipes.cook={name:'Preparar filé',description:'Carne cozida: +30 alimento, +5 hidratação e até 20 de vida. Produção imediata.',cost:{rawMeat:1,wood:1},requires:'bonfire',give:'cookedMeat',amount:1};
recipes.rainCollector={name:'Coletor de chuva',description:'Permite reabastecer garrafas no refúgio.',cost:{wood:6,stone:4,cloth:2},requires:'bench',build:true};
recipes.refillWater={name:'Encher garrafa',description:'Reutiliza uma garrafa vazia. Água: +50 hidratação. Produção imediata.',cost:{emptyBottle:1},requires:'rainCollector',give:'water',amount:1};
const clamp=(v,a,b)=>Math.min(b,Math.max(a,v));
const known=(catalog,key)=>typeof key==='string'&&Object.hasOwn(catalog,key);
export const distance=(a,b)=>Math.hypot(a.x-b.x,a.y-b.y);
export const cargo=g=>Object.values(g.bag).reduce((a,b)=>a+b,0);
export const capacity=g=>g.built.pack===true?90:CAPACITY;
export const isNight=g=>g.survival.clock>=150;
export function toggleTorch(g){
 if(!g.survival.torch&&g.survival.fuel<=0)return {ok:false,message:'Tocha sem combustível. Recarregue na oficina do refúgio.'};
 g.survival.torch=!g.survival.torch;g.revision++;
 return {ok:true,message:g.survival.torch?'Tocha acesa. O combustível só é gasto à noite, fora do refúgio.':'Tocha apagada.'};
}
export function preparation(g,zone){
 if(zone==='base')return [];
 const warnings=[];
 if(g.player.hp<60)warnings.push('Pouca vida: use um kit ou descanse no refúgio.');
 if(g.durability.blade<=20&&(g.ammo<=0||g.durability.pistol<=0))warnings.push('Equipamento comprometido: repare antes de enfrentar inimigos.');
 if(capacity(g)-cargo(g)<10)warnings.push('Mochila quase cheia: deposite os materiais antes de sair.');
 if(isNight(g)&&g.survival.fuel<20)warnings.push('Pouco combustível na tocha: recarregue para explorar à noite.');
 if(g.survival.hunger<25)warnings.push('Pouco alimento no organismo: coma antes de sair.');
 if(g.survival.thirst<25)warnings.push('Pouca hidratação: beba e leve água na mochila.');
 return warnings;
}
export const total=(g,id)=>(g.bag[id]||0)+(g.store[id]||0);
export function createWorld(){
 const base={nodes:[],enemies:[]};
 const forest={nodes:[],enemies:[]},district={nodes:[],enemies:[]};
 for(let i=0;i<15;i++)forest.nodes.push({id:'f'+i,item:i<8?'wood':i<13?'stone':'food',amount:i<8?5:4,x:280+(i*173)%770,y:150+(i*127)%520});
 for(let i=0;i<14;i++)district.nodes.push({id:'d'+i,item:i<7?'scrap':i<11?'electronics':'cloth',amount:i<7?5:i<11?2:3,x:300+(i*157)%740,y:150+(i*113)%520});
 forest.nodes.push({id:'f-meat-1',item:'rawMeat',amount:2,x:370,y:650},{id:'f-meat-2',item:'rawMeat',amount:2,x:1000,y:600});
 district.nodes.push({id:'d-water-1',item:'water',amount:3,x:260,y:660},{id:'d-bottle-1',item:'emptyBottle',amount:2,x:720,y:540});
 for(let i=0;i<4;i++)forest.enemies.push({id:'fe'+i,x:460+(i*191)%560,y:210+(i*139)%390,hp:60,maxHp:60,cooldown:0,windup:0,seed:i});
 for(let i=0;i<5;i++)district.enemies.push({id:'de'+i,x:440+(i*197)%630,y:180+(i*131)%470,hp:i===4?120:75,maxHp:i===4?120:75,cooldown:0,windup:0,seed:i});
 return {base,forest,district};
}
export function createGame(){return {version:VERSION,zone:'base',player:{x:600,y:570,hp:100},bag:{wood:2,scrap:2,medkit:3,food:2,water:2,emptyBottle:1},store:{},favorites:['medkit','food','water','cookedMeat'],ammo:24,weapon:'blade',durability:{blade:100,pistol:100,armor:100},built:{bench:false,scanner:false,radio:false,pack:false,bonfire:false,rainCollector:false},survival:{clock:0,fuel:100,torch:false,hunger:100,thirst:100},won:false,drop:null,world:createWorld(),cooldown:0,stats:{kills:0,collected:0,deaths:0},revision:0};}
export function addItem(g,id,count){if(!known(items,id)||!Number.isFinite(count)||count<=0)return 0;const n=Math.max(0,Math.min(Math.floor(count),99-(g.bag[id]||0),capacity(g)-cargo(g)));if(n){g.bag[id]=(g.bag[id]||0)+n;g.revision++;}return n;}
export function deposit(g){if(g.zone!=='base')return {ok:false,message:'Deposite seus itens no refúgio.'};let count=0;for(const [id,n]of Object.entries(g.bag)){if(g.favorites.includes(id))continue;g.store[id]=(g.store[id]||0)+n;count+=n;delete g.bag[id];}g.revision++;return {ok:true,message:count?`${count} recursos guardados. Favoritos ficaram com você.`:'Só há favoritos na mochila. Nada foi movido.'};}
export function withdraw(g,id,n=5){if(g.zone!=='base'||!known(items,id))return {ok:false,message:'Retire itens no refúgio.'};const moved=addItem(g,id,Math.min(n,g.store[id]||0));if(!moved)return {ok:false,message:'Mochila cheia ou depósito vazio.'};g.store[id]-=moved;if(!g.store[id])delete g.store[id];return {ok:true,message:`${moved} × ${items[id].name} na mochila.`};}
export function craft(g,id){
 const r=known(recipes,id)?recipes[id]:null;if(!r)return {ok:false,message:'Projeto desconhecido.'};if(g.zone!=='base')return {ok:false,message:'Volte ao refúgio para fabricar.'};if(r.build&&g.built[id])return {ok:false,message:'Este projeto já foi concluído.'};if(r.requires&&!g.built[r.requires])return {ok:false,message:`Primeiro construa: ${recipes[r.requires].name}.`};
 if(r.repair&&Object.values(g.durability).every(n=>n>=100))return {ok:false,message:'Seu equipamento já está em bom estado.'};
 if(r.fuel&&g.survival.fuel>=100)return {ok:false,message:'A tocha já está com combustível completo.'};
 const missing=Object.entries(r.cost).filter(([k,n])=>total(g,k)<n);if(missing.length)return {ok:false,message:'Faltam '+missing.map(([k,n])=>`${n-total(g,k)} ${items[k].name.toLowerCase()}`).join(', ')+'.'};
 if(r.give&&cargo(g)-Object.entries(r.cost).reduce((n,[k,v])=>n+Math.min(v,g.bag[k]||0),0)+r.amount>capacity(g))return {ok:false,message:'Abra espaço na mochila antes de fabricar.'};
 for(const[k,n]of Object.entries(r.cost)){const fromBag=Math.min(n,g.bag[k]||0);if(fromBag){g.bag[k]-=fromBag;if(!g.bag[k])delete g.bag[k];}const fromStore=n-fromBag;if(fromStore){g.store[k]-=fromStore;if(!g.store[k])delete g.store[k];}}
 if(r.build)g.built[id]=true;if(r.give)addItem(g,r.give,r.amount);if(r.ammo)g.ammo+=r.ammo;if(r.fuel)g.survival.fuel=100;if(r.repair)g.durability={blade:100,pistol:100,armor:100};if(g.built.radio)g.won=true;g.revision++;
 return {ok:true,message:id==='radio'?'Sinal enviado. O refúgio está conectado!':`${r.name}: pronto.`};
}
export function collect(g,id){const n=g.world[g.zone].nodes.find(n=>n.id===id);if(!n||!n.amount)return {ok:false,message:'Este recurso já foi coletado.'};if(distance(g.player,n)>85)return {ok:false,message:'Aproxime-se para coletar.'};const added=addItem(g,n.item,n.amount);if(!added)return {ok:false,message:'Mochila cheia. Volte e deposite os recursos.'};n.amount-=added;g.stats.collected+=added;return {ok:true,message:`+${added} ${items[n.item].name.toLowerCase()}`,item:n.item};}
export function attack(g){
 if(g.zone==='base')return {ok:false,message:'O refúgio é uma área segura.'};if(g.cooldown>0)return {ok:false,silent:true};const w=weapons[g.weapon];if(g.weapon!=='fists'&&g.durability[g.weapon]<=0)return {ok:false,message:'Arma quebrada. Use os punhos ou repare no refúgio.'};if(g.weapon==='pistol'&&g.ammo<=0)return {ok:false,message:'Sem munição. Troque para a lâmina.'};
 const e=g.world[g.zone].enemies.filter(e=>e.hp>0&&distance(g.player,e)<w.range).sort((a,b)=>distance(a,g.player)-distance(b,g.player))[0];if(!e)return {ok:false,message:'Nenhum inimigo ao alcance.'};
 g.cooldown=w.cooldown;e.hp=Math.max(0,e.hp-w.damage);if(g.weapon!=='fists')g.durability[g.weapon]=Math.max(0,g.durability[g.weapon]-(g.weapon==='blade'?3:2));if(g.weapon==='pistol')g.ammo--;
 if(!e.hp){g.stats.kills++;addItem(g,'cloth',1);}g.revision++;return {ok:true,message:!e.hp?'Ameaça neutralizada.':`${w.damage} de dano`,enemy:e.id,killed:!e.hp,damage:w.damage};
}
export function heal(g){if(g.player.hp>=100)return {ok:false,message:'Sua vida já está completa.'};if(!g.bag.medkit)return {ok:false,message:'Sem kit na mochila. Retire ou fabrique no refúgio.'};g.bag.medkit--;if(!g.bag.medkit)delete g.bag.medkit;g.player.hp=Math.min(100,g.player.hp+45);g.revision++;return {ok:true,message:'+45 de vida.'};}
export function consume(g,id){
 const item=known(items,id)?items[id]:null,use=item?.use;
 if(!use||!g.bag[id])return {ok:false,message:'Escolha um alimento ou água da mochila.'};
 if(!(use.hunger>0&&g.survival.hunger<100)&&!(use.thirst>0&&g.survival.thirst<100)&&!(use.health>0&&g.player.hp<100))return {ok:false,message:'Você já está recuperado para este suprimento.'};
 if(use.returns&&(g.bag[use.returns]||0)>=99)return {ok:false,message:'Abra espaço para a garrafa vazia.'};
 g.bag[id]--;if(!g.bag[id])delete g.bag[id];
 for(const need of ['hunger','thirst'])g.survival[need]=clamp(g.survival[need]+(use[need]||0),0,lastDayData.needs[need].maximum);
 g.player.hp=Math.min(100,g.player.hp+(use.health||0));if(use.returns)addItem(g,use.returns,1);g.revision++;
 return {ok:true,message:`${item.name}: consumido.${use.returns?' A garrafa vazia voltou à mochila.':''}`};
}
export function move(g,x,y,dt){const len=Math.hypot(x,y);if(!len)return;const d=170*clamp(dt,0,.08);g.player.x=clamp(g.player.x+x/Math.max(1,len)*d,40,1160);g.player.y=clamp(g.player.y+y/Math.max(1,len)*d,60,760);}
export function travel(g,zone){if(!known(zones,zone))return {ok:false,message:'Setor desconhecido.'};if(g.zone===zone)return {ok:false,message:'Você já está neste setor.'};if(g.world[g.zone].enemies.some(e=>e.hp>0&&distance(g.player,e)<135))return {ok:false,message:'Afaste-se dos inimigos antes de viajar.'};g.zone=zone;g.player.x=zone==='base'?600:160;g.player.y=zone==='base'?570:620;g.cooldown=0;
 const w=g.world[zone];if(zone!=='base'&&w.nodes.every(n=>!n.amount)){const next=createWorld()[zone];w.nodes=next.nodes;w.enemies=next.enemies;}
 g.revision++;return {ok:true,message:zone==='base'?'Você chegou ao refúgio. Respire.':`${zones[zone].name}: encontre recursos e fique atento.`};}
export function die(g){g.drop=cargo(g)>0?{zone:g.zone,x:g.player.x,y:g.player.y,items:{...g.bag}}:g.drop;g.bag={};g.player={x:600,y:570,hp:100};g.survival.hunger=100;g.survival.thirst=100;g.zone='base';g.cooldown=0;g.stats.deaths++;g.revision++;return {ok:true,message:'Você foi resgatado. Sua carga ficou no local da queda.'};}
export function recover(g){if(!g.drop||g.drop.zone!==g.zone||distance(g.player,g.drop)>85)return {ok:false,message:'Aproxime-se da carga perdida.'};let count=0;for(const[id,n]of Object.entries(g.drop.items)){const moved=addItem(g,id,n);count+=moved;g.drop.items[id]-=moved;if(!g.drop.items[id])delete g.drop.items[id];}if(!Object.keys(g.drop.items).length)g.drop=null;g.revision++;return {ok:count>0,message:count?`${count} itens recuperados.`:'Mochila cheia. Abra espaço e volte.'};}
export function tick(g,seconds){const dt=clamp(Number.isFinite(seconds)?seconds:0,0,.1);g.cooldown=Math.max(0,g.cooldown-dt);g.survival.clock=(g.survival.clock+dt)%240;
 if(g.zone!=='base'&&isNight(g)&&g.survival.torch){g.survival.fuel=Math.max(0,g.survival.fuel-dt*.5);if(g.survival.fuel===0)g.survival.torch=false;}
 if(g.zone==='base'){g.player.hp=Math.min(100,g.player.hp+dt*2);return [];}
 const events=[];
 for(const need of ['hunger','thirst']){const rule=lastDayData.needs[need];g.survival[need]=Math.max(0,g.survival[need]-dt*rule.drainPerSecond);if(g.survival[need]===0)g.player.hp-=dt*rule.damagePerSecond;}
 for(const e of g.world[g.zone].enemies){if(e.hp<=0)continue;e.cooldown=Math.max(0,e.cooldown-dt);const d=distance(g.player,e);if(e.windup>0){e.windup-=dt;if(e.windup<=0){if(d<85){const dmg=g.durability.armor>0?8:13;g.player.hp-=dmg;g.durability.armor=Math.max(0,g.durability.armor-4);events.push({type:'hit',damage:dmg});}e.cooldown=1.3;}continue;}if(d<58&&e.cooldown<=0)e.windup=.58;else if(d<290&&d>48){const speed=(e.maxHp>100?29:40)*dt;e.x+=(g.player.x-e.x)/d*speed;e.y+=(g.player.y-e.y)/d*speed;}}
 if(g.player.hp<=0){die(g);events.push({type:'death'});}return events;
}
export function objective(g){const id=!g.built.bench?'bench':!g.built.scanner?'scanner':'radio';return {id,...recipes[id],complete:g.won};}
export function restore(text){
 const fresh=createGame();try{const s=JSON.parse(text);if(!s||typeof s!=='object'||![VERSION,'0.4.0','0.3.0','0.2.1','0.2.0','0.1.0'].includes(s.version))return fresh;const num=(v,a,b,f)=>typeof v==='number'&&Number.isFinite(v)?clamp(v,a,b):f;
 fresh.zone=known(zones,s.zone)?s.zone:'base';fresh.player={x:num(s.player?.x,40,1160,600),y:num(s.player?.y,60,760,570),hp:num(s.player?.hp,1,100,100)};
 fresh.built.bench=s.built?.bench===true;fresh.built.scanner=fresh.built.bench&&s.built?.scanner===true;fresh.built.radio=fresh.built.scanner&&s.built?.radio===true;fresh.built.pack=fresh.built.bench&&s.built?.pack===true;fresh.won=fresh.built.radio;
 fresh.built.bonfire=s.built?.bonfire===true;fresh.built.rainCollector=fresh.built.bench&&s.built?.rainCollector===true;
 fresh.survival.clock=num(s.survival?.clock,0,239.999,0);fresh.survival.fuel=num(s.survival?.fuel,0,100,100);fresh.survival.torch=s.survival?.torch===true&&fresh.survival.fuel>0;
 for(const need of ['hunger','thirst'])fresh.survival[need]=num(s.survival?.[need],0,lastDayData.needs[need].maximum,lastDayData.needs[need].maximum);
 for(const bucket of ['bag','store']){fresh[bucket]={};for(const k of Object.keys(items)){const n=Math.floor(num(s[bucket]?.[k],0,bucket==='bag'?99:99999,0));if(n){if(bucket==='bag')addItem(fresh,k,n);else fresh.store[k]=n;}}}
 fresh.favorites=Array.isArray(s.favorites)?[...new Set(s.favorites.filter(k=>known(items,k)))]:['medkit'];fresh.weapon=known(weapons,s.weapon)?s.weapon:'blade';fresh.ammo=Math.floor(num(s.ammo,0,9999,24));for(const k of ['blade','pistol','armor'])fresh.durability[k]=num(s.durability?.[k],0,100,100);
 for(const zone of ['forest','district'])for(const type of ['nodes','enemies']){for(const o of fresh.world[zone][type]){const stored=Array.isArray(s.world?.[zone]?.[type])?s.world[zone][type].find(v=>v?.id===o.id):null;if(!stored)continue;if(type==='nodes')o.amount=Math.floor(num(stored.amount,0,o.amount,o.amount));else{o.hp=num(stored.hp,0,o.maxHp,o.maxHp);o.x=num(stored.x,40,1160,o.x);o.y=num(stored.y,60,760,o.y);}}}
 if(s.drop&&['forest','district'].includes(s.drop.zone)){const bag={};for(const k of Object.keys(items)){const n=Math.floor(num(s.drop.items?.[k],0,99,0));if(n)bag[k]=n;}if(Object.keys(bag).length)fresh.drop={zone:s.drop.zone,x:num(s.drop.x,40,1160,600),y:num(s.drop.y,60,760,400),items:bag};}
 for(const k of Object.keys(fresh.stats))fresh.stats[k]=Math.floor(num(s.stats?.[k],0,999999,0));return fresh;
 }catch{return fresh;}
}
