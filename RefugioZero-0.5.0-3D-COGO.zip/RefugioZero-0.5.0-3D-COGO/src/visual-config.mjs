const profiles=Object.freeze({
 balanced:Object.freeze({id:'balanced',label:'Equilibrado',pixelRatio:1.25,shadowSize:1024,grass:360,post:true}),
 high:Object.freeze({id:'high',label:'Alto',pixelRatio:1.75,shadowSize:2048,grass:700,post:true}),
 light:Object.freeze({id:'light',label:'Leve',pixelRatio:1,shadowSize:0,grass:140,post:false})
});
export function qualityProfile(name){return typeof name==='string'&&Object.hasOwn(profiles,name)?profiles[name]:profiles.balanced;}
export function nextQuality(name){return {balanced:'high',high:'light',light:'balanced'}[qualityProfile(name).id];}
export function cameraZoom(index){return [1,.82,1.17][Number.isFinite(index)?((Math.floor(index)%3)+3)%3:0];}
