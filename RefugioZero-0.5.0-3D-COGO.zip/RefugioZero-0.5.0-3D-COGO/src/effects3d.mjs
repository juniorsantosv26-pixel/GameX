import * as T from '../vendor/three.module.js';
const LIMIT=192;
export function createEffects3D(scene){
 const positions=new Float32Array(LIMIT*3),colors=new Float32Array(LIMIT*3),particles=Array.from({length:LIMIT},()=>({life:0,age:1,x:0,y:0,z:0,vx:0,vy:0,vz:0}));positions.fill(1e5);
 const geometry=new T.BufferGeometry();geometry.setAttribute('position',new T.BufferAttribute(positions,3));geometry.setAttribute('color',new T.BufferAttribute(colors,3));
 const pixels=new Uint8Array(16*16*4);for(let y=0;y<16;y++)for(let x=0;x<16;x++){const alpha=Math.max(0,1-Math.hypot((x-7.5)/7.5,(y-7.5)/7.5));pixels.set([255,255,255,Math.round(alpha*alpha*255)],(y*16+x)*4);}
 const texture=new T.DataTexture(pixels,16,16,T.RGBAFormat);texture.needsUpdate=true;
 const material=new T.PointsMaterial({size:.18,map:texture,vertexColors:true,transparent:true,opacity:.85,depthWrite:false,blending:T.AdditiveBlending});
 const points=new T.Points(geometry,material);points.frustumCulled=false;scene.add(points);
 const flash=new T.Mesh(new T.IcosahedronGeometry(.19,0),new T.MeshBasicMaterial({color:'#ffe5a3',transparent:true,opacity:.95}));flash.visible=false;scene.add(flash);
 const flashLight=new T.PointLight('#ffc96b',0,4,2);scene.add(flashLight);
 const traceGeometry=new T.BufferGeometry(),tracePositions=new Float32Array(12*6);traceGeometry.setAttribute('position',new T.BufferAttribute(tracePositions,3));traceGeometry.setDrawRange(0,0);const traceMaterial=new T.LineBasicMaterial({color:'#ffe4a2',transparent:true,opacity:.9,depthWrite:false});const traces=new T.LineSegments(traceGeometry,traceMaterial);traces.frustumCulled=false;scene.add(traces);
 const seen=new WeakSet(),activeTraces=[];let cursor=0,zone='',emberClock=0,flashLeft=0;
 function emit(x,y,z,color,n,speed=1){const c=new T.Color(color);for(let i=0;i<n;i++){const a=i*2.399+cursor;const p=particles[cursor++%LIMIT];Object.assign(p,{x,y,z,vx:Math.cos(a)*speed,vy:.7+(i%4)*.25,vz:Math.sin(a)*speed,life:.35+(i%5)*.15,age:0});p.color=c;}}
 return {
  update(g,time,dt,effects=[],light=false){
   if(zone!==g.zone){for(const p of particles)p.age=p.life+1;activeTraces.length=0;flashLeft=0;zone=g.zone;}
   for(const e of effects)if(!seen.has(e)){
    seen.add(e);const x=e.ex/30,z=e.ey/30;
    if(e.type==='shot'){
     flash.position.set(e.x/30,1.2,e.y/30);flashLight.position.copy(flash.position);flashLeft=.085;
     if(activeTraces.length>=12)activeTraces.shift();activeTraces.push({a:[e.x/30,1.2,e.y/30],b:[x,1,z],life:.09});emit(x,1,z,'#f5c08b',light?5:10,1.1);
    }else emit(x,.8,z,'#d5ba87',light?4:8,.8);
   }
   emberClock+=dt;
   if(g.zone==='base'&&g.built.bonfire&&emberClock>.065){emberClock=0;emit(24,.55,18.7,'#ffc46a',1,.15);}
   const night=g.survival.clock>150;
   if(!light&&Math.floor(time*7)!==Math.floor((time-dt)*7))emit(g.player.x/30+Math.sin(time*2.7)*5,1+Math.sin(time)*.5,g.player.y/30+Math.cos(time*1.8)*4,night?'#9ddcc6':'#eee7bb',1,.03);
   particles.forEach((p,i)=>{
    p.age+=dt;if(p.age>=p.life){positions[i*3]=1e5;positions[i*3+1]=1e5;positions[i*3+2]=1e5;return;}
    p.x+=p.vx*dt;p.y+=p.vy*dt;p.z+=p.vz*dt;p.vy-=dt*.5;positions.set([p.x,p.y,p.z],i*3);const fade=1-p.age/p.life;colors.set([p.color.r*fade,p.color.g*fade,p.color.b*fade],i*3);
   });
   geometry.attributes.position.needsUpdate=true;geometry.attributes.color.needsUpdate=true;
   flashLeft=Math.max(0,flashLeft-dt);flash.visible=flashLeft>0;flash.scale.setScalar(.7+Math.sin(time*50)*.25);flashLight.intensity=flash.visible?4:0;
   for(const t of activeTraces)t.life-=dt;for(let i=activeTraces.length-1;i>=0;i--)if(activeTraces[i].life<=0)activeTraces.splice(i,1);
   activeTraces.forEach((t,i)=>tracePositions.set([...t.a,...t.b],i*6));traceGeometry.setDrawRange(0,activeTraces.length*2);traceGeometry.attributes.position.needsUpdate=true;
  },
  dispose(){scene.remove(points,flash,traces,flashLight);geometry.dispose();material.dispose();texture.dispose();flash.geometry.dispose();flash.material.dispose();traceGeometry.dispose();traceMaterial.dispose();}
 };
}
